//
// create by renchang on 2021-08-04
//

#ifndef POST_PROCESS_GRAPH_H
#define POST_PROCESS_GRAPH_H

#include<vector>

// using namespace std;
typedef int vertex_t;
typedef int path_t;

static int sMaxBytesNum = 4;
static int sOffsetBits[4] = {0, 8, 16, 24};
static int sByteMask = 0xff;

static path_t path_to_fast(const std::vector<vertex_t>& path)
{
    path_t fast = 0;
    for (int i = 0; i < sMaxBytesNum; i++) {
        int now_num = 0;
        now_num = i < path.size() ? path[i] << sOffsetBits[i] : 0xff << sOffsetBits[i];
        fast |= now_num;
    }
    return fast;
}

static std::vector<vertex_t> fast_to_path(path_t fast)
{
    std::vector<vertex_t> path;

    for (int i = 0; i < sMaxBytesNum; i++) {
        vertex_t v = fast >> sOffsetBits[i] & sByteMask;
        if (v == sByteMask) {
            break;
        }
        path.push_back(v);
    }
    return path;
}

class Edge {
public:
    Edge(vertex_t v1, vertex_t v2) : v1(v1), v2(v2) {}

    vertex_t v1;
    vertex_t v2;
    bool has(vertex_t v)
    {
        return v == v1 || v == v2;
    }
};

class Graph{
    public:
        void addEdge(int u, int v);
        std::vector<std::vector<vertex_t>>findCyclesFast(int maxLen);
        int edgeNum(){return graph_.size();}
    
    private:
        std::vector<std::vector<vertex_t>> findAllCyclesFast(int maxLen);
        
        std::vector<Edge> graph_;

};
#endif // POST_PROCESS_GRAPH_H