//
// Created by renchang on 2021-8-4.
//

#include <functional>
#include <algorithm>
#include <set>
#include "graph.h"

using namespace std;

void Graph::addEdge(int u, int v) {

    graph_.emplace_back(u, v);  // push_back 会创建对象后然后调用移动构造函数，而emplace_back则是直接创建这个元素的对象，省去了拷贝或者移动元素的过程
}

std::vector<std::vector<vertex_t>> Graph::findAllCyclesFast(int maxLen)
{
    if (maxLen > 4) {

        return std::vector< std::vector<vertex_t> >();
    }

    std::set<path_t > cycles;

    std::function<void(std::vector<vertex_t>)> findNewCycles = [&]( std::vector<vertex_t> sub_path )
    {
        auto visisted = []( vertex_t v, const std::vector<vertex_t> & path ){
            return std::find(path.begin(),path.end(),v) != path.end();
        };

        auto rotate_to_smallest = []( std::vector<vertex_t> path ){
            std::rotate(path.begin(), std::min_element(path.begin(), path.end()), path.end());
            return path;
        };

        auto invert = [&]( std::vector<vertex_t> path ){
            std::reverse(path.begin(),path.end());
            return rotate_to_smallest(path);
        };

        auto isNew = [&cycles]( const std::vector<vertex_t> & path ) {
            path_t fast = path_to_fast(path);
            return cycles.count(fast) == 0;
        };

        vertex_t start_node = sub_path[0];
        vertex_t next_node;

        // visit each edge and each node of each edge
        for(auto edge : graph_)
        {
            if( edge.has(start_node) )
            {
                vertex_t node1 = edge.v1, node2 = edge.v2;

                if(node1 == start_node)
                    next_node = node2;
                else
                    next_node = node1;

                if( !visisted(next_node, sub_path) && sub_path.size() < maxLen) 
                {
                    // neighbor node not on path yet
                    std::vector<vertex_t> sub;
                    sub.push_back(next_node);
                    sub.insert(sub.end(), sub_path.begin(), sub_path.end());
                    findNewCycles( sub );
                }
                else if( sub_path.size() > 2 && next_node == sub_path.back() ) 
                {
                    // cycle found
                    auto p = rotate_to_smallest(sub_path); // 最小索引的角点加入进来
                    auto inv = invert(p);

                    if( isNew(p) && isNew(inv) ) {
                        path_t path = path_to_fast(p);
                        cycles.emplace(path);
                    }
                }
            }
        }
    };

    std::set<vertex_t > vertexs;

    for(auto edge : graph_)
    {
        vertexs.emplace(edge.v1);
        vertexs.emplace(edge.v2);
    }

    for (auto v:vertexs) {
        findNewCycles( std::vector<vertex_t>(1, v) ); //std::vector<vertex_t>(1, v) = std::vector<vertex_t>{v}
    }

    std::vector<std::vector<vertex_t> > quad;
    quad.reserve(cycles.size());

    for (auto & c: cycles) {
        std::vector<vertex_t> path = fast_to_path(c);
        quad.push_back(path);
    }

    return quad;
}

std::vector<std::vector<vertex_t>>Graph::findCyclesFast(int maxLen){
    std::vector<std::vector<vertex_t>> cycles = findAllCyclesFast(maxLen);
    for (auto it = cycles.begin(); it != cycles.end(); /* NOTHING */)
    {
        if ((*it).size() < maxLen)
            it = cycles.erase(it);
        else
            ++it;
    }

    return cycles;

}