// This file is part of OpenCV project.
// It is subject to the license terms in the LICENSE file found in the top-level directory
// of this distribution and at http://opencv.org/license.html.

#ifndef __OPENCV_FAST_LINE_DETECTOR_HPP__
#define __OPENCV_FAST_LINE_DETECTOR_HPP__

#include <opencv2/core.hpp>

namespace cv
{
namespace ximgproc
{

//! @addtogroup ximgproc_fast_line_detector
//! @{

/** @brief Class implementing the FLD (Fast Line Detector) algorithm described
in @cite Lee14 .
*/

//! @include samples/fld_lines.cpp

class CV_EXPORTS_W FastLineDetector : public Algorithm
{
public:
    /** @example fld_lines.cpp
      An example using the FastLineDetector
      */
    /** @brief Finds lines in the input image.
      This is the output of the default parameters of the algorithm on the above
      shown image.

      ![image](pics/corridor_fld.jpg)

      @param image A grayscale (CV_8UC1) input image. If only a roi needs to be
      selected, use: `fld_ptr-\>detect(image(roi), lines, ...);
      lines += Scalar(roi.x, roi.y, roi.x, roi.y);`
      @param lines A vector of Vec4f elements specifying the beginning
      and ending point of a line.  Where Vec4f is (x1, y1, x2, y2), point
      1 is the start, point 2 - end. Returned lines are directed so that the
      brighter side is on their left.
      */
    CV_WRAP virtual void detect(InputArray image, OutputArray lines) = 0;

    /** @brief Draws the line segments on a given image.
      @param image The image, where the lines will be drawn. Should be bigger
      or equal to the image, where the lines were found.
      @param lines A vector of the lines that needed to be drawn.
      @param draw_arrow If true, arrow heads will be drawn.
      @param linecolor Line color.
      @param linethickness Line thickness.
      */
    CV_WRAP virtual void drawSegments(InputOutputArray image, InputArray lines,
            bool draw_arrow = false, Scalar linecolor = Scalar(0, 0, 255), int linethickness = 1) = 0;

    virtual ~FastLineDetector() { }
};

enum SEG_TYPE {
    RAW,
    MERGE_CRUDE,
    MERGE_FINE,
    AUTO_NEW,
};

struct SEGMENT {
    SEGMENT() = default;

    SEGMENT(float x1, float y1, float x2, float y2):x1(x1), y1(y1), x2(x2), y2(y2) {
        len = cv::norm(cv::Point2f(x1, y1) - cv::Point2f(x2, y2));
    }

    SEGMENT(const Point2f& p1, const Point2f& p2):x1(p1.x), y1(p1.y), x2(p2.x), y2(p2.y) {
        len = cv::norm(p1 - p2);
    }

    float x1{0}, y1{0}, x2{0}, y2{0}, angle{0}, len{0};
    Point2f center;
    Mat l;
    SEG_TYPE type{RAW};
    int expandDirect{-1};
    int ref{0};

    std::vector<SEGMENT> subSegs;

    bool operator==(const SEGMENT &t1)const {
        return ((int)roundf(x1) == (int)roundf(t1.x1) && (int)roundf(y1) == (int)roundf(t1.y1) &&
                (int)roundf(x2) == (int)roundf(t1.x2) && (int)roundf(y2) == (int)roundf(t1.y2)) ||
                ((int)roundf(x1) == (int)roundf(t1.x2) && (int)roundf(y1) == (int)roundf(t1.y2) &&
                (int)roundf(x2) == (int)roundf(t1.x1) && (int)roundf(y2) == (int)roundf(t1.y1));
    }

    void sort()
    {
        double delta_x = x1 - x2, delta_y = y1 - y2;
        float tmpx1 = 0.0, tmpy1 = 0.0;
        // get horizontal lines and vertical lines respectively
        if (fabs(delta_x) > fabs(delta_y)) { //horizontal
            tmpx1 = x1 > x2 ? x2 : x1;
            tmpy1 = x1 > x2 ? y2 : y1;
        } else {
            tmpx1 = y1 > y2 ? x2 : x1;
            tmpy1 = y1 > y2 ? y2 : y1;
        }

        if (x1 != tmpx1) {
            x2 = x1;
            y2 = y1;
            x1 = tmpx1;
            y1 = tmpy1;
        }
    }

};

class FastLineDetectorImpl : public FastLineDetector
{
    public:
    /** @brief Creates a smart pointer to a FastLineDetector object and initializes it

        @param length_threshold    Segment shorter than this will be discarded
        @param distance_threshold  A point placed from a hypothesis line
                           segment farther than this will be regarded as an outlier
        @param canny_th1           First threshold for hysteresis procedure in Canny()
        @param canny_th2           Second threshold for hysteresis procedure in Canny()
        @param canny_aperture_size Aperturesize for the sobel operator in Canny().
                           If zero, Canny() is not applied and the input image is taken as an edge image.
        @param do_merge            If true, incremental merging of segments will be performed
        */
        FastLineDetectorImpl(int _length_threshold = 10, float _distance_threshold = 1.414213562f,
                double _canny_th1 = 50.0, double _canny_th2 = 50.0, int _canny_aperture_size = 3,
                bool _do_merge = false);

        void detect(InputArray image, OutputArray lines) CV_OVERRIDE;

        void drawSegments(InputOutputArray image, InputArray lines, bool draw_arrow = false, Scalar linecolor = Scalar(0, 0, 255), int linethickness = 1) CV_OVERRIDE;

    protected:
        int imagewidth, imageheight, threshold_length;
        float threshold_dist;
        double canny_th1, canny_th2;
        int canny_aperture_size;
        bool do_merge;

        FastLineDetectorImpl& operator= (const FastLineDetectorImpl&); // to quiet MSVC
        template<class T>
            void incidentPoint(const Mat& l, T& pt);

        void mergeLines(const SEGMENT& seg1, const SEGMENT& seg2, SEGMENT& seg_merged);

        bool mergeSegments(const SEGMENT& seg1, const SEGMENT& seg2, SEGMENT& seg_merged);

        bool getPointChain(const Mat& img, Point pt, Point& chained_pt, float& direction, int step);

        double distPointLine(const Mat& p, Mat& l);

        void extractSegments(const std::vector<Point2i>& points, std::vector<SEGMENT>& segments);

        void lineDetection(const Mat& src, std::vector<SEGMENT>& segments_all);

        void pointInboardTest(const Size srcSize, Point2i& pt);

        void getAngle(SEGMENT& seg);

        void additionalOperationsOnSegment(const Mat& src, SEGMENT& seg);

        void drawSegment(InputOutputArray image, const SEGMENT& seg, Scalar bgr = Scalar(0,255,0), int thickness = 1, bool directed = true);
};

CV_EXPORTS_W Ptr<FastLineDetector> createFastLineDetector(
        int length_threshold = 10, float distance_threshold = 1.414213562f,
        double canny_th1 = 50.0, double canny_th2 = 50.0, int canny_aperture_size = 3,
        bool do_merge = false);

//! @} ximgproc_fast_line_detector
}
}
#endif
