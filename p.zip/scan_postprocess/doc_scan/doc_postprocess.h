//
// create by renchang on 2021-08-02
//

#ifndef POST_PROCESS_DOC_POSTPROCESS_H 
#define POST_PROCESS_DOC_POSTPROCESS_H

#include "fast_line_detector.hpp"
// using namespace cv;

struct CORNER {
    cv::Point2f pt;
    std::vector<int> lineIds;
    float score {0};
};

struct QUAD {
    std::vector<CORNER> corners;
    float score {0};
};

enum DIRECT {
    TOP,
    BOTTOM,
    LEFT,
    RIGHT,
    IN,
};

enum PROCESS {
    NORMAL,
    CORNERCASE,
    EDGECASE
};


class DocPostprocess : public cv::ximgproc::FastLineDetectorImpl {
    public:
        DocPostprocess(int _length_threshold, float _distance_threshold, 
                       double _canny_th1, double _canny_th2, int _canny_aperture_size, bool _do_merge) : FastLineDetectorImpl(_length_threshold,  \
                                                                                                                             _distance_threshold,  \
                                                                                                                             _canny_th1, _canny_th2, _canny_aperture_size, _do_merge)
        {

        }
        void detect(const cv::Mat & heatmap, std::vector<cv::Point2f>& quadPts, const cv::Mat & src, float thresh, int & processStatus, bool isDebug=false);
    
    private:
        int imageW_;
        int imageH_;
    
    private:
        void initSegment(cv::ximgproc::SEGMENT & seg);

        void centerSegment(const cv::ximgproc::SEGMENT& seg, cv::Point2f & c);

        std::vector<cv::ximgproc::SEGMENT> mergeCrudeSegs(cv::Mat image, std::vector<cv::ximgproc::SEGMENT> &segments);

        std::vector<cv::ximgproc::SEGMENT> mergeFineSegs(cv::Mat image, std::vector<cv::ximgproc::SEGMENT> &segments);

        void sortSegment(std::vector<cv::ximgproc::SEGMENT>& segments);

        float getLineAngle(const cv::ximgproc::SEGMENT& seg1, const cv::ximgproc::SEGMENT& seg2);

        float lineVerticalDist(const cv::ximgproc::SEGMENT& seg1, const cv::ximgproc::SEGMENT& seg2);

        std::vector<cv::Point2f> getSegmentsQuad(const cv::ximgproc::SEGMENT &seg1, const cv::ximgproc::SEGMENT &seg2);

        bool isFilled(cv::Mat &img, std::vector<cv::Point2f> quad);

        float getPointDist(const cv::Point2f &point1, const cv::Point2f &point2);

        float getSegmentsOverlaps(const cv::ximgproc::SEGMENT &seg1, const cv::ximgproc::SEGMENT &seg2, bool isReProj = true);

        int getPointDirectOnLine(const cv::Point2f &point, const cv::ximgproc::SEGMENT &line);

        bool isVerticalLine(const cv::ximgproc::SEGMENT &seg);
        
        void drawSegments(cv::Mat & image, const std::vector<cv::ximgproc::SEGMENT> &lines);
        
        std::vector<cv::ximgproc::SEGMENT> uniqueSegs(const std::vector<cv::ximgproc::SEGMENT> &segments);
        
        void mergeSubSegments(cv::ximgproc::SEGMENT& seg);

        void filterSegs(std::vector<cv::ximgproc::SEGMENT> &segments);

        void calcCorners(const cv::Size& boardSize, const std::vector<cv::ximgproc::SEGMENT> &segs,
                     std::vector<CORNER> &corners, bool isLoose=false);

        bool getSegmentIntersection(const cv::ximgproc::SEGMENT &line_a, const cv::ximgproc::SEGMENT &line_b, cv::Point2f &intersection);

        bool isPointOnLine(const cv::Point2f &point, const cv::ximgproc::SEGMENT &line);

        bool testCornerInBoard(const CORNER &corner, const cv::Size& size, bool canOut=true);

        void drawCorners(cv::Mat & image, const std::vector<CORNER> &corners);

        bool calcEdgeQuad(const cv::Size& boardSize, const std::vector<cv::ximgproc::SEGMENT>& segs, const std::vector<CORNER>& corners,
                      std::vector<cv::Point2f>& quad);

        void getBoardLine(std::vector<cv::ximgproc::SEGMENT>& segs);

        void calcQuad(const cv::Size& boardSize, const std::vector<cv::ximgproc::SEGMENT> &segs, const std::vector<CORNER> &corners,
                  std::vector<QUAD> &quads, bool isLoose=false);
        
        bool checkEnoughPoints(const CORNER& corner, const std::vector<std::vector<int> >& segCornerInfo);

        int findCornersLine(const CORNER &c1, const CORNER &c2);

        void drawQuads(cv::Mat & image, const std::vector<QUAD> &quad);

        void drawQuad(cv::Mat & image, const std::vector<cv::Point2f> &quads);

        QUAD chooseBestQuad(std::vector<QUAD> &quads);

        void cornerCase(const std::vector<cv::ximgproc::SEGMENT>& segs,
                    const std::vector<CORNER>& corners,
                    QUAD &quad, bool isDebug);

        bool tryQuadWithBoardLine(const std::vector<cv::ximgproc::SEGMENT>& inSegs, const std::vector<CORNER>& inCorners,
                              std::vector<cv::ximgproc::SEGMENT>& outSegs, std::vector<CORNER>& outCorners, std::vector<QUAD>& quads);
        
        void addBoardLine(std::vector<cv::ximgproc::SEGMENT>& segs);

        void addVertexSegs(const std::vector<cv::ximgproc::SEGMENT>& inSegs, std::vector<cv::ximgproc::SEGMENT>& outSegs, std::vector<CORNER>& outCorners);

        void sortSegments(std::vector<cv::ximgproc::SEGMENT> &segments);

        void addMoreSegs(const std::vector<cv::ximgproc::SEGMENT>& in, std::vector<cv::ximgproc::SEGMENT>& out);

        bool isSegmentIntersection(const cv::ximgproc::SEGMENT &line_a, const cv::ximgproc::SEGMENT &line_b);

        bool isTrapezoid(const QUAD &quad, const std::vector<cv::ximgproc::SEGMENT> &segs, bool isLoose);

        std::pair<DIRECT, cv::ximgproc::SEGMENT> chooseLongestSegment(std::vector<std::pair<DIRECT, cv::ximgproc::SEGMENT>> &segs);

        void addExtendNearEdgeSegs(const std::vector<cv::ximgproc::SEGMENT> &inSegs, const std::vector<CORNER>& corners, std::vector<cv::ximgproc::SEGMENT> &outSegs);

        bool mayGenerateQuad(const std::vector<cv::ximgproc::SEGMENT> &segs);

        void generateImageEdgeQuad(QUAD &quadOut);

        void normalizeQuad(const cv::Mat &image, const QUAD &quad, std::vector<cv::Point2f> &quadPts);

        void restoreQuads(std::vector<QUAD> &quads);

        void restoreCorners(std::vector<CORNER> &corner);

        void normalizeQuad_2(const cv::Mat& image, const QUAD &quad, std::vector<cv::Point2f> &quadPts);

};

#endif //POST_PROCESS_DOC_POSTPROCESS_H