//
// create by renchang on 2021-08-02
//

#include "doc_postprocess.h"

#include <iostream>
#include <set>

#include "opencv2/core/core.hpp"
#include "opencv2/imgcodecs/imgcodecs.hpp"
#include "opencv2/imgproc/imgproc.hpp"
// #include "android/log.h"

#include "graph.h"

using cv::Mat;
using cv::max;
using cv::min;
using cv::Point;
using cv::Point2f;
using cv::Rect;
using cv::ximgproc::SEGMENT;
using std::vector;

// #define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "doc_postprocess", __VA_ARGS__)

static const int LARGE_NUM = 9999999;

static const int HANDLE_IMAGE_W = 320;
static const int HANDLE_IMAGE_H = 320;
static const int HANDLE_IMAGE_PADDING = 6;
static const int HANDLE_REAL_W = HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING * 2;
static const int HANDLE_REAL_H = HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING * 2;

static const float MAX_CRUDE_ANGLE = 15;
static const float MAX_CRUDE_LINE_DIST = 15;
static const float MIN_CRUDE_LINE_DIST = 5;
static const float MIN_CRUDE_OVERLAP_RATIO = 0.7;
static const float FILLED_RATIO = 0.85;

static const float MAX_FINE_ANGLE = 8;
static const float MAX_FINE_LINE_DIST = 8;
static const float MIN_FINE_OVERLAP_RATIO = 2;

static const int MAX_LINE_NUM = 30;

static const int MAX_CORNER_NUM = 30;
static const int MIN_CORNER_DIST = 20;
static const int MIN_CORNER_ANGLE = 30;
static const float MIN_CORNER_BLANK_RATIO = 1.5;
static const float MIN_CORNER_BLANK_RATIO_OUTBOARD = 2;
static const float MIN_CORNER_BLANK_RATIO_LOOSE = 3;
static const float MIN_CORNER_TWO_LINE_RATIO = 0.15;
static const float MIN_CORNER_TWO_LINE_RATIO_LOOSE = 0.1;

static const float EDGE_QUAD_TWO_STRAIGHT_SEG_DELTA_ANGEL = 20;
static const float EDGE_QUAD_SEG_NO_OVERLAP_DIST = 10;
static const float EDGE_QUAD_PT_TO_SEG_DIST = 20;
static const float EDGE_QUAD_SEG_TO_EDGE_DIST = 5;
static const float EDGE_QUAD_TWO_EDGE_DELTA_ANGEL = 1;

static const float THRESHOLD_MAP = 0.1;
static const int QUAD_CORNER_NUM = 4;

static const float DOTTED_SOLID_LINE_RATIO = 0.30;
static const float DOTTED_SOLID_LINE_RATIO_OUTBOARD = 0.15;
static const float DOTTED_SOLID_LINE_RATIO_LOOSE = 0.10;

static const float QUAD_SEG_LEN_RATIO = 0.2;
static const float QUAD_BLANK_SCORE_PUNISH = 1.5;
static const float QUAD_EXCEED_LINE_PUNISH = 0;

static const int MIN_BOARD_LINE_EXIST_DIST = 20;
static const int MIN_BOARD_LINE_EXIST_ANGLE = 10;
static const float MIN_BOARD_LINE_EXIST_RATIO = 0.5;
static const int MIN_BOARD_LINE_DIST = 8;

static const float MIN_LINE_LEN = 15;
static const float CORNER_CASE_LINE_LEN = 50;
static const int CORNER_CASE_MAX_AUTO_NEW_LINE = 3;

static const float NEAR_BOARD_PADDING = 20;
static const float QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET = 4;
static const float QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET_LOOSE = 8;
static const float QUAD_TWO_PARALLEL_LINE_MIN_ANGLE = 5;
static const float QUAD_EXPAND_MIN_SEG_LENGHT = 200;
static const float MAX_NEAR_BOARDLINE_ANGLE = 45;
static const float MIN_NEAR_BOARDLINE_LENGHT = 40;
static const float MIN_LINE_PT_TO_CORNERS_DIS = 15;
static const float MIN_EXPANDED_EDGE_LINE_LENGHT = 160;

CV_EXPORTS cv::Ptr<cv::ximgproc::FastLineDetector>
cv::ximgproc::createFastLineDetector(int _length_threshold, float _distance_threshold, double _canny_th1,
                                     double _canny_th2, int _canny_aperture_size, bool _do_merge)
{
    return cv::makePtr<DocPostprocess>(_length_threshold, _distance_threshold, _canny_th1, _canny_th2,
                                       _canny_aperture_size, _do_merge);
}

void DocPostprocess::centerSegment(const cv::ximgproc::SEGMENT &seg, cv::Point2f &c)
{
    c.x = (seg.x1 + seg.y1) / 2;
    c.y = (seg.x2 + seg.y2) / 2;
}

void DocPostprocess::initSegment(cv::ximgproc::SEGMENT &seg)
{
    seg.len = sqrt((seg.x1 - seg.x2) * (seg.x1 - seg.x2) + (seg.y1 - seg.y2) * (seg.y1 - seg.y2));

    double a[] = {0.0, 0.0, 1.0};
    double b[] = {0.0, 0.0, 1.0};

    a[0] = seg.x1;
    a[1] = seg.y1;
    b[0] = seg.x2;
    b[1] = seg.y2;

    cv::Mat p1 = cv::Mat(3, 1, CV_64FC1, a).clone();
    cv::Mat p2 = cv::Mat(3, 1, CV_64FC1, b).clone();

    cv::Mat l1 = p1.cross(p2);
    seg.l = l1.clone();
    seg.type = cv::ximgproc::RAW;
    seg.expandDirect = -1;
    getAngle(seg);

    centerSegment(seg, seg.center);
}

void DocPostprocess::sortSegment(std::vector<cv::ximgproc::SEGMENT> &segments)
{
    sort(segments.begin(), segments.end(),
         [](const cv::ximgproc::SEGMENT &a, const cv::ximgproc::SEGMENT &b) -> bool
         { return a.len > b.len; });
}

float DocPostprocess::getLineAngle(const cv::ximgproc::SEGMENT &seg1, const cv::ximgproc::SEGMENT &seg2)
{
    float angleDiff = fabs(seg1.angle - seg2.angle) / CV_PI * 180;
    angleDiff = angleDiff > 180 ? angleDiff - 180 : angleDiff;
    angleDiff = angleDiff > 90 ? 180 - angleDiff : angleDiff;

    return angleDiff;
}

float DocPostprocess::lineVerticalDist(const cv::ximgproc::SEGMENT &seg1, const cv::ximgproc::SEGMENT &seg2)
{
    Mat l;
    Mat p1(3, 1, CV_64FC1);
    Mat p2(3, 1, CV_64FC1);
    if (seg1.len < seg2.len)
    { // 将长线段投影到短线段上
        p1.at<double>(0, 0) = (double)seg2.x1;
        p1.at<double>(1, 0) = (double)seg2.y1;
        p1.at<double>(2, 0) = 1.0;

        p2.at<double>(0, 0) = (double)seg2.x2;
        p2.at<double>(1, 0) = (double)seg2.y2;
        p2.at<double>(2, 0) = 1.0;
        l = seg1.l;
    }
    else
    {
        p1.at<double>(0, 0) = (double)seg1.x1;
        p1.at<double>(1, 0) = (double)seg1.y1;
        p1.at<double>(2, 0) = 1.0;

        p2.at<double>(0, 0) = (double)seg1.x2;
        p2.at<double>(1, 0) = (double)seg1.y2;
        p2.at<double>(2, 0) = 1.0;
        l = seg2.l;
    }
    auto dist1 = (float)distPointLine(p1, l);
    auto dist2 = (float)distPointLine(p2, l);

    return cv::max(fabs(dist1), fabs(dist2));
}
bool DocPostprocess::isFilled(Mat &img, std::vector<cv::Point2f> quad)
{
    std::vector<cv::Point2f> quad_dl;
    for (int i=0; i < quad.size(); i++){
        float pt_x = MIN(quad[i].x, HANDLE_IMAGE_W - 1);
        pt_x = MAX(pt_x, 0);
        float pt_y = MIN(quad[i].y, HANDLE_IMAGE_H - 1);
        pt_y = MAX(pt_y, 0);
        Point2f pt(pt_x, pt_y);
        quad_dl.push_back(pt);
    }
    Rect rect = boundingRect(quad_dl);
    Mat roi = img(rect);

    for (auto &pt : quad_dl)
    {
        pt.x -= rect.x;
        pt.y -= rect.y;
    }

    std::vector<cv::Point> points;

    cv::Mat(quad_dl).convertTo(points, cv::Mat(points).type());
    std::vector<std::vector<cv::Point>> quads = {points};

    Mat mask = Mat::zeros(rect.height, rect.width, CV_8UC1);
    fillPoly(mask, quads, 255);
    Mat fill = roi & mask;

    int total_cnt = countNonZero(mask);
    int fill_cnt = countNonZero(fill);

    return fill_cnt * 1.0f / total_cnt > FILLED_RATIO;
}

std::vector<cv::Point2f> DocPostprocess::getSegmentsQuad(const SEGMENT &seg1, const SEGMENT &seg2)
{
    std::vector<cv::Point2f> corns = {cv::Point2f(seg1.x1, seg1.y1), cv::Point2f(seg1.x2, seg1.y2),
                                      cv::Point2f(seg2.x1, seg2.y1), cv::Point2f(seg2.x2, seg2.y2)};
    std::vector<cv::Point2f> hull;
    convexHull(corns, hull, false);
    return hull;
}

bool DocPostprocess::isVerticalLine(const SEGMENT &seg)
{

    float delta_x = fabs(seg.x1 - seg.x2);
    float delta_y = fabs(seg.y1 - seg.y2);
    return delta_y > delta_x;
}

int DocPostprocess::getPointDirectOnLine(const cv::Point2f &point, const SEGMENT &line)
{
    cv::Point p0 = cv::Point((int)line.x1, (int)line.y1);
    cv::Point p1 = cv::Point((int)line.x2, (int)line.y2);

    int min_x = MIN(p0.x, p1.x);
    int max_x = MAX(p0.x, p1.x);
    int min_y = MIN(p0.y, p1.y);
    int max_y = MAX(p0.y, p1.y);

    Point pt((int)point.x, (int)point.y);

    if (isVerticalLine(line))
    { // 竖线
        if (pt.y >= min_y && pt.y <= max_y)
        {
            return DIRECT::IN;
        }
        else if (pt.y < min_y)
        {
            return DIRECT::LEFT;
        }
        else
        {
            return DIRECT::RIGHT;
        }
    }
    else
    {
        if (pt.x >= min_x && pt.x <= max_x)
        {
            return DIRECT::IN;
        }
        else if (pt.x < min_x)
        {
            return DIRECT::LEFT;
        }
        else
        {
            return DIRECT::RIGHT;
        }
    }
}

float DocPostprocess::getPointDist(const cv::Point2f &point1, const cv::Point2f &point2)
{
    return static_cast<float>(cv::norm(point1 - point2));
}

/***
 * 获取两条线的重叠长度。 正值表示重叠长度， 负值或0表示投影点距离原线的最短距离.
 * @param seg1
 * @param seg2
 * @return
 */
float DocPostprocess::getSegmentsOverlaps(const SEGMENT &seg1, const SEGMENT &seg2, bool isReProj)
{

    SEGMENT projectL = seg1;
    SEGMENT projectedL = seg2;

    if (isReProj)
    {
        projectL = seg1.len > seg2.len ? seg2 : seg1;
        projectedL = seg1.len > seg2.len ? seg1 : seg2;
    }

    cv::Point2f p1(projectL.x1, projectL.y1);
    cv::Point2f p2(projectL.x2, projectL.y2);

    if (isReProj)
    {
        incidentPoint(projectedL.l, p1);
        incidentPoint(projectedL.l, p2);
    }

    int direct1 = getPointDirectOnLine(p1, projectedL); // 方向
    int direct2 = getPointDirectOnLine(p2, projectedL);

    if (direct1 == direct2)
    {
        if (direct1 != DIRECT::IN)
        { // 两点在线段同侧， 不包含线段
            float d1 = getPointDist(p1, Point2f(projectedL.x1, projectedL.y1));
            float d2 = getPointDist(p1, Point2f(projectedL.x2, projectedL.y2));

            float d3 = getPointDist(p2, Point2f(projectedL.x1, projectedL.y1));
            float d4 = getPointDist(p2, Point2f(projectedL.x2, projectedL.y2));
            return -min(min(min(d1, d2), d3), d4);
        }
        else
        { //两点均在线段里面
            return getPointDist(p1, p2);
        }
    }
    else
    { // 两点跨在不同段
        if (!isVerticalLine(projectedL))
        { // 横线的情况

            cv::Point2f pStart = projectedL.x1 > projectedL.x2 ? cv::Point2f(projectedL.x2, projectedL.y2)
                                                               : cv::Point2f(projectedL.x1, projectedL.y1);

            cv::Point2f pInterStart = p1.x > p2.x ? p2 : p1;

            pStart = pStart.x > pInterStart.x ? pStart : pInterStart;

            cv::Point2f pEnd = projectedL.x1 > projectedL.x2 ? cv::Point2f(projectedL.x1, projectedL.y1)
                                                             : cv::Point2f(projectedL.x2, projectedL.y2);

            cv::Point2f pInterEnd = p1.x > p2.x ? p1 : p2;

            pEnd = pEnd.x < pInterEnd.x ? pEnd : pInterEnd;

            return getPointDist(pStart, pEnd);
        }
        else
        {

            cv::Point2f pStart = projectedL.y1 > projectedL.y2 ? cv::Point2f(projectedL.x2, projectedL.y2)
                                                               : cv::Point2f(projectedL.x1, projectedL.y1);

            cv::Point2f pInterStart = p1.y > p2.y ? p2 : p1;

            pStart = pStart.y > pInterStart.y ? pStart : pInterStart;

            cv::Point2f pEnd = projectedL.y1 > projectedL.y2 ? cv::Point2f(projectedL.x1, projectedL.y1)
                                                             : cv::Point2f(projectedL.x2, projectedL.y2);

            cv::Point2f pInterEnd = p1.y > p2.y ? p1 : p2;

            pEnd = pEnd.y < pInterEnd.y ? pEnd : pInterEnd;

            return getPointDist(pStart, pEnd);
        }
    }
}

std::vector<SEGMENT> DocPostprocess::mergeCrudeSegs(Mat image, std::vector<SEGMENT> &segments)
{

    std::vector<bool> isReserved(segments.size(), true);
    sortSegment(segments);

    std::vector<SEGMENT> merges;

    for (int i = 0; i < segments.size(); i++)
    {
        if (!isReserved[i])
        {
            continue;
        }
        auto &seg_i = segments[i];
        for (int j = 0; j < segments.size(); j++)
        {
            auto &seg_j = segments[j];
            float angle = getLineAngle(seg_i, seg_j);
            if (angle > MAX_CRUDE_ANGLE)
            {
                continue;
            }

            float dist = lineVerticalDist(seg_i, seg_j);
            if (dist > MAX_CRUDE_LINE_DIST)
            {
                continue;
            }
            std::vector<Point2f> quad = getSegmentsQuad(seg_i, seg_j);

            // 两条直线靠的毕竟近而且中间的heatmap不是连续的
            if (dist > MIN_CRUDE_LINE_DIST && !isFilled(image, quad))
            {
                continue;
            }

            float overlaps = getSegmentsOverlaps(seg_i, seg_j);

            // 两条线段重叠部分太短
            if (overlaps < min(seg_i.len, seg_j.len) * MIN_CRUDE_OVERLAP_RATIO)
            {
                continue;
            }

            SEGMENT merge;
            mergeLines(seg_i, seg_j, merge);
            initSegment(merge);
            merge.type = cv::ximgproc::MERGE_CRUDE;

            merges.push_back(merge);

            isReserved[i] = false;
            isReserved[j] = false;
            break;
        }
    }

    for (int i = 0; i < segments.size(); i++)
    {
        if (isReserved[i])
        {
            merges.push_back(segments[i]);
        }
    }
    return merges;
}

void DocPostprocess::drawSegments(Mat &image, const std::vector<SEGMENT> &lines)
{
    cv::RNG rng(12456);
    int i = 0;
    for (const auto &l : lines)
    {
        Point2f b(l.x1, l.y1);
        Point2f e(l.x2, l.y2);
        cv::Scalar color;
        int thickness = 1;
        if (l.type == cv::ximgproc::RAW)
        {
            color = cv::Scalar(0, 0, 255);
        }
        else if (l.type == cv::ximgproc::AUTO_NEW)
        {
            color = cv::Scalar(0, 255, 255);
            thickness = 2;
        }
        else
        {
            color = cv::Scalar(rng.uniform(0, 256), rng.uniform(0, 256), rng.uniform(0, 256));
        }
        cv::line(image, b, e, color, thickness);
        Point2f c = (b + e) / 2;
        putText(image, std::to_string(i), c, cv::FONT_HERSHEY_PLAIN, 1, color, 1);
        i++;
    }
}

std::vector<SEGMENT> DocPostprocess::uniqueSegs(const std::vector<SEGMENT> &segments)
{
    std::vector<SEGMENT> uniques;

    for (auto &seg : segments)
    {
        bool isUnique = true;
        for (const auto &u : uniques)
        {
            if (seg == u)
            {
                isUnique = false;
                break;
            }
        }

        if (isUnique)
        {
            // 更新子段
            std::vector<SEGMENT> uniqueSub;
            for (auto &sub : seg.subSegs)
            {
                bool isSubUnique = true;
                for (const auto &us : uniqueSub)
                {
                    if (us == sub)
                    {
                        isSubUnique = false;
                        break;
                    }
                }
                if (isSubUnique)
                {
                    uniqueSub.push_back(sub);
                }
            }
            SEGMENT tmp = seg;
            tmp.subSegs = uniqueSub;
            uniques.push_back(tmp);
        }
    }

    return uniques;
}

void DocPostprocess::mergeSubSegments(SEGMENT &seg)
{
    if (seg.subSegs.empty())
    {
        return;
    }
    bool isHorizon = true;
    double delta_x = seg.x1 - seg.x2, delta_y = seg.y1 - seg.y2;
    // get horizontal lines and vertical lines respectively
    if (fabs(delta_x) < fabs(delta_y))
    {
        isHorizon = false;
    }

    sort(seg.subSegs.begin(), seg.subSegs.end(), [isHorizon](const SEGMENT &a, const SEGMENT &b) -> bool
         { return isHorizon ? a.center.x > b.center.x : a.center.y > b.center.y; });

    vector<SEGMENT> newSubs;
    for (int i = 1; i < seg.subSegs.size(); i++)
    {
        float overlap = getSegmentsOverlaps(seg.subSegs[i - 1], seg.subSegs[i]);
        if (overlap > 0)
        {
            SEGMENT merge;
            mergeLines(seg.subSegs[i - 1], seg.subSegs[i], merge);
            initSegment(merge);
            seg.subSegs[i] = merge;
        }
        else
        {
            newSubs.push_back(seg.subSegs[i - 1]);
        }
    }

    newSubs.push_back(seg.subSegs[seg.subSegs.size() - 1]);
    seg.subSegs = newSubs;
}

std::vector<SEGMENT> DocPostprocess::mergeFineSegs(Mat image, std::vector<SEGMENT> &segments)
{
    sortSegment(segments);

    // init ref
    for (int i = 0; i < segments.size(); i++)
    {
        segments[i].ref = i;
    }

    std::vector<SEGMENT> segmentRaws = segments;

    for (int i = 0; i < segments.size(); i++)
    {
        auto &seg_i = segments[i];
        for (int j = i + 1; j < segments.size(); j++)
        {
            auto &seg_j = segments[j];
            float angle = getLineAngle(seg_i, seg_j);
            if (angle > MAX_FINE_ANGLE)
            {
                continue;
            }

            float dist = lineVerticalDist(seg_i, seg_j);
            if (dist > MAX_FINE_LINE_DIST)
            {
                continue;
            }

            float overlaps = getSegmentsOverlaps(seg_i, seg_j);

            if (overlaps < 0 && fabs(overlaps) > MIN_FINE_OVERLAP_RATIO * (seg_i.len + seg_j.len))
            {
                continue;
            }

            SEGMENT merge;
            mergeLines(seg_i, seg_j, merge);
            initSegment(merge);
            merge.type = cv::ximgproc::MERGE_FINE;
            merge.ref = seg_i.ref;
            seg_i = merge;
            seg_j = merge;
        }
    }

    // update same ref
    std::vector<std::vector<SEGMENT>> fineSubMerges(segments.size());
    std::vector<SEGMENT> merges;

    for (int i = segments.size() - 1; i >= 0; i--)
    {
        if (segments[i].type == cv::ximgproc::MERGE_FINE)
        {
            if (fineSubMerges[segments[i].ref].empty())
            {
                segments[segments[i].ref] = segments[i];
            }
            fineSubMerges[segments[i].ref].push_back(segmentRaws[i]);
        }
        else
        {
            merges.push_back(segmentRaws[i]);
        }
    }

    // init subSegs
    for (int i = 0; i < fineSubMerges.size(); i++)
    {
        if (!fineSubMerges[i].empty())
        {
            segments[i].subSegs = fineSubMerges[i];
            merges.push_back(segments[i]);
        }
    }

    segments = uniqueSegs(segments);

    for (auto &seg : segments)
    {
        mergeSubSegments(seg);
    }

    return segments;
}

void DocPostprocess::filterSegs(std::vector<SEGMENT> &segments)
{
    std::vector<SEGMENT> filter;
    for (auto &seg : segments)
    {
        if (seg.len >= MIN_LINE_LEN)
        {
            filter.push_back(seg);
        }
    }

    sortSegment(filter);
    if (filter.size() > MAX_LINE_NUM)
    {
        filter.resize(MAX_LINE_NUM);
    }
    segments = filter;
}

bool DocPostprocess::getSegmentIntersection(const SEGMENT &line_a, const SEGMENT &line_b, cv::Point2f &intersection)
{
    Mat inter = line_a.l.cross(line_b.l);

    if (inter.at<double>(2, 0) == 0)
        return false; // 两条直线平行
    else
    {
        intersection.x = inter.at<double>(0, 0) / inter.at<double>(2, 0);
        intersection.y = inter.at<double>(1, 0) / inter.at<double>(2, 0);
        return true;
    }
}

bool DocPostprocess::isPointOnLine(const cv::Point2f &point, const SEGMENT &line)
{
    cv::Point2f p0 = cv::Point2f(line.x1, line.y1);
    cv::Point2f p1 = cv::Point2f(line.x2, line.y2);

    float min_x = MIN(p0.x, p1.x);
    float max_x = MAX(p0.x, p1.x);
    float min_y = MIN(p0.y, p1.y);
    float max_y = MAX(p0.y, p1.y);

    return point.x >= min_x && point.x <= max_x && point.y >= min_y && point.y <= max_y;
}

bool DocPostprocess::testCornerInBoard(const CORNER &corner, const cv::Size &size, bool canOut)
{
    int w = size.width;
    int h = size.height;
    if (canOut)
    {
        return corner.pt.x > -(w / 3.) && corner.pt.x < (w / 3.) + w && corner.pt.y > -(h / 3.) &&
               corner.pt.y < (h / 3.) + h;
    }
    else
    {
        return corner.pt.x >= 0 && corner.pt.x < w && corner.pt.y >= 0 && corner.pt.y < h;
    }
}

void DocPostprocess::calcCorners(const cv::Size &boardSize, const std::vector<SEGMENT> &segs,
                                 std::vector<CORNER> &corners, bool isLoose)
{

    std::vector<std::vector<int>> lineWithCornerIds(segs.size());
    for (int i = 0; i < segs.size(); i++)
    {
        auto seg_i = segs[i];
        for (int j = i + 1; j < segs.size(); j++)
        {
            auto seg_j = segs[j];

            float angle = getLineAngle(seg_i, seg_j);
            if (angle < MIN_CORNER_ANGLE)
            {
                continue;
            }

            // 如果两条直线平行，那么直接跳过
            cv::Point2f cornerPt;
            if (!getSegmentIntersection(seg_i, seg_j, cornerPt))
            {
                continue;
            }

            float miss1 = 0, miss2 = 0;
            float miss1Ratio = 0, miss2Ratio = 0;
            if (!isPointOnLine(cornerPt, seg_i))
            {
                float dist1 = getPointDist(cornerPt, Point2f(seg_i.x1, seg_i.y1));
                float dist2 = getPointDist(cornerPt, Point2f(seg_i.x2, seg_i.y2));
                miss1Ratio += min(dist1, dist2) / seg_i.len;
                miss1 += min(dist1, dist2);
            }

            if (!isPointOnLine(cornerPt, seg_j))
            {
                float dist1 = getPointDist(cornerPt, Point2f(seg_j.x1, seg_j.y1));
                float dist2 = getPointDist(cornerPt, Point2f(seg_j.x2, seg_j.y2));
                miss2Ratio += min(dist1, dist2) / seg_j.len;
                miss2 += min(dist1, dist2);
            }

            CORNER corner = CORNER();
            corner.lineIds.push_back(i);
            corner.lineIds.push_back(j);
            corner.pt = cornerPt;

            bool isIn = testCornerInBoard(corner, boardSize, false);
            float blank_ratio = !isIn ? MIN_CORNER_BLANK_RATIO_OUTBOARD : MIN_CORNER_BLANK_RATIO;
            blank_ratio = isLoose ? MIN_CORNER_BLANK_RATIO_LOOSE : blank_ratio;

            if ((miss1Ratio > blank_ratio || miss2Ratio > blank_ratio))
            {
                continue;
            }

            float minLen = min(seg_i.len, seg_j.len);
            float maxLen = max(seg_i.len, seg_j.len);

            float two_line_ratio = isLoose ? MIN_CORNER_TWO_LINE_RATIO_LOOSE : MIN_CORNER_TWO_LINE_RATIO;
            if ((minLen / maxLen <= two_line_ratio))
            {
                continue;
            }

            if (!testCornerInBoard(corner, boardSize))
            {
                continue;
            }

            corner.score += (miss1Ratio + miss2Ratio);
            corners.push_back(corner);
            lineWithCornerIds[i].push_back(corners.size() - 1);
            lineWithCornerIds[j].push_back(corners.size() - 1);
        }
    }

    sort(corners.begin(), corners.end(), [](const CORNER &a, const CORNER &b) -> bool
         { return a.score < b.score; });

    if (corners.size() > MAX_CORNER_NUM)
    {
        corners.resize(MAX_CORNER_NUM);
    }
}

void DocPostprocess::drawCorners(Mat &image, const std::vector<CORNER> &corners)
{
    int w = image.size().width;
    int h = image.size().height;
    for (const auto &c : corners)
    {
        if (c.pt.x < 0 || c.pt.x > (w - 1) || c.pt.y < 0 || c.pt.y > (h - 1))
        {
            continue;
        }
        circle(image, c.pt, 3, cv::Scalar(0, 255, 0), -1, 8);
    }
}

void DocPostprocess::getBoardLine(std::vector<SEGMENT> &segs)
{
    SEGMENT top(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING,
                HANDLE_IMAGE_PADDING);

    SEGMENT bottom(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING,
                   HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);

    SEGMENT left(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING,
                 HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);

    SEGMENT right(HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING,
                  HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);

    segs = {top, bottom, left, right};
    for (auto &b : segs)
    {
        initSegment(b);
    }
    return;
}

bool DocPostprocess::calcEdgeQuad(const cv::Size &boardSize, const std::vector<SEGMENT> &segs,
                                  const std::vector<CORNER> &corners, std::vector<cv::Point2f> &quad)
{
    if (segs.size() < 2)
    {
        return false;
    }

    float right_angle = 90.0;
    int corner_size = corners.size();
    for (int i = 0; i < corner_size; i++)
    {
        SEGMENT seg1 = segs[corners[i].lineIds[0]];
        SEGMENT seg2 = segs[corners[i].lineIds[1]];
        if (seg1.len < boardSize.height / 3 || seg2.len < boardSize.width / 3)
        {
            continue;
        }
        float angle = getLineAngle(seg1, seg2);
        if (angle - right_angle > EDGE_QUAD_TWO_STRAIGHT_SEG_DELTA_ANGEL)
        {
            continue;
        }

        float seg1_d1 = getPointDist(corners[i].pt, Point2f(seg1.x1, seg1.y1));
        float seg1_d2 = getPointDist(corners[i].pt, Point2f(seg1.x2, seg1.y2));
        float seg2_d1 = getPointDist(corners[i].pt, Point2f(seg2.x1, seg2.y1));
        float seg2_d2 = getPointDist(corners[i].pt, Point2f(seg2.x2, seg2.y2));
        if (fabs(MAX(seg1_d1, seg1_d2) - seg1.len) > EDGE_QUAD_SEG_NO_OVERLAP_DIST ||
            fabs(MAX(seg2_d1, seg2_d2) - seg2.len) > EDGE_QUAD_SEG_NO_OVERLAP_DIST)
        {
            continue;
        }

        Point2f seg1_far_pt = seg1_d1 > seg1_d2 ? Point2f(seg1.x1, seg1.y1) : Point2f(seg1.x2, seg1.y2);
        Point2f seg2_far_pt = seg2_d1 > seg2_d2 ? Point2f(seg2.x1, seg2.y1) : Point2f(seg2.x2, seg2.y2);

        std::vector<SEGMENT> boards;
        getBoardLine(boards); // 边界4条边
        Mat p1 = Mat(3, 1, CV_64FC1);
        Mat p2 = Mat(3, 1, CV_64FC1);
        p1.at<double>(0, 0) = (double)seg1_far_pt.x;
        p1.at<double>(1, 0) = (double)seg1_far_pt.y;
        p1.at<double>(2, 0) = 1.0;
        p2.at<double>(0, 0) = (double)seg2_far_pt.x;
        p2.at<double>(1, 0) = (double)seg2_far_pt.y;
        p2.at<double>(2, 0) = 1.0;
        float min_dis_p1 = (float)LARGE_NUM;
        float min_dis_p2 = (float)LARGE_NUM;
        int min_dis_p1_id = 0;
        int min_dis_p2_id = 0;
        for (int i = 0; i < boards.size(); i++)
        {
            float dis_p1 = fabs(distPointLine(p1, boards[i].l));
            if (min_dis_p1 > dis_p1)
            {
                min_dis_p1 = dis_p1;
                min_dis_p1_id = i;
            }
            float dis_p2 = fabs(distPointLine(p2, boards[i].l));
            if (min_dis_p2 > dis_p2)
            {
                min_dis_p2 = dis_p2;
                min_dis_p2_id = i;
            }
        }
        if (min_dis_p1 > EDGE_QUAD_SEG_TO_EDGE_DIST || min_dis_p2 > EDGE_QUAD_SEG_TO_EDGE_DIST)
        {
            continue;
        }

        bool noNearLine = true;
        for (int j = 0; j < segs.size(); j++)
        {
            if (j != corners[i].lineIds[0] && j != corners[i].lineIds[1])
            {
                p1.at<double>(0, 0) = (double)segs[j].x1;
                p1.at<double>(1, 0) = (double)segs[j].y1;
                p1.at<double>(2, 0) = 1.0;
                p2.at<double>(0, 0) = (double)segs[j].x2;
                p2.at<double>(1, 0) = (double)segs[j].y2;
                p2.at<double>(2, 0) = 1.0;
                float dis_p1_seg1 = fabs(distPointLine(p1, seg1.l));
                float dis_p2_seg1 = fabs(distPointLine(p1, seg2.l));
                float dis_p1_seg2 = fabs(distPointLine(p2, seg1.l));
                float dis_p2_seg2 = fabs(distPointLine(p2, seg2.l));
                if (MIN(MIN(MIN(dis_p1_seg1, dis_p2_seg1), dis_p1_seg2), dis_p2_seg2) < EDGE_QUAD_PT_TO_SEG_DIST)
                {
                    noNearLine = false;
                    break;
                }
            }
        }
        if (!noNearLine)
        {
            continue;
        }

        SEGMENT edge1 = boards[min_dis_p1_id];
        SEGMENT edge2 = boards[min_dis_p2_id];
        if (getLineAngle(edge1, edge2) - right_angle > EDGE_QUAD_TWO_EDGE_DELTA_ANGEL)
        {
            continue;
        }
        cv::Point2f edge_pt;
        if (!getSegmentIntersection(edge1, edge2, edge_pt))
        {
            continue;
        }

        std::vector<cv::Point2f> quad_pts = {corners[i].pt, seg1_far_pt, seg2_far_pt, edge_pt};
        std::vector<int> hull;
        convexHull(quad_pts, hull, false, false);
        if (hull.size() != quad_pts.size())
        {
            continue;
        }
        for (int i = 0; i < hull.size(); i++)
        {
            quad.push_back(quad_pts[hull[i]]);
        }
        for (auto &pt : quad)
        {
            pt.x -= HANDLE_IMAGE_PADDING;
            pt.y -= HANDLE_IMAGE_PADDING;
            pt.x *= (imageW_ * 1.0f / HANDLE_REAL_W);
            pt.y *= (imageH_ * 1.0f / HANDLE_REAL_H);
        }
        if (!quad.empty())
        {
            // std::cout << "边缘case" << std::endl;
            return true;
        }
    }
    return false;
}

bool DocPostprocess::checkEnoughPoints(const CORNER &corner, const std::vector<std::vector<int>> &segCornerInfo)
{
    bool hasEnoughPts = true;
    for (auto l_id : corner.lineIds)
    {
        if (segCornerInfo[l_id].size() < 2)
        {
            hasEnoughPts = false;
            break;
        }
    }
    return hasEnoughPts;
}

int DocPostprocess::findCornersLine(const CORNER &c1, const CORNER &c2)
{
    for (auto l1 : c1.lineIds)
    {
        for (auto l2 : c2.lineIds)
        {
            if (l1 == l2)
            {
                return l1;
            }
        }
    }
    return -1;
}

bool isConvexQuad(std::vector<CORNER> &corners)
{
    if (corners.size() != QUAD_CORNER_NUM)
    {
        return false;
    }

    std::vector<cv::Point2f> quads = {corners[0].pt, corners[1].pt, corners[2].pt, corners[3].pt};
    std::vector<int> hull;
    convexHull(quads, hull, false, false);

    if (hull.size() != QUAD_CORNER_NUM)
    {
        return false;
    }

    std::vector<CORNER> newCorners(QUAD_CORNER_NUM);
    for (int i = 0; i < hull.size(); i++)
    {
        newCorners[i] = corners[hull[i]];
    }

    corners = newCorners;
    return true;
}

void DocPostprocess::calcQuad(const cv::Size &boardSize, const std::vector<SEGMENT> &segs,
                              const std::vector<CORNER> &corners, std::vector<QUAD> &quads, bool isLoose)
{
    if (corners.size() < QUAD_CORNER_NUM)
    {
        return;
    }

    std::vector<std::vector<int>> segCornerIds(segs.size());

    for (int i = 0; i < corners.size(); i++)
    {
        segCornerIds[corners[i].lineIds[0]].push_back(i);
        segCornerIds[corners[i].lineIds[1]].push_back(i);
    }

    Graph graph;

    for (int i = 0; i < corners.size(); i++)
    {
        auto &c_i = corners[i];
        bool isCiIn = testCornerInBoard(c_i, boardSize, false);
        if (!checkEnoughPoints(c_i, segCornerIds))
        { // 点所在的两条线上，需要有2个或以上的点才有意义
            continue;
        }

        for (int j = i + 1; j < corners.size(); j++)
        {
            auto &c_j = corners[j];

            int lineId = findCornersLine(c_i, c_j); // 两个角点组成的直线id
            if (lineId < 0)
            {
                continue;
            }

            float dist = getPointDist(c_i.pt, c_j.pt); // 脚点距离
            if (dist < MIN_CORNER_DIST)
            {
                continue;
            }

            SEGMENT seg_tmp(c_i.pt, c_j.pt);

            bool isCjIn = testCornerInBoard(c_j, boardSize, false); // c_i?

            float overlapsRatio = (!isCiIn || !isCjIn) ? DOTTED_SOLID_LINE_RATIO_OUTBOARD : DOTTED_SOLID_LINE_RATIO;
            overlapsRatio = isLoose ? DOTTED_SOLID_LINE_RATIO_LOOSE : overlapsRatio;

            float overlaps = getSegmentsOverlaps(seg_tmp, segs[lineId], false);
            if ((overlaps / dist) < overlapsRatio)
            { //重叠的占比
                continue;
            }

            graph.addEdge(i, j);
        }
    }

    // std::cout << "edges:" << graph.edgeNum() << std::endl;

    vector<std::vector<vertex_t>> cycles = graph.findCyclesFast(QUAD_CORNER_NUM);
    // std::cout << "找到" << cycles.size() << "quads" << std::endl;

    for (auto &cycle : cycles)
    {
        std::vector<CORNER> quadCorners;
        std::set<int> lines; // 存储线段的索引
        for (auto &v : cycle)
        {
            quadCorners.push_back(corners[v]);
            lines.emplace(corners[v].lineIds[0]);
            lines.emplace(corners[v].lineIds[1]);
        }

        if (lines.size() != QUAD_CORNER_NUM)
        { // 有可能四个点都在一条直线上
            continue;
        }
        if (!isConvexQuad(quadCorners))
        {
            continue;
        }

        float overlaps = 0;
        float perimeter = 0;
        bool isValidQuad = true;
        for (int i = 0; i < quadCorners.size(); i++)
        {
            CORNER last_c = quadCorners[(i + QUAD_CORNER_NUM - 1) % QUAD_CORNER_NUM];
            CORNER now_c = quadCorners[i];
            CORNER next_c = quadCorners[(i + 1) % QUAD_CORNER_NUM];

            int lineId = findCornersLine(now_c, next_c); // 线段的索引
            if (lineId < 0)
            {
                isValidQuad = false;
                break;
            }

            SEGMENT seg1(last_c.pt, now_c.pt);
            SEGMENT seg2(now_c.pt, next_c.pt);
            initSegment(seg1);
            initSegment(seg2);

            float a = getLineAngle(seg1, seg2);
            if (a <= MIN_CORNER_ANGLE)
            {
                isValidQuad = false;
                break;
            }

            //=============================================================//
            SEGMENT seg_tmp(now_c.pt, next_c.pt);
            if (!segs[lineId].subSegs.empty())
            {
                for (auto &sub : segs[lineId].subSegs)
                {
                    float o = getSegmentsOverlaps(seg_tmp, sub, false); // 重叠部分
                    if (o > 0)
                    {
                        overlaps += o;
                        overlaps -= QUAD_EXCEED_LINE_PUNISH * (sub.len - o); //将多出来的部分作为惩罚项
                    }
                }
            }
            else
            {
                if (segs[lineId].type != cv::ximgproc::AUTO_NEW)
                { // 自动脑补的线不计入分数
                    float o = getSegmentsOverlaps(seg_tmp, segs[lineId], false);
                    if (o > 0)
                    {
                        overlaps += o;
                        overlaps -= QUAD_EXCEED_LINE_PUNISH * (segs[lineId].len - o); //将多出来的部分作为惩罚项
                    }
                }
            }
            if (segs[lineId].type != cv::ximgproc::AUTO_NEW)
            {
                perimeter += getPointDist(now_c.pt, next_c.pt);
            }
        }

        if (!isValidQuad)
        {
            continue;
        }

        QUAD quad;
        quad.corners = quadCorners;
        quad.score = overlaps - QUAD_BLANK_SCORE_PUNISH * (perimeter - overlaps); // 实线 - 留白
        quads.push_back(quad);
    }
}

void DocPostprocess::drawQuads(Mat &image, const std::vector<QUAD> &quads)
{
    int w = image.size().width;
    int h = image.size().height;
    cv::RNG rng(1245);
    int qId = 0;
    // std::cout << "一共有" << quads.size() << "个多边形" << std::endl;
    for (const auto &quad : quads)
    {
        cv::Scalar color =
            cv::Scalar(rng.uniform(50, 256), rng.uniform(50, 256), rng.uniform(50, 256)); // Scalar(0, 255, 0)
        std::vector<Point> contour;
        for (int i = 0; i < quad.corners.size(); i++)
        {
            line(image, quad.corners[i].pt, quad.corners[(i + 1) % QUAD_CORNER_NUM].pt, color, 2);
            contour.push_back(quad.corners[i].pt);
        }

        cv::Moments mu = moments(contour, false);
        Point2f c(mu.m10 / mu.m00, mu.m01 / mu.m00);
        putText(image, std::to_string(qId), c, cv::FONT_HERSHEY_PLAIN, 1, color, 1);
        qId++;
    }
}

void DocPostprocess::drawQuad(Mat &image, const std::vector<Point2f> &quads)
{
    int w = image.size().width;
    int h = image.size().height;
    cv::RNG rng(123);
    cv::Scalar color =
        cv::Scalar(rng.uniform(50, 256), rng.uniform(50, 256), rng.uniform(50, 256)); // Scalar(0, 255, 0)

    for (int i = 0; i < quads.size(); i++)
    {
        line(image, quads[i], quads[(i + 1) % QUAD_CORNER_NUM], color, 2);
    }
}

QUAD DocPostprocess::chooseBestQuad(std::vector<QUAD> &quads)
{
    return *std::max_element(quads.begin(), quads.end(),
                             [](const QUAD &a, const QUAD &b) -> bool
                             { return a.score < b.score; });
}

void DocPostprocess::addBoardLine(std::vector<SEGMENT> &segs)
{
    std::vector<SEGMENT> boards;
    getBoardLine(boards);

    vector<SEGMENT> boardLines;
    for (auto &b : boards)
    {
        vector<Point2f> inters;
        for (auto &seg : segs)
        {
            Point2f inter;
            if (!getSegmentIntersection(seg, b, inter))
            {
                continue;
            }

            if (!isPointOnLine(inter, b))
            {
                continue;
            }

            float d1 = getPointDist(inter, Point2f(seg.x1, seg.y1));
            float d2 = getPointDist(inter, Point2f(seg.x2, seg.y2));

            if (min(d1, d2) <= MIN_BOARD_LINE_DIST)
            { //边界线和其他线段构成的实点, push进入
                inters.push_back(inter);
            }
        }

        if (inters.size() >= 2)
        {
            // minX 存储的是最左边的交点坐标 minY同理 maxX 存储的是最右边的交点坐标 maxY
            Point2f minX(LARGE_NUM, LARGE_NUM), minY(LARGE_NUM, LARGE_NUM), maxX(-1, -1), maxY(-1, -1);
            for (auto &in : inters)
            {
                if (minX.x >= in.x)
                {
                    minX = in;
                }
                if (minY.y >= in.y)
                {
                    minY = in;
                }

                if (maxX.x <= in.x)
                {
                    maxX = in;
                }
                if (maxY.y <= in.y)
                {
                    maxY = in;
                }
            }

            float d1 = maxX.x - minX.x;
            float d2 = maxY.y - minY.y;
            SEGMENT boardLine = d1 > d2 ? SEGMENT(minX, maxX) : SEGMENT(minY, maxY);
            initSegment(boardLine);
            boardLine.type = cv::ximgproc::AUTO_NEW;
            bool isExist = false;
            for (auto &seg : segs)
            { //判断没有和boardLine类似的线
                if (lineVerticalDist(seg, boardLine) < MIN_BOARD_LINE_EXIST_DIST &&
                    getLineAngle(seg, boardLine) < MIN_BOARD_LINE_EXIST_ANGLE &&
                    min(seg.len, boardLine.len) / max(seg.len, boardLine.len) > MIN_BOARD_LINE_EXIST_RATIO)
                {
                    isExist = true;
                    break;
                }
            }
            if (!isExist)
            {
                boardLines.push_back(boardLine);
            }
        }
    }

    segs.insert(segs.end(), boardLines.begin(), boardLines.end());
}

bool DocPostprocess::tryQuadWithBoardLine(const std::vector<SEGMENT> &inSegs, const std::vector<CORNER> &inCorners,
                                          std::vector<SEGMENT> &outSegs, std::vector<CORNER> &outCorners,
                                          std::vector<QUAD> &quads)
{
    outSegs = inSegs;
    addBoardLine(outSegs);
    if (outSegs.size() != inSegs.size())
    { // 说明添加了线段
        calcCorners(cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H), outSegs, outCorners);
        calcQuad(cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H), outSegs, outCorners, quads);

        return true;
    }
    return false;
}

void DocPostprocess::sortSegments(std::vector<SEGMENT> &segments)
{
    sort(segments.begin(), segments.end(), [](const SEGMENT &a, const SEGMENT &b) -> bool
         { return a.len > b.len; });
}

bool DocPostprocess::isSegmentIntersection(const SEGMENT &line_a, const SEGMENT &line_b)
{
    Mat inter = line_a.l.cross(line_b.l);
    Point2f intersection;

    if (inter.at<double>(2, 0) == 0)
    {
        return lineVerticalDist(line_a, line_b) <= MIN_LINE_LEN;
    }
    else
    {
        intersection.x = inter.at<double>(0, 0) / inter.at<double>(2, 0);
        intersection.y = inter.at<double>(1, 0) / inter.at<double>(2, 0);

        if (isPointOnLine(intersection, line_a) || isPointOnLine(intersection, line_b))
        {
            return true;
        }
        return false;
    }
}

void DocPostprocess::addMoreSegs(const vector<SEGMENT> &in, vector<SEGMENT> &out)
{
    for (int i = 0; i < in.size(); i++)
    {
        auto &seg_i = in[i];
        for (int j = i + 1; j < in.size(); j++)
        {
            auto &seg_j = in[j];
            if (isSegmentIntersection(seg_i, seg_j))
            {
                continue;
            }
            float d1 = min(seg_i.len, seg_j.len);
            float d2 = max(seg_i.len, seg_j.len);
            if (d1 / d2 < QUAD_SEG_LEN_RATIO)
            {
                continue;
            }

            SEGMENT seg1(seg_i.x1, seg_i.y1, seg_j.x1, seg_j.y1);
            initSegment(seg1);
            seg1.type = cv::ximgproc::AUTO_NEW;
            SEGMENT seg2(seg_i.x2, seg_i.y2, seg_j.x2, seg_j.y2);
            initSegment(seg2);
            seg2.type = cv::ximgproc::AUTO_NEW;

            if (getLineAngle(seg1, seg_i) < MIN_CORNER_ANGLE || getLineAngle(seg2, seg_i) < MIN_CORNER_ANGLE ||
                getLineAngle(seg1, seg_j) < MIN_CORNER_ANGLE || getLineAngle(seg1, seg_j) < MIN_CORNER_ANGLE)
            {
                continue;
            }

            bool isExist1 = false;
            bool isExist2 = false;
            for (auto &o : out)
            {
                if (getLineAngle(o, seg1) <= MIN_BOARD_LINE_EXIST_ANGLE &&
                    lineVerticalDist(o, seg1) <= MIN_BOARD_LINE_EXIST_DIST &&
                    min(o.len, seg1.len) / max(o.len, seg1.len) >= MIN_BOARD_LINE_EXIST_RATIO)
                {
                    isExist1 = true;
                }

                if (getLineAngle(o, seg2) <= MIN_BOARD_LINE_EXIST_ANGLE &&
                    lineVerticalDist(o, seg2) <= MIN_BOARD_LINE_EXIST_DIST &&
                    min(o.len, seg2.len) / max(o.len, seg2.len) >= MIN_BOARD_LINE_EXIST_RATIO)
                {
                    isExist2 = true;
                }
            }

            if (!isExist1 && seg1.len > CORNER_CASE_LINE_LEN)
            {
                out.push_back(seg1);
            }

            if (!isExist2 && seg2.len > CORNER_CASE_LINE_LEN)
            {
                out.push_back(seg2);
            }
        }
    }
}

void DocPostprocess::addVertexSegs(const std::vector<SEGMENT> &inSegs, std::vector<SEGMENT> &outSegs,
                                   std::vector<CORNER> &outCorners)
{
    // inSegs: 添加边界线后的线段
    vector<SEGMENT> horizontals; // 存储水平的线段
    vector<SEGMENT> verticals;   // 存储垂直的线段
    for (const auto &seg : inSegs)
    {
        if (seg.len < CORNER_CASE_LINE_LEN)
        {
            continue;
        }

        SEGMENT seg_tmp = seg;
        seg_tmp.sort();
        double delta_x = seg.x1 - seg.x2, delta_y = seg.y1 - seg.y2;
        // get horizontal lines and vertical lines respectively
        if (fabs(delta_x) > fabs(delta_y))
        {
            horizontals.push_back(seg_tmp);
        }
        else
        {
            verticals.push_back(seg_tmp);
        }
    }

    sortSegments(horizontals); //长边在前
    sortSegments(verticals);

    vector<SEGMENT> horizontalTmp = horizontals;
    vector<SEGMENT> verticalsTmp = verticals;

    if (horizontalTmp.size() > CORNER_CASE_MAX_AUTO_NEW_LINE)
    {
        horizontalTmp.resize(CORNER_CASE_MAX_AUTO_NEW_LINE);
    }
    if (verticalsTmp.size() > CORNER_CASE_MAX_AUTO_NEW_LINE)
    {
        verticalsTmp.resize(CORNER_CASE_MAX_AUTO_NEW_LINE);
    }

    addMoreSegs(verticalsTmp, horizontals);
    if (horizontals.size() < 2)
    {
        SEGMENT top(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING,
                    HANDLE_IMAGE_PADDING);

        SEGMENT bottom(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING,
                       HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);
        initSegment(top);
        initSegment(bottom);
        top.type = cv::ximgproc::AUTO_NEW;
        bottom.type = cv::ximgproc::AUTO_NEW;
        if (horizontals.empty())
        {
            horizontals.push_back(top);
            horizontals.push_back(bottom);
        }
        else
        {
            horizontals.push_back(bottom);
        }
    }

    addMoreSegs(horizontalTmp, verticals);
    if (verticals.size() < 2)
    {
        SEGMENT left(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING,
                     HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);

        SEGMENT right(HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING,
                      HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING);
        initSegment(left);
        initSegment(right);
        left.type = cv::ximgproc::AUTO_NEW;
        right.type = cv::ximgproc::AUTO_NEW;
        if (verticals.empty())
        {
            verticals.push_back(left);
            verticals.push_back(right);
        }
        else
        {
            verticals.push_back(right);
        }
    }

    sortSegments(horizontals);
    sortSegments(verticals);

    outSegs = horizontals;
    outSegs.insert(outSegs.end(), verticals.begin(), verticals.end());
    int startVIdx = horizontals.size();

    for (int i = 0; i < horizontals.size(); i++)
    {
        auto seg_h = horizontals[i];
        for (int j = 0; j < verticals.size(); j++)
        {
            auto seg_v = verticals[j];

            float angle = getLineAngle(seg_h, seg_v);
            if (angle < MIN_CORNER_ANGLE)
            {
                continue;
            }

            cv::Point2f cornerPt;
            if (!getSegmentIntersection(seg_h, seg_v, cornerPt))
            {
                continue;
            }

            float miss1Ratio = 0, miss2Ratio = 0;
            if (!isPointOnLine(cornerPt, seg_h))
            {
                float dist1 = getPointDist(cornerPt, Point2f(seg_h.x1, seg_h.y1));
                float dist2 = getPointDist(cornerPt, Point2f(seg_h.x2, seg_h.y2));
                miss1Ratio += min(dist1, dist2) / seg_h.len;
            }

            if (!isPointOnLine(cornerPt, seg_v))
            {
                float dist1 = getPointDist(cornerPt, Point2f(seg_v.x1, seg_v.y1));
                float dist2 = getPointDist(cornerPt, Point2f(seg_v.x2, seg_v.y2));
                miss2Ratio += min(dist1, dist2) / seg_v.len;
            }

            CORNER corner = CORNER();
            corner.lineIds.push_back(i);
            corner.lineIds.push_back(startVIdx + j);
            corner.pt = cornerPt;

            bool isIn = testCornerInBoard(corner, cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H), false);
            float blank_ratio = !isIn ? MIN_CORNER_BLANK_RATIO_OUTBOARD : MIN_CORNER_BLANK_RATIO;

            if ((miss1Ratio > blank_ratio || miss2Ratio > blank_ratio))
            {
                continue;
            }

            float minLen = min(seg_h.len, seg_v.len);
            float maxLen = max(seg_h.len, seg_v.len);

            float two_line_ratio = MIN_CORNER_TWO_LINE_RATIO;
            if ((minLen / maxLen <= two_line_ratio))
            {
                continue;
            }

            if (!testCornerInBoard(corner, cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H)))
            {
                continue;
            }

            corner.score += (miss1Ratio + miss2Ratio);
            outCorners.push_back(corner);
        }
    }

    sort(outCorners.begin(), outCorners.end(),
         [](const CORNER &a, const CORNER &b) -> bool
         { return a.score < b.score; });

    if (outCorners.size() > MAX_CORNER_NUM)
    {
        outCorners.resize(MAX_CORNER_NUM);
    }

    return;
};

bool DocPostprocess::isTrapezoid(const QUAD &quad, const std::vector<SEGMENT> &segs, bool isLoose)
{

    vector<CORNER> quadCorners = quad.corners;
    vector<SEGMENT> quadSegs;
    for (int i = 0; i < quadCorners.size(); ++i)
    {
        CORNER now_c = quadCorners[i];
        CORNER next_c = quadCorners[(i + 1) % QUAD_CORNER_NUM];
        SEGMENT seg = SEGMENT(now_c.pt, next_c.pt);
        initSegment(seg);
        seg.type = cv::ximgproc::AUTO_NEW;
        quadSegs.push_back(seg);
    }
    float angDiff1 = getLineAngle(quadSegs[0], quadSegs[2]);
    float angDiff2 = getLineAngle(quadSegs[1], quadSegs[3]);
    float angleOffset = isLoose ? QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET_LOOSE : QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET;
    if (fabs(angDiff1 - angDiff2) > angleOffset)
    {
        return true;
    }
    else if (min(angDiff1, angDiff2) > QUAD_TWO_PARALLEL_LINE_MIN_ANGLE)
    {
        return true;
    }
    return false;
}

std::pair<DIRECT, SEGMENT> DocPostprocess::chooseLongestSegment(vector<std::pair<DIRECT, SEGMENT>> &segs)
{
    return *std::max_element(segs.begin(), segs.end(),
                             [](const std::pair<DIRECT, SEGMENT> &a, const std::pair<DIRECT, SEGMENT> &b) -> bool
                             {
                                 return a.second.len < b.second.len;
                             });
}

void DocPostprocess::addExtendNearEdgeSegs(const std::vector<SEGMENT> &inSegs, const std::vector<CORNER> &corners,
                                           std::vector<SEGMENT> &outSegs)
{

    std::vector<SEGMENT> boards;
    getBoardLine(boards);
    vector<vector<std::pair<DIRECT, SEGMENT>>> dirSegsWithId(4);
    for (int i = 0; i < inSegs.size(); ++i)
    {
        vector<float> boardAngles;
        for (int j = 0; j < boards.size(); ++j)
        {
            float angle = getLineAngle(inSegs[i], boards[j]);
            boardAngles.push_back(angle);
        }
        if (min(inSegs[i].y1, inSegs[i].y2) < NEAR_BOARD_PADDING &&
            boardAngles[DIRECT::TOP] < MAX_NEAR_BOARDLINE_ANGLE && inSegs[i].len > MIN_NEAR_BOARDLINE_LENGHT)
        {
            dirSegsWithId[DIRECT::TOP].push_back(std::pair<DIRECT, SEGMENT>(DIRECT::TOP, inSegs[i]));
        }
        else if (max(inSegs[i].y1, inSegs[i].y2) > HANDLE_IMAGE_W - NEAR_BOARD_PADDING &&
                 boardAngles[DIRECT::BOTTOM] < MAX_NEAR_BOARDLINE_ANGLE &&
                 inSegs[i].len > MIN_NEAR_BOARDLINE_LENGHT)
        {
            dirSegsWithId[DIRECT::BOTTOM].push_back(std::pair<DIRECT, SEGMENT>(DIRECT::BOTTOM, inSegs[i]));
        }
        else if (min(inSegs[i].x1, inSegs[i].x2) < NEAR_BOARD_PADDING &&
                 boardAngles[DIRECT::LEFT] < MAX_NEAR_BOARDLINE_ANGLE && inSegs[i].len > MIN_NEAR_BOARDLINE_LENGHT)
        {
            dirSegsWithId[DIRECT::LEFT].push_back(std::pair<DIRECT, SEGMENT>(DIRECT::LEFT, inSegs[i]));
        }
        else if (max(inSegs[i].x1, inSegs[i].x2) > HANDLE_IMAGE_W - NEAR_BOARD_PADDING &&
                 boardAngles[DIRECT::RIGHT] < MAX_NEAR_BOARDLINE_ANGLE && inSegs[i].len > MIN_NEAR_BOARDLINE_LENGHT)
        {
            dirSegsWithId[DIRECT::RIGHT].push_back(std::pair<DIRECT, SEGMENT>(DIRECT::RIGHT, inSegs[i]));
        }
        else
        {
            outSegs.push_back(inSegs[i]);
        }
    }

    vector<std::pair<int, SEGMENT>> needExpandLinesWithId;
    for (int dir = 0; dir < dirSegsWithId.size(); ++dir)
    {
        if (!dirSegsWithId[dir].empty())
        {
            std::pair<DIRECT, SEGMENT> nearBoardSegWithId = chooseLongestSegment(dirSegsWithId[dir]);
            needExpandLinesWithId.push_back(nearBoardSegWithId);
        }
    }

    if (needExpandLinesWithId.empty())
    {
        return;
    }
    // 两端都有交点：不延伸; 两端无交点：两侧同时延伸; 一侧有交点：延伸另一侧
    for (int i = 0; i < needExpandLinesWithId.size(); ++i)
    {
        int direct = needExpandLinesWithId[i].first;
        SEGMENT seg = needExpandLinesWithId[i].second;
        seg.sort();
        int segP1ExsitCornerCnt = 0;
        int segP2ExsitCornerCnt = 0;
        for (int c = 0; c < corners.size(); ++c)
        {
            float dis1 = getPointDist(Point2f(seg.x1, seg.y1), corners[c].pt);
            float dis2 = getPointDist(Point2f(seg.x2, seg.y2), corners[c].pt);
            if (dis1 < MIN_LINE_PT_TO_CORNERS_DIS)
            {
                ++segP1ExsitCornerCnt;
            }
            if (dis2 < MIN_LINE_PT_TO_CORNERS_DIS)
            {
                ++segP2ExsitCornerCnt;
            }
        }
        if (segP1ExsitCornerCnt >= 1 && segP2ExsitCornerCnt >= 1)
        {
            continue;
        }
        if (segP1ExsitCornerCnt >= 1)
        {
            if (isVerticalLine(seg))
            {
                float slope = (seg.x2 - seg.x1) / (seg.y2 - seg.y1);
                seg.y2 = HANDLE_IMAGE_H - 1;
                seg.x2 = (seg.y2 - seg.y1) * slope + seg.x1;
            }
            else
            {
                float slope = (seg.y2 - seg.y1) / (seg.x2 - seg.x1);
                seg.x2 = HANDLE_IMAGE_W - 1;
                seg.y2 = (seg.x2 - seg.x1) * slope + seg.y1;
            }
        }
        else if (segP2ExsitCornerCnt >= 1)
        {
            if (isVerticalLine(seg))
            {
                float slope = (seg.x2 - seg.x1) / (seg.y2 - seg.y1);
                seg.y1 = 0;
                seg.x1 = seg.x2 - (seg.y2 - seg.y1) * slope;
            }
            else
            {
                float slope = (seg.y2 - seg.y1) / (seg.x2 - seg.x1);
                seg.x1 = 0;
                seg.y1 = seg.y2 - (seg.x2 - seg.x1) * slope;
            }
        }
        else
        {
            if (isVerticalLine(seg))
            {
                float slope = (seg.x2 - seg.x1) / (seg.y2 - seg.y1);
                seg.y1 = 0;
                seg.x1 = seg.x2 - (seg.y2 - seg.y1) * slope;
                seg.y2 = HANDLE_IMAGE_H - 1;
                seg.x2 = (seg.y2 - seg.y1) * slope + seg.x1;
            }
            else
            {
                float slope = (seg.y2 - seg.y1) / (seg.x2 - seg.x1);
                seg.x1 = 0;
                seg.y1 = seg.y2 - (seg.x2 - seg.x1) * slope;
                seg.x2 = HANDLE_IMAGE_W - 1;
                seg.y2 = (seg.x2 - seg.x1) * slope + seg.y1;
            }
        }
        initSegment(seg);
        seg.expandDirect = direct;
        if (!seg.subSegs.empty())
        {
            seg.subSegs.clear();
        }
        if (seg.len < MIN_EXPANDED_EDGE_LINE_LENGHT)
        {
            continue;
        }
        outSegs.push_back(seg);
    }
    return;
}

bool DocPostprocess::mayGenerateQuad(const std::vector<SEGMENT> &segs)
{

    std::vector<SEGMENT> expandSegs;
    for (int i = 0; i < segs.size(); ++i)
    {
        if (segs[i].expandDirect != -1)
        {
            expandSegs.push_back(segs[i]);
        }
    }
    if (expandSegs.empty())
    {
        return false;
    }
    sort(expandSegs.begin(), expandSegs.end(),
         [](const SEGMENT &a, const SEGMENT &b) -> bool
         { return a.expandDirect < b.expandDirect; });
    if (expandSegs.size() >= 3)
    {
        return true;
    }
    else
    {
        int verticalDirectSum = DIRECT::TOP + DIRECT::BOTTOM;
        int horizontalDirectSum = DIRECT::LEFT + DIRECT::RIGHT;
        vector<int> directCnt(4);
        for (int i = 0; i < segs.size(); ++i)
        {
            if (segs[i].len < QUAD_EXPAND_MIN_SEG_LENGHT)
            {
                continue;
            }
            if (max(segs[i].y1, segs[i].y2) < HANDLE_IMAGE_H / 4)
            {
                directCnt[DIRECT::TOP]++;
            }
            else if (min(segs[i].y1, segs[i].y2) > HANDLE_IMAGE_H - HANDLE_IMAGE_H / 4)
            {
                directCnt[DIRECT::BOTTOM]++;
            }
            else if (max(segs[i].x1, segs[i].x2) < HANDLE_IMAGE_W / 4)
            {
                directCnt[DIRECT::LEFT]++;
            }
            else if (min(segs[i].x1, segs[i].x2) > HANDLE_IMAGE_W - HANDLE_IMAGE_W / 4)
            {
                directCnt[DIRECT::RIGHT]++;
            }
        }
        if (expandSegs.size() == 1)
        {
            if (expandSegs[0].expandDirect <= verticalDirectSum &&
                directCnt[verticalDirectSum - expandSegs[0].expandDirect] > 0)
            {
                return true;
            }
            else if (expandSegs[0].expandDirect <= horizontalDirectSum &&
                     directCnt[horizontalDirectSum - expandSegs[0].expandDirect] > 0)
            {
                return true;
            }
        }
        if (expandSegs.size() == 2)
        {
            int directPairSum = expandSegs[0].expandDirect + expandSegs[1].expandDirect;
            if (directPairSum == verticalDirectSum || directPairSum == horizontalDirectSum)
            {
                return true;
            }
            else if (directCnt[verticalDirectSum - expandSegs[0].expandDirect] > 0 ||
                     directCnt[horizontalDirectSum - expandSegs[1].expandDirect] > 0)
            {
                return true;
            }
        }
    }

    return false;
}

void DocPostprocess::generateImageEdgeQuad(QUAD &quadOut)
{

    CORNER c1;
    CORNER c2;
    CORNER c3;
    CORNER c4;
    c1.pt = Point2f(0, 0);
    c2.pt = Point2f(imageW_, 0);
    c3.pt = Point2f(imageW_, imageH_);
    c4.pt = Point2f(0, imageH_);
    quadOut.corners = {c1, c2, c3, c4};

    return;
}

void DocPostprocess::cornerCase(const std::vector<SEGMENT> &segs, const std::vector<CORNER> &corners, QUAD &quadOut,
                                bool isDebug)
{

    std::vector<QUAD> newQuadsWithBoard;
    std::vector<SEGMENT> newSegsWithBoard;
    std::vector<CORNER> newCornersWithBoard;
    // 检测出三条边的情况
    if (tryQuadWithBoardLine(segs, corners, newSegsWithBoard, newCornersWithBoard, newQuadsWithBoard))
    {
        if (!newQuadsWithBoard.empty())
        {
            quadOut = chooseBestQuad(newQuadsWithBoard);
            return;
        }
    }

    std::vector<QUAD> newQuadsWithAllSegs;
    std::vector<SEGMENT> allSegs;
    std::vector<CORNER> newCornersWithAllSegs;
    addVertexSegs(newSegsWithBoard, allSegs, newCornersWithAllSegs);
    calcQuad(cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H), allSegs, newCornersWithAllSegs, newQuadsWithAllSegs, false);

    if (!newQuadsWithAllSegs.empty())
    {
        quadOut = chooseBestQuad(newQuadsWithAllSegs);
        if (isTrapezoid(quadOut, allSegs, false))
        { // 四边形为梯形
            std::vector<SEGMENT> newExpandAndOrgSegs;
            addExtendNearEdgeSegs(segs, corners, newExpandAndOrgSegs);

            std::vector<QUAD> newExpandQuads;
            std::vector<SEGMENT> newExpandAllSegs;
            std::vector<CORNER> newExpandCorners;
            addVertexSegs(newExpandAndOrgSegs, newExpandAllSegs, newExpandCorners);

            if (!mayGenerateQuad(newExpandAllSegs))
            {
                generateImageEdgeQuad(quadOut);
                return;
            }
            calcQuad(cv::Size(HANDLE_IMAGE_W, HANDLE_IMAGE_H), newExpandAllSegs, newExpandCorners, newExpandQuads,
                     false);
            if (!newExpandQuads.empty())
            {
                quadOut = chooseBestQuad(newExpandQuads);
            }
        }
    }
    else
    {
        generateImageEdgeQuad(quadOut);
    }

    return;
}

void DocPostprocess::restoreCorners(std::vector<CORNER> &corner)
{
    for (auto &cor : corner)
    {
        cor.pt.x -= HANDLE_IMAGE_PADDING;
        cor.pt.y -= HANDLE_IMAGE_PADDING;

        cor.pt.x *= (imageW_ * 1.0f / HANDLE_REAL_W);
        cor.pt.y *= (imageH_ * 1.0f / HANDLE_REAL_H);
    }
}

void DocPostprocess::restoreQuads(std::vector<QUAD> &quads) {
    for (auto &quad : quads) {
        restoreCorners(quad.corners);
    }
}

void DocPostprocess::normalizeQuad(const Mat &image, const QUAD &quad, std::vector<cv::Point2f> &quadPts) {
    std::vector<QUAD> quadsTmp = {quad};

    restoreQuads(quadsTmp);

    for (auto &corner : quadsTmp[0].corners) {
        corner.pt.x = (int)corner.pt.x;
        corner.pt.y = (int)corner.pt.y;
    }

    std::vector<SEGMENT> boards = {
            SEGMENT(0, 0, image.size().width - 1, 0),
            SEGMENT(image.size().width - 1, 0, image.size().width - 1, image.size().height - 1),
            SEGMENT(image.size().width - 1, image.size().height - 1, 0, image.size().height - 1),
            SEGMENT(0, image.size().height - 1, 0, 0)};
    for (auto &b : boards) {
        initSegment(b);
    }

    std::vector<DIRECT> boardsDirects = {TOP, RIGHT, BOTTOM, LEFT};

    for (int i = 0; i < quadsTmp[0].corners.size(); i++) {
        CORNER last_c = quadsTmp[0].corners[(i + QUAD_CORNER_NUM - 1) % QUAD_CORNER_NUM];
        CORNER now_c = quadsTmp[0].corners[i];
        CORNER next_c = quadsTmp[0].corners[(i + 1) % QUAD_CORNER_NUM];
        if (!testCornerInBoard(now_c, image.size(), false)) {
            // 超出图像外面的点单独处理
            std::vector<DIRECT> direct;
            CORNER quadsInter3 = quadsTmp[0].corners[i];
            if (now_c.pt.x < 0) {
                quadsInter3.pt.x = 0;
                direct.push_back(LEFT);
            } else if (now_c.pt.x > (image.size().width - 1)) {
                quadsInter3.pt.x = (image.size().width - 1);
                direct.push_back(RIGHT);
            }

            if (now_c.pt.y < 0) {
                quadsInter3.pt.y = 0;
                direct.push_back(TOP);
            } else if (now_c.pt.y > (image.size().height - 1)) {
                quadsInter3.pt.y = image.size().height - 1;
                direct.push_back(BOTTOM);
            }

            std::vector<SEGMENT> mayInterBoards;
            for (auto &dir : direct) {
                for (int d = 0; d < boardsDirects.size(); d++) {
                    if (boardsDirects[d] == dir) {
                        mayInterBoards.push_back(boards[d]);
                    }
                }
            }
            Point2f inter;
            SEGMENT l1(last_c.pt, now_c.pt);
            initSegment(l1);
            SEGMENT l2(now_c.pt, next_c.pt);
            initSegment(l2);
            std::vector<Point2f> intersections;
            for (auto &b : mayInterBoards) {
                if (getSegmentIntersection(b, l1, inter) && isPointOnLine(inter, b) && isPointOnLine(inter, l1)) {
                    intersections.push_back(inter);
                }

                if (getSegmentIntersection(b, l2, inter) && isPointOnLine(inter, b) && isPointOnLine(inter, l2)) {
                    intersections.push_back(inter);
                }
                if (direct.size() == 2) {
                    Point2f inter3 = {quadsInter3.pt.x, quadsInter3.pt.y};
                    intersections.push_back(inter3);
                }
                if (intersections.size() >= 3) {
                    break;
                }
            }

            if (intersections.size() >= 2) {  // 两个交点，取近点，很少能出现两个交点的情况吧。
                float d1 = getPointDist(now_c.pt, intersections[0]);
                float d2 = getPointDist(now_c.pt, intersections[1]);
                quadPts.push_back(
                        d1 < d2 ? intersections[0]
                                : intersections[1]);  //(d1 < d2 ? intersections[0] : intersections[1]);
            } else if (intersections.size() == 1) {
                quadPts.push_back(intersections[0]);
            } else {
                //                LOG(WARNING) << "corner is out, and not inersection with any board";
                quadPts.clear();
                return;
            }
        } else {
            quadPts.push_back(now_c.pt);
        }
    }
}
void DocPostprocess::normalizeQuad_2(const Mat &image, const QUAD &quad, std::vector<cv::Point2f> &quadPts)
{
    std::vector<QUAD> quadsTmp = {quad};

    restoreQuads(quadsTmp);

    for (auto &corner : quadsTmp[0].corners)
    {
        corner.pt.x = (int)MIN(MAX(corner.pt.x, 0), image.size().width - 1);
        corner.pt.y = (int)MIN(MAX(corner.pt.y, 0), image.size().height - 1);
        quadPts.push_back(corner.pt);
    }

    return;
}

void DocPostprocess::detect(const Mat &heatmap, std::vector<cv::Point2f> &quadPts, const Mat &src, float thresh,
                            int &processStatus, bool isDebug)
{
    CV_Assert(!heatmap.empty() && heatmap.type() == CV_8UC1);
    imageH_ = heatmap.size().height;
    imageW_ = heatmap.size().width;

    Mat handle = Mat::zeros(HANDLE_IMAGE_H, HANDLE_IMAGE_W, CV_8UC1);
    Rect handleRect(HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING, HANDLE_REAL_W, HANDLE_REAL_H);

    cv::resize(heatmap, handle(handleRect), cv::Size(HANDLE_REAL_W, HANDLE_REAL_H));

    // blur
    handle.setTo(0, handle < (thresh * 255));
    cv::GaussianBlur(handle, handle, cv::Size(3, 3), 0);

    std::vector<SEGMENT> segments;

    // std::cout << "开始直线检测" << std::endl;
    lineDetection(handle.clone(), segments);
    // std::cout << "一共检测出:" << segments.size() << "条线段" << std::endl;

    if (isDebug)
    {
        Mat nowDraw = handle.clone();
        cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
        drawSegments(nowDraw, segments);
        std::string line_detect_path =
            "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/line_detect.jpg";
        cv::imwrite(line_detect_path, nowDraw);
    }
    // 给线段添加相应的属性
    for (auto &seg : segments)
    {
        initSegment(seg);
    }

    // 合并线段
    std::vector<SEGMENT> merges = mergeCrudeSegs(handle, segments);
    if (isDebug)
    {
        Mat nowDraw = handle.clone();
        cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
        drawSegments(nowDraw, merges);
        std::string line_detect_path =
            "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/mergeCrude.jpg";
        cv::imwrite(line_detect_path, nowDraw);
    }
    // std::cout << "mergeCrudeSegs后线段的数量为:" << merges.size() << "条" << std::endl;

    // mergeFineSegs
    merges = mergeFineSegs(handle, merges);
    if (isDebug)
    {
        Mat nowDraw = handle.clone();
        cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
        drawSegments(nowDraw, merges);
        std::string line_detect_path =
            "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/mergeFine.jpg";
        cv::imwrite(line_detect_path, nowDraw);
    }
    // std::cout << "mergeFineSegs后线段的数量为:" << merges.size() << "条" << std::endl;

    filterSegs(merges);
    if (isDebug)
    {
        Mat nowDraw = handle.clone();
        cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
        drawSegments(nowDraw, merges);
        std::string line_detect_path =
            "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/filterSegs.jpg";
        cv::imwrite(line_detect_path, nowDraw);
    }
    // std::cout << "filterSegs后线段的数量为:" << merges.size() << "条" << std::endl;

    // 计算角点
    std::vector<CORNER> corners;
    calcCorners(handle.size(), merges, corners);
    // std::cout << "calcCorners 得到的角点个数为:" << corners.size() << std::endl;
    if (isDebug)
    {
        Mat nowDraw = handle.clone();
        cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
        drawSegments(nowDraw, merges);
        drawCorners(nowDraw, corners);
        std::string line_detect_path =
            "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/calcCorners.jpg";
        cv::imwrite(line_detect_path, nowDraw);
    }

    // 第一种情况，只检测出两条边
    if (!calcEdgeQuad(handle.size(), merges, corners, quadPts))
    {
        processStatus = PROCESS::NORMAL;
        std::vector<QUAD> quads;
        calcQuad(handle.size(), merges, corners, quads);

        if (isDebug)
        {
            Mat nowDraw = handle.clone();
            cv::cvtColor(nowDraw, nowDraw, cv::COLOR_GRAY2BGR);
            drawQuads(nowDraw, quads);
            std::string line_detect_path =
                "/home/work/codes/document/document/algorithm/edge_detection/postprocess/debug_c++/calcQuad.jpg";
            cv::imwrite(line_detect_path, nowDraw);
        }

        std::vector<QUAD> realQuads;
        QUAD quad;
        if (!quads.empty())
        {
            quad = chooseBestQuad(quads);
            realQuads.push_back(quad);
        }
        else
        { // cornerCase
            cornerCase(merges, corners, quad, isDebug);
            processStatus = PROCESS::CORNERCASE;
        }
        if (processStatus == PROCESS::NORMAL)
        {
            normalizeQuad(heatmap, quad, quadPts);
        }
        else if (processStatus == PROCESS::CORNERCASE)
        {
            normalizeQuad_2(heatmap, quad, quadPts);
        }
    }

    std::vector<cv::Point2f> sorted_pts;
    std::vector<cv::Point2f> raw_pts = {
        cv::Point2f(0, 0),
        cv::Point2f(imageW_ - 1, 0),
        cv::Point2f(imageW_ - 1, imageH_ - 1),
        cv::Point2f(0, imageH_ - 1)
    };
    std::vector<bool> visited(4, false);
    for (const auto& raw_pt : raw_pts) {
        int min_dist_idx = -1;
        float min_dist = INT_MAX;

        for (int i = 0; i < quadPts.size(); i++) {
            if (visited[i])
                continue;
            float dist = cv::norm(raw_pt - quadPts[i]);
            if (dist < min_dist) {
                min_dist = dist;
                min_dist_idx = i;
            }
        }

        if (min_dist_idx >= 0) {
            sorted_pts.emplace_back(quadPts[min_dist_idx]);
            visited[min_dist_idx] = true;
        }
    }
    
    quadPts = sorted_pts;
}