#!/usr/bin/env python
# -*- encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
post_process
@File        :post_process.py
@Time        :2022/03/28 14:57:00
@Author      :renchang
@Version     :1.0
@Contact     :renchang@baidu.com
"""

import copy
import cv2
import numpy as np
import ctypes
import os
from ctypes import c_float
# print(1)
ll = ctypes.cdll.LoadLibrary
lib_path = os.path.join(os.path.dirname(__file__), "./build/libDOC_SCAN.so")
lib = ll(lib_path)

lib.post_process.argtypes = (ctypes.c_int, ctypes.c_int, ctypes.c_int,
                             ctypes.c_char_p, ctypes.c_int, ctypes.c_int, ctypes.c_char_p)
# print("1.25")
lib.post_process.restype = ctypes.py_object
# print('1.5')
lib.crop.argtypes = (ctypes.c_int, ctypes.c_int, ctypes.c_char_p,
                          ctypes.POINTER(ctypes.c_float), ctypes.c_int)
lib.crop.restype = ctypes.py_object
# print(2)

def getBoxes(thresh, img, src_img):
    """计算角点
    """
    frame_data = img.ctypes.data_as(ctypes.c_char_p)
    src_data = src_img.ctypes.data_as(ctypes.c_char_p)
    points = lib.post_process(
        thresh, img.shape[1], img.shape[0], frame_data, src_img.shape[1], src_img.shape[0], src_data)
    
    return np.asarray(points).astype(np.float32).reshape((-1, 2))
from ctypes import *
def crop(img,points_pred):
    frame_data = img.ctypes.data_as(ctypes.c_char_p)
    sizep=points_pred.size
    # 如果 points_pred 不是 float32 类型或者不是一维数组，先进行转换
    if points_pred.dtype != np.float32 or points_pred.ndim != 1:
        points_pred = points_pred.flatten().astype(np.float32)
    # print("points_pred",points_pred)
    
    # 然后获取 ctypes 指针
    points_pred_pointer = points_pred.ctypes.data_as(POINTER(c_float))

    ret = lib.crop(img.shape[1], img.shape[0], frame_data, points_pred_pointer,sizep)
    # print("ret shape",len(ret))
    # ret=np.asarray(ret).astype(np.float32).reshape())
    h, w = ret[-2:]
    # print("h:",h)
    # print("w:",w)
    ret = ret[:-2]
    ret2 = np.array(ret).reshape(h, w, 3).astype(np.uint8)
    # print("ret2 shape",ret2.shape)
    cv2.imwrite('debug_ret.jpg', ret2)
    return ret2
# def crop(img, pts, save_path):
#     """crop
#     """
#     frame_data = img.ctypes.data_as(ctypes.c_char_p)
#     # print("pts:{}".format(pts))
#     pts_data = pts.ctypes.data_as(ctypes.POINTER(ctypes.c_float))
#     lib.post_crop(img.shape[1], img.shape[0], frame_data,
#                   pts_data, save_path.encode('utf-8'))


def draw_img(img, points, draw_type='draw'):
    """
    draw_img
    依次连接points，draw_type颜色不同而已
    """
    assert draw_type in ['gt', 'draw']
    color_draw = (255, 0, 0) if draw_type == 'draw' else (0, 0, 255)
    img_draw = copy.deepcopy(img)
    n_points = len(points)
    # print("points:{}".format(points))
    for i in range(n_points):
        point_s = tuple(map(int, points[i]))
        if i == n_points - 1:
            point_e = tuple(map(int, points[0]))
        else:
            point_e = tuple(map(int, points[i + 1]))
        cv2.line(img_draw, point_s, point_e, color_draw, thickness=2)
    return img_draw


if __name__ == "__main__":
    image_path = "/home/chenjiashun/code/bujin/codes/edge_detection/scc/data/visible_gt/3_input.jpg"
    src_img = cv2.imread(image_path)
    if src_img.ndim == 3:
        h, w, _ = src_img.shape
    else:
        h, w = src_img.shape

    # print("h:{}, w:{}".format(h, w))
    assert w % 2 == 0
    real_w = w // 2
    heat_map = src_img[:, real_w:]
    input_img = src_img[:, :real_w]
    heat_map = cv2.cvtColor(heat_map, cv2.COLOR_BGR2GRAY)
    cv2.imwrite('heat_map_new.jpg', heat_map)
    cv2.imwrite('input_img_new.jpg', input_img)
    thresh = 22
    points = getBoxes(thresh, heat_map, input_img)
    imgDraw = draw_img(input_img, points)
    cv2.imwrite('debug_so_new.jpg', imgDraw)
    # print(points.tolist())
