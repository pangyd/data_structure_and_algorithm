#!/usr/bin/env python
# -*- encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
计算iou
@File        :eval.py
@Time        :2022/12/09 17:34:15
@Author      :renchang
@Version     :1.0
@Contact     :renchang@baidu.com
"""


import cv2
from tqdm import tqdm 
import numpy as np 
import os
import os.path as osp
import shapely
from shapely.geometry import Polygon, MultiPoint


def calulate_iou(points, gt_points):
    """
    可能是预测点和gt点计算iou
    """
    poly1 = Polygon(points).convex_hull  
    # print(poly1)
     
    poly2 = Polygon(gt_points).convex_hull
    # print(poly2)
     
    union_poly = np.concatenate((points, gt_points))
    
    if not poly1.intersects(poly2): 
        iou = 0
    else:
        try:
            inter_area = poly1.intersection(poly2).area   
            union_area = MultiPoint(union_poly).convex_hull.area
            if union_area == 0:
                iou= 0
            iou=float(inter_area) /(poly1.area + poly2.area - inter_area)
        except shapely.geos.TopologicalError:
            print('shapely.geos.TopologicalError occured, iou set to 0')
            iou = 0
    return iou