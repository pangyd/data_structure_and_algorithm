#include "doc_correction.h"

#include <map>

#include "opencv2/imgproc/imgproc.hpp"

using cv::Point2f;
using std::vector;

static const int sQuadPtNum = 4;
static const float CROP_EXCEED_RATIO = 1.20;
static const float EPSILON = 1e-9;

static const float DISTANCE_ADJUST_H = 0.012f;
static const float DISTANCE_ADJUST_W = 0.012f;

static void adjust_background(cv::Mat &rectify_image)
{
    int crop_src_h = rectify_image.rows;
    int crop_src_w = rectify_image.cols;

    int h_diff = static_cast<int>(static_cast<float>(crop_src_h) * DISTANCE_ADJUST_H);
    int w_diff = static_cast<int>(static_cast<float>(crop_src_w) * DISTANCE_ADJUST_W);

    int dest_h = crop_src_h - 1.5 * h_diff;
    int dest_w = crop_src_w - 1.5 * w_diff;

    cv::Rect rect(w_diff, h_diff, dest_w, dest_h);
    cv::Mat adjust_mat = rectify_image(rect);
    rectify_image = adjust_mat.clone();
}

void coordinate2pts(const vector<float> &coordinate, vector<Point2f> &pts)
{
    CV_Assert(coordinate.size() == sQuadPtNum * 2);

    pts.clear();
    for (int idx = 0; idx < coordinate.size(); idx += 2)
    {
        Point2f pt_tmp;
        pt_tmp.x = coordinate[idx];
        pt_tmp.y = coordinate[idx + 1];
        pts.push_back(pt_tmp);
    }
}

void pts2coordinate(const vector<Point2f> &pts, vector<float> &coordinate)
{
    CV_Assert(pts.size() == sQuadPtNum);

    coordinate.clear();
    for (auto pt : pts)
    {
        coordinate.push_back(pt.x);
        coordinate.push_back(pt.y);
    }
}

float linesAngle(std::vector<cv::Point2f> line1, std::vector<cv::Point2f> line2)
{
    float line1Angle = (float)(cv::fastAtan2(line1[1].y - line1[0].y, line1[1].x - line1[0].x) / 180.0f * CV_PI);
    float line2Angle = (float)(cv::fastAtan2(line2[1].y - line2[0].y, line2[1].x - line2[0].x) / 180.0f * CV_PI);
    float angleDiff = static_cast<float>(fabsf(line1Angle - line2Angle) / CV_PI * 180);

    angleDiff = angleDiff > 180 ? angleDiff - 180 : angleDiff;
    angleDiff = angleDiff > 90 ? 180 - angleDiff : angleDiff;

    return angleDiff;
}

bool normalizationPoints(vector<float> &coordinate, float minAngle)
{
    std::vector<cv::Point2f> img_pts;
    coordinate2pts(coordinate, img_pts);

    std::vector<int> hull;
    convexHull(img_pts, hull, false, false); //返回的是顺时针的方向
    if (hull.size() != sQuadPtNum)
    {
        return false;
    }

    std::vector<Point2f> newCorners;
    for (size_t i = 0; i < sQuadPtNum; i++)
    {
        newCorners.push_back(img_pts[hull[i]]);
    }

    for (int i = 0; i < sQuadPtNum; i++)
    {
        std::vector<Point2f> line1 = {newCorners[i], newCorners[(i + 1) % sQuadPtNum]};
        std::vector<Point2f> line2 = {newCorners[i], newCorners[(i - 1 + sQuadPtNum) % sQuadPtNum]};
        float angle = linesAngle(line1, line2);
        if (angle < minAngle)
        {
            return false;
        }
    }

    pts2coordinate(newCorners, coordinate);

    return true;
}

float calEdgesAngle(const std::vector<cv::Point2f> &imgPoints, const std::vector<std::pair<int, int>> &edges)
{
    float edgesAngle = 0.0;
    std::vector<cv::Point2f> line = {cv::Point2f(0.0, 0.0), cv::Point2f(1.0, 0.0)};
    for (const auto &edge : edges)
    {
        std::vector<cv::Point2f> lineEdge = {imgPoints[edge.first], imgPoints[edge.second]};
        edgesAngle += linesAngle(line, lineEdge);
    }

    return edgesAngle;
}

void reorderImgPts(vector<Point2f> &imgPts)
{
    vector<Point2f> imgPts_res;
    std::vector<std::pair<int, int>> edges1, edges2;
    edges1.push_back(std::pair<int, int>(0, 1));
    edges1.push_back(std::pair<int, int>(2, 3));
    edges2.push_back(std::pair<int, int>(1, 2));
    edges2.push_back(std::pair<int, int>(3, 0));

    float angle1 = calEdgesAngle(imgPts, edges1);
    float angle2 = calEdgesAngle(imgPts, edges2);

    std::map<float, std::vector<std::pair<int, int>>> edgesAngle;
    edgesAngle[angle1] = edges1;
    edgesAngle[angle2] = edges2;

    const auto &horizontalEdges = edgesAngle.begin()->second;
    for (int i = 0; i < horizontalEdges.size(); ++i)
    {
        const auto &index1 = horizontalEdges[i].first;
        const auto &index2 = horizontalEdges[i].second;
        if (imgPts[index1].x < imgPts[index2].x)
        {
            imgPts_res.emplace_back(imgPts[index1]);
            imgPts_res.emplace_back(imgPts[index2]);
        }
        else
        {
            imgPts_res.emplace_back(imgPts[index2]);
            imgPts_res.emplace_back(imgPts[index1]);
        }
    }

    // assert the average Y of edges1 is less than that of edges2;
    float edges1Y = (imgPts_res[0].y + imgPts_res[1].y) / 2;
    float edges2Y = (imgPts_res[2].y + imgPts_res[3].y) / 2;
    if (edges1Y > edges2Y)
    {
        imgPts_res.emplace_back(imgPts_res[0]);
        imgPts_res.emplace_back(imgPts_res[1]);
        imgPts_res.erase(imgPts_res.begin());
        imgPts_res.erase(imgPts_res.begin());
    }

    imgPts.clear();
    imgPts.assign(imgPts_res.begin(), imgPts_res.end());
}

double calAspectRatio(const vector<Point2f> &imgPts, int imageWidth, int imageHeight)
{
    CV_Assert(imgPts.size() == sQuadPtNum);

    std::vector<cv::Vec3d> cornerCoords;
    for (int i = 0; i < sQuadPtNum; i++)
    {
        cornerCoords.emplace_back(cv::Vec3d(imgPts[i].x, imgPts[i].y, 1.0));
    }

    const auto &m1 = cornerCoords[0];
    const auto &m2 = cornerCoords[1];
    const auto &m3 = cornerCoords[2];
    const auto &m4 = cornerCoords[3];

    double k2Numerator = m1.cross(m4).dot(m3);
    double k2Denominator = m2.cross(m4).dot(m3);
    double k2 = k2Numerator / k2Denominator;
    cv::Vec3d n2 = k2 * m2 - m1;

    double k3Numerator = m1.cross(m4).dot(m2);
    double k3Denominator = m3.cross(m4).dot(m2);
    double k3 = k3Numerator / k3Denominator;
    cv::Vec3d n3 = k3 * m3 - m1;

    int u0 = imageWidth / 2;
    int v0 = imageHeight / 2;
    int s = 1;
    double focal = 0.0;
    double aspectRatio = 0.0;

    const int usualFocal = std::min(imageHeight, imageWidth);
    const int focalThreshold = usualFocal / 10;

    if ((std::abs(n2[2]) < 0.01) || (std::abs(n3[2]) < 0.01))
    {
        focal = double(usualFocal);
    }
    else
    {
        double fSquare = -((n2[0] * n3[0] - (n2[0] * n3[2] + n2[2] * n3[0]) * u0 + n2[2] * n3[2] * u0 * u0) * s * s +
                           (n2[1] * n3[1] - (n2[1] * n3[2] + n2[2] * n3[1]) * v0 + n2[2] * n3[2] * v0 * v0)) /
                         (n2[2] * n3[2] * s * s);

        if (fSquare < 0)
        {
            focal = double(usualFocal);
        }
        else
        {
            focal = std::sqrt(fSquare);
        }
        if (std::abs(focal - usualFocal) <= focalThreshold)
        {
            focal = double(usualFocal);
        }
    }

    cv::Matx<double, 3, 1> n2Matrix(n2[0], n2[1], n2[2]);
    cv::Matx<double, 3, 1> n3Matrix(n3[0], n3[1], n3[2]);
    cv::Matx<double, 3, 3> A(focal, 0, u0, 0, focal, v0, 0, 0, 1);
    double aspectRatioSquare =
        ((n2Matrix.t() * A.t().inv() * A.inv() * n2Matrix)(0)) / ((n3Matrix.t() * A.t().inv() * A.inv() * n3Matrix)(0));
    if (aspectRatioSquare < 0)
    {
        return -1;
    }
    aspectRatio = std::sqrt(aspectRatioSquare);

    return aspectRatio;
}

void calPerspectiveImgHW(const vector<Point2f> &imgPts, float aspectRatio, int imageWidth, int imageHeight,
                         int &resultW, int &resultH)
{
    // Updating resultW && resultH only when aspectRatio is computed successfully. // and its difference with ratio is
    // less than diffThreshold; double diffThreshold = 0.28;
    if (imgPts.size() != 4)
    {
        return;
    }

    float a = static_cast<float>(cv::norm(imgPts[0] - imgPts[1]));
    float b = static_cast<float>(cv::norm(imgPts[0] - imgPts[2]));
    float a1 = static_cast<float>(cv::norm(imgPts[2] - imgPts[3]));
    float b1 = static_cast<float>(cv::norm(imgPts[1] - imgPts[3]));

    float maxW = std::max(a, a1);
    float maxH = std::max(b, b1);

    float mean_a = (a + a1) / 2;
    float mean_b = (b + b1) / 2;

    float ratio = 0.0;
    if (mean_a > mean_b)
    { //宽比长多
        ratio = std::min(a, a1) / std::min(b, b1);
        // resultW = (int) max(ratio * maxH, maxW);
        // resultH = static_cast<int>(resultW / ratio);
        resultW = int(maxW);
        resultH = std::min((int)(resultW / ratio), (int)(imageHeight * CROP_EXCEED_RATIO));
    }
    else
    { //长比宽多
        ratio = std::min(a, a1) / std::min(b, b1);
        // resultH = (int) max(maxW / ratio, maxH);
        // resultW = static_cast<int>(resultH * ratio);
        resultH = (int)maxH;
        resultW = std::min((int)(resultH * ratio), (int)(imageWidth * CROP_EXCEED_RATIO));
    }
    if (fabs(aspectRatio + 1) < EPSILON)
    {
        double initialRatio = maxW / maxH;
        if (initialRatio >= aspectRatio)
        {
            resultW = (int)maxW;
            resultH = std::min((int)(resultW / aspectRatio), (int)(imageHeight * CROP_EXCEED_RATIO));
        }
        else
        {
            resultH = (int)maxH;
            resultW = std::min((int)(resultH * aspectRatio), (int)(imageWidth * CROP_EXCEED_RATIO));
        }
    }
}

cv::Mat crop(const cv::Mat &src, const std::vector<float> &coordinate, bool &flag)
{
    CV_Assert(!src.empty() && src.type() == CV_8UC3);

    int height_src = src.rows;
    int width_src = src.cols;
    cv::Mat output;
    CV_Assert(coordinate.size() == 8);

    float min_angle = 30;
    std::vector<float> coordinate_dl = coordinate;
    if (!normalizationPoints(coordinate_dl, min_angle))
    {
        flag = false;
        return output;
    }

    vector<Point2f> img_pts;
    coordinate2pts(coordinate_dl, img_pts);
    reorderImgPts(img_pts);
    // for (const auto& pt : img_pts) {
    //     std::cout << "Point: (" << pt.x << ", " << pt.y << ")" << std::endl;
    // }
    double aspectRatio = 0.0;
    aspectRatio = calAspectRatio(img_pts, width_src, height_src);
    // std::cout << "AspectRatio: " << aspectRatio << std::endl;
    int resultW = 0, resultH = 0;
    calPerspectiveImgHW(img_pts, aspectRatio, width_src, height_src, resultW, resultH);
    // std::cout << "ResultW: " << resultW << ", ResultH: " << resultH << std::endl;
    vector<Point2f> dst_pts;
    dst_pts.push_back(cv::Point(0, 0));
    dst_pts.push_back(cv::Point(resultW - 1, 0));
    dst_pts.push_back(cv::Point(0, resultH - 1));
    dst_pts.push_back(cv::Point(resultW - 1, resultH - 1));

    cv::Mat transmtx = getPerspectiveTransform(img_pts, dst_pts);
    warpPerspective(src, output, transmtx, cv::Size(resultW, resultH));

    // adjust_background(output);
    flag = true;
    return output;
}