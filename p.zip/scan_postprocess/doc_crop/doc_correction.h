//
// create by renchang on 2021 08 10
// 

#ifndef DOC_CORRECTION_H
#define DOC_CORRECTION_H

#include <opencv2/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include<iostream>
#include<vector>
#include<map>

cv::Mat crop(const cv::Mat & src, const std::vector<float>& coordinate, bool & flag);
void crop_save(const cv::Mat & src, const std::vector<float>& coordinate, const std::string& savePath);
#endif // DOC_CORRECTION_H