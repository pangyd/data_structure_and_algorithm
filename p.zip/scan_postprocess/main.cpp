#include <iostream>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv/cv.hpp>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include "doc_scan/fast_line_detector.hpp"
#include "doc_scan/doc_postprocess.h" 
#include "doc_crop/doc_correction.h"

using namespace std;
using namespace cv;
using namespace cv::ximgproc;

// void FindFiles(string root, vector<string> &files) {
//     DIR *dir = nullptr;
//     struct dirent *ent = nullptr;
//     if ((dir = opendir(root.c_str())) != NULL) {
//         while ((ent = readdir(dir)) != NULL) {
//             if (!strcmp(ent->d_name, ".") || !strcmp(ent->d_name, ".."))
//                 continue;
//             files.push_back(ent->d_name);
//         }
//         closedir(dir);
//     }
// }

// void getImagePathList(std::string folder, std::vector<cv::String> &imagePathList, std::vector<std::string> &filename) {
//     cv::glob(folder, imagePathList);

//     for (size_t i = 0; i < imagePathList.size(); i++) {
//         char a[20];
//         int idx = 0;
//         int n = imagePathList[i].size() - folder.size();
//         for (idx; idx < 16; idx++) {
//             a[i] = imagePathList[i][idx];
//         }
//         a[idx] = '\0';
//         std::string filename_tmp = a;
//         filename.push_back(filename_tmp);
//     }
//     return;
// }

// void drawQuad(cv::Mat &image, std::vector<cv::Point2f> quads) {
//     int numberPoints = quads.size();
//     int w = image.size().width;
//     int h = image.size().height;
//     RNG rng(123);
//     Scalar color = Scalar(rng.uniform(50, 256), rng.uniform(50, 256), rng.uniform(50, 256));  // Scalar(0, 255, 0)

//     for (int i = 0; i < quads.size(); i++) {
//         line(image, quads[i], quads[(i + 1) % numberPoints], color, 2);
//     }
// }

// int document_mkdir(std::string output_dir) {
//     if (access(output_dir.c_str(), 0) == -1) {
//         std::cout << output_dir << "当前目录不存在" << endl;
//         std::cout << "now make it" << endl;
//         int flag = mkdir(output_dir.c_str(), 0777);
//         if (flag == 0) {
//             std::cout << "make successfully" << endl;
//             return 0;
//         } else {
//             cout << "make errorly" << endl;
//             return -1;
//         }
//     } else {
//         std::cout << output_dir << "当前目录已存在" << endl;
//     }
// }

int main() {
    return 0;
}