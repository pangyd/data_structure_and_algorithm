#!/usr/bin/env python
# -*- encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
@File        :detect.py
@Time        :2021/06/28 17:17:29
@Author      :renchang
@Version     :1.0
@Contact     :renchang@baidu.com
脚本根据边缘检测网络输出的heatmap预测文档区域的4个角点位置
"""

import os
import numpy as np
import cv2
import math
import copy
from glob import glob
import os.path as osp
from tqdm import tqdm

from scan_postprocess import detect_confidence 


handle_image_padding = 6 # 这里是根据opencv 中设置的
canny_th1 = 50
canny_th2 = canny_th1 * 3
canny_aperture_size = 3
length_thre = 8
distance_thre = 4
image_width = 320
image_height = 320

LARGE_NUM = 9999999
CV_PI = 3.1415926

MAX_CRUDE_ANGLE = 15
MAX_CRUDE_LINE_DIST = 15
MIN_CRUDE_LINE_DIST = 5
MIN_CRUDE_OVERLAP_RATIO = 0.7
FILLED_RATIO = 0.85

MAX_FINE_ANGLE = 8
MAX_FINE_LINE_DIST = 8
MIN_FINE_OVERLAP_RATIO = 2

HANDLE_IMAGE_W = 320
HANDLE_IMAGE_H = 320
HANDLE_IMAGE_PADDING = 6
HANDLE_REAL_W = HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING * 2
HANDLE_REAL_H = HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING * 2

MIN_LINE_LEN = 15
CORNER_CASE_LINE_LEN = 50
CORNER_CASE_MAX_AUTO_NEW_LINE = 3

MAX_LINE_NUM = 30

MIN_BOARD_LINE_EXIST_DIST = 20
MIN_BOARD_LINE_EXIST_ANGLE = 10
MIN_BOARD_LINE_EXIST_RATIO = 0.5
MIN_BOARD_LINE_DIST = 8

MAX_CORNER_NUM = 40
MIN_CORNER_DIST = 20
MIN_CORNER_ANGLE = 30
MIN_CORNER_BLANK_RATIO = 1.5
MIN_CORNER_BLANK_RATIO_OUTBOARD = 2
MIN_CORNER_BLANK_RATIO_LOOSE = 3
MIN_CORNER_TWO_LINE_RATIO = 0.15
MIN_CORNER_TWO_LINE_RATIO_LOOSE = 0.1

DOTTED_SOLID_LINE_RATIO = 0.30
DOTTED_SOLID_LINE_RATIO_OUTBOARD = 0.15
DOTTED_SOLID_LINE_RATIO_LOOSE = 0.10

QUAD_SEG_LEN_RATIO = 0.2
QUAD_BLANK_SCORE_PUNISH = 1.5
QUAD_EXCEED_LINE_PUNISH = 0

EDGE_QUAD_TWO_STRAIGHT_SEG_DELTA_ANGEL = 20
EDGE_QUAD_SEG_NO_OVERLAP_DIST = 10
EDGE_QUAD_PT_TO_SEG_DIST = 20
EDGE_QUAD_SEG_TO_EDGE_DIST = 5
EDGE_QUAD_TWO_EDGE_DELTA_ANGEL = 1

NEAR_BOARD_PADDING = 20
QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET = 4
QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET_LOOSE = 8
QUAD_TWO_PARALLEL_LINE_MIN_ANGLE = 5
QUAD_EXPAND_MIN_SEG_LENGHT = 200
MAX_NEAR_BOARDLINE_ANGLE = 45
MIN_NEAR_BOARDLINE_LENGHT = 40
MIN_LINE_PT_TO_CORNERS_DIS = 15
MIN_EXPANDED_EDGE_LINE_LENGHT = 160

THRESHOLD_MAP = 0.1
QUAD_CORNER_NUM = 4


class Corner(object):
    """定义角点
    """
    def __init__(self, pt):
        self.pt = pt
        self.lineIds = []
        self.score = 0.0


class Quad(object):
    """定义多边形
    """
    def __init__(self, corners):
        self.corners = corners
        self.score = None


class Segment(object):
    """定义线段
    """
    def __init__(self, ps, pe):
        self.ps = [ps[0], ps[1]]
        self.pe = [pe[0], pe[1]]
        self.angle = None
        self.len = None
        self.center = None
        self.seg_type = 0 # 0 表示原始的线段 1 表示merge_crude 2表示merge_fine 3表示auto_new
        self.expandDirect = -1 
        self.ref = None 
        self.subSegs = []
        self.l = None # 直线方程 type numpy [3, ]
    
    def sort(self):
        """调整线段的端点，满足s在e的前面
        """
        delta_x = self.pe[0] - self.ps[0]
        delta_y = self.pe[1] - self.ps[1]
        # 垂直情况下,需要保证ps的y值小于pe的y值；水平情况下，需要保证的是ps的x的值小于pe的x的值
        if abs(delta_x) > abs(delta_y): # 说明是小于45度的直线，我们当作水平线处理
            if self.ps[0] > self.pe[0]: # 线段起始点的x坐标大于终点，此时我们做交换
                self.ps, self.pe = self.pe, self.ps
        else: # 大于45度，此时做垂直线处理
            if self.ps[1] > self.pe[1]:
                self.ps, self.pe = self.pe, self.ps
    
    def getAngle(self):
        """计算直线的斜率
        """
        assert self.ps and self.pe 
        delta_x = self.pe[0] - self.ps[0]
        delta_y = self.pe[1] - self.ps[1]
        # self.angle 的取值范围为[0, 2* pi]
        # self.angle = math.atan2(delta_y, delta_x) # atan2的取值范围为-pi ~ pi
        self.angle =  1.0 * cv2.fastAtan2(delta_y, delta_x) / 180.0 * CV_PI
    
    def centerSegment(self):
        """计算线段中点
        """
        center_x = (self.ps[0] + self.pe[0]) / 2
        center_y = (self.ps[1] + self.pe[1]) / 2
        self.center = [center_x, center_y]
    
    def init_segment(self):
        """根据线段的2个点初始化线段的其他属性
        """
        # assert self.ps != None and self.pe != None
        delta_x = self.pe[0] - self.ps[0]
        delta_y = self.pe[1] - self.ps[1]
        self.len = math.sqrt(delta_x * delta_x + delta_y * delta_y)

        # a = self.ps + [1.0]
        # b = self.pe + [1.0]
        a = [self.ps[0], self.ps[1], 1.0]
        b = [self.pe[0], self.pe[1], 1.0]
        # a_array = np.array(a).astype(np.float).reshape((3, 1))
        # b_array = np.array(b).astype(np.float).reshape((3, 1))
        # self.l = np.cross(a_array, b_array)
        self.l = np.cross(a, b)
        self.seg_type = 0
        self.expandDirect = -1
        self.getAngle()
        self.centerSegment()
    
    def new_eq(self, other):
        """new_eq
        """
        other.sort()
        delta_ps_x = abs(other.ps[0] - self.ps[0])
        delta_ps_y = abs(other.ps[1] - self.ps[1])
        delta_pe_x = abs(other.pe[0] - self.pe[0])
        delta_pe_y = abs(other.pe[1] - self.pe[1])
        if max([delta_ps_x, delta_ps_y, delta_pe_x, delta_pe_y]) < 1e-6:
            return True
        else:
            return False


class Edge(object):
    """定义边
    """
    def __init__(self, v1, v2):
        """__init__
        """
        self.v1 = v1
        self.v2 = v2
    
    def has(self, v):
        """判断边是否包含角点v
        """
        return v == self.v1 or v == self.v2

        
class Graph(object):
    """图
    """
    def __init__(self):
        self.graph_ = []
        self.allCycles = []
    
    def addEgde(self, u, v):
        """添加边

        Args:
            u: 角点索引
            v: 角点索引
        """
        edge_tmp = Edge(u, v)
        self.graph_.append(edge_tmp)

    def edgeNum(self):
        """边的数目
        """
        return len(self.graph_)
    
    def addEdgeFast(self, u, v):
        """
        添加边
        """
        if u >= 0 and u <= 255  and v >= 0 and v <= 255:
            edge_tmp = Edge(u, v)
            self.graph_.append(edge_tmp)
        else:
            # print("角点的索引不合法，应该在0-255之间")
            pass
    
    def findNewCycles(self, sub_path, maxLen=4):
        """寻找闭环
        回溯法解决
        """
        start_node = sub_path[-1]
        next_node = -1
        for edge in self.graph_:
            if edge.has(start_node):
                node1 = edge.v1
                node2 = edge.v2
                next_node = node2 if node1 == start_node else node1
                if next_node not in sub_path and len(sub_path) < maxLen: # 如果下一个节点不在当前路径中，并且路径长度不大于最大值
                    sub_path.append(next_node)
                    self.findNewCycles(sub_path, maxLen)
                    sub_path.pop() # 回溯
                elif next_node == sub_path[0] and len(sub_path) > 2: # 当前路径中以及有3个点了
                    p = sorted(sub_path)
                    inv = p[::-1]
                    if p not in self.allCycles and inv not in self.allCycles:
                        self.allCycles.append(p[:])

    def findAllCyclesFast(self, maxLen):
        """快速找边
        """
        if maxLen > 4:
            return []
        
        cycles = set()
        vertexs = set() # 存储所有的角点
        for edge in self.graph_:
            vertexs.add(edge.v1)
            vertexs.add(edge.v2)
        
        for v in vertexs:
            # 以每一个角点为起始点找4个角点能构成的闭环
            self.findNewCycles([v])
        return self.allCycles

    def findCyclesFast(self, maxLen=4):
        """寻找图中能构成闭环的4个点

        Args:
            maxLen (int, optional): [description]. Defaults to 4.
        """
        for i, cycle in enumerate(self.allCycles):
            if len(cycle) < maxLen:
                self.allCycles.pop(i)
        return self.allCycles

    
def distPointLine(p, l):
    """[summary] 计算点到直线的距离

    Args:
        p ([numpy]): [点的坐标]
        l ([numpy]): [直线方程的系数 A, B, C]
    """
    a, b, c = l
    w = math.sqrt(a * a + b * b)
    l = l / w
    ans =  np.dot(l, p)
    return ans


# def getPointChain(canny_img, pt, chained_pt_list, direction_list, step):
#     """
#     getPointChain
#     """
#     chained_pt = chained_pt_list[0]
#     direction = direction_list[0]
#     h, w = canny_img.shape
#     min_dir_diff = 7.0
#     indices = [(1, 1), (1, 0), (1, -1), (0, -1), (-1, -1), (-1, 0), (-1, 1), (0, 1)]
#     consistent_direction = 0
#     consistent_pt = [-1, -1]
#     for i, indice in enumerate(indices):
#         ci = pt[0] + indice[1]
#         ri = pt[1] + indice[0]
#         if ci < 0 or ci >= w or ri < 0 or ri >= h:
#             continue
#         if canny_img[ri, ci] == 0:
#             continue
#         if step == 0: # 种子点
#             chained_pt[0] = ci
#             chained_pt[1] = ri
#             direction = float(i - 8) if i > 4 else i
#             direction_list[0] = direction
#             chained_pt_list[0] = chained_pt
#             return True
#         else:
#             curr_dir = float(i - 8) if i > 4 else i
#             dir_diff = abs(curr_dir - direction)
#             dir_diff = 8.0 - dir_diff if dir_diff > 4 else dir_diff
#             if dir_diff <= min_dir_diff:
#                 min_dir_diff = dir_diff
#                 consistent_pt = (ci, ri)
#                 consistent_direction =  i - 8 if i > 4 else i

#     if min_dir_diff < 2.0:
#         chained_pt = consistent_pt
#         direction = (direction * float(step) + float(consistent_direction)) / (float(step + 1))
#         direction_list[0] = direction
#         chained_pt_list[0] = chained_pt
#         return True
#     return False


def incidentPoint(l, pt):
    """计算点投影到直线上的点的位置

    Args:
        l: 法向量
        pt: 点

    Returns:
        [type]: [description]
    """
    a = [pt[0], pt[1], 1.0]
    b = [l[0], l[1], 0.0]
    xk = np.array(a).astype(float)
    lh = np.array(b).astype(float)
    lk = np.cross(xk, lh)
    xk = np.cross(lk, l)
    beta = 1.0 / xk[2]
    xk = xk * beta
    pt_tmp = [max(0, xk[0]), max(0, xk[1])]
    pt_tmp[0] = min(pt_tmp[0], image_width - 1)
    pt_tmp[1] = min(pt_tmp[1], image_height - 1)
    return pt_tmp


# def extractSegments(points):
#     """从点集中提取线段

#     Args:
#         points ([list]): [点集]
#     """
#     is_line = False
#     seg = Segment()
#     ans = []
#     ps = [-1, -1]
#     pe = [-1, -1]
#     pt = [-1, -1]
#     l_points = []
#     total = len(points)
#     i = 0
#     while i + length_thre < total:
#         ps = points[i]
#         pe = points[i + length_thre]

#         a = [ps[0], ps[1], 1]
#         b = [pe[0], pe[1], 1]
#         p1 = np.array(a).reshape(3, ).astype(np.float)
#         p2 = np.array(b).reshape(3, ).astype(np.float)
#         l = np.cross(p1, p2)

#         is_line = True
#         l_points = []
#         l_points.append(ps)

#         for j in range(1, length_thre):
#             pt = [points[i + j][0], points[i + j][1]]
#             p = [points[i + j][0], points[i + j][1], 1]
#             p_array = np.array(p).astype(np.float)
#             dist = distPointLine(p_array, l)

#             if dist > distance_thre:
#                 is_line = False
#                 break
#             l_points.append(pt)
        
#         if not is_line:
#             i += 1
#             continue
        
#         l_points.append(pe)

#         line = cv2.fitLine(l_points, cv2.DIST_L2, 0, 0.01, 0.01)
#         a[0] = line[2]
#         a[1] = line[3]
#         b[0] = line[2] + line[0]
#         b[1] = line[3] + line[1]

#         p1 = [line[2], line[3], 1]
#         p1 = np.array(p1).astype(np.float)
#         p2 = [b[0], b[1], 1].astype(np.float)
#         p2 = np.array(p2).astype(np.float)

#         l = np.cross(p1, p2)

#         # opencv 中求入射点的函数不知道作用是什么
#         pt_tmp = incidentPoint(l, ps)
#         # 更新ps
#         ps = pt_tmp

#         # extend line
#         j = length_thre + 1
#         while i +j < total:
#             pt = points[i + j]
#             p = [pt[0], pt[1], 1]
#             p = np.array(p).astype(np.float)

#             dist =  distPointLine(p, l)
#             if dist > distance_thre:
#                 line = cv2.fitLine(l_points, cv2.DIST_L2, 0, 0.01, 0.01)
#                 a[0] = line[2]
#                 a[1] = line[3]
#                 b[0] = line[2] + line[0]
#                 b[1] = line[3] + line[1]

#                 p1 = [line[2], line[3], 1]
#                 p1 = np.array(p1).astype(np.float)
#                 p2 = [b[0], b[1], 1].astype(np.float)
#                 p2 = np.array(p2).astype(np.float)

#                 l = np.cross(p1, p2)
#                 dist = distPointLine(p, l)
#                 if dist > distance_thre:
#                     j -= 1
#                     break
#             pe = pt
#             l_points.append(pt)
#             j += 1
#         line = cv2.fitLine(l_points, cv2.DIST_L2, 0, 0.01, 0.01)
#         a[0] = line[2]
#         a[1] = line[3]
#         b[0] = line[2] + line[0]
#         b[1] = line[3] + line[1]

#         p1 = [line[2], line[3], 1]
#         p1 = np.array(p1).astype(np.float)
#         p2 = [b[0], b[1], 1].astype(np.float)
#         p2 = np.array(p2).astype(np.float)

#         l = np.cross(p1, p2)
#         e1 = [ps[0], ps[1]]
#         e2 = [pe[0], pe[1]]
#         pt_tmp = incidentPoint(l, e1)
#         e1 = pt_tmp
#         pt_tmp = incidentPoint(l, e2)
#         e2 = pt_tmp
#         seg.ps = e1
#         seg.pe = e2
#         ans.append(seg)
#         i = i + j if j >= 1 else i + 1

# def lineDetection(heatmap_dl):
#     """检测直线

#     Args:
#         heatmap_dl ([Mat]): [模糊后的mask]
#     """
#     h, w = heatmap_dl.shape
#     canny = cv2.Canny(heatmap_dl, canny_th1, canny_th2, canny_aperture_size)
#     # opencv 中是这样实现的
#     canny[0:6, :] = 0
#     canny[h - 5 : h, :] = 0
#     canny[:, 0:6] = 0
#     canny[:, w-5:h] = 0

#     points = [] # 存储点的坐标

#     for i in range(h):
#         for j in range(w):
#             # Find seeds - skip for non-seeds
#             if canny[i, j] == 0:
#                 continue
#             pt = (j, i)
#             points.append(pt)
#             canny[i, j] = 0

#             direction = 0.0
#             step = 0
#             chained_pt = pt
#             chained_pt_list = [chained_pt]
#             direction_list = [direction]
#             while getPointChain(canny, pt, chained_pt_list, direction_list, step):
#                 points.append(chained_pt)
#                 step += 1
#                 chained_pt = chained_pt_list[0]
#                 canny[chained_pt[1], chained_pt[0]] = 0
            
#             if len(points) <= length_thre:
#                 points = []
#                 continue


# 这段代码是在stackflow上找到的         
def FLD(image):
    """FLD
    """
    # TODO 还需要check一下代码的正确性
    # Create default Fast Line Detector class
    fld = cv2.ximgproc.createFastLineDetector(length_thre, distance_thre, canny_th1,  \
                                                canny_th2, canny_aperture_size, do_merge=True)
    # Get line vectors from the image
    lines = fld.detect(image)
    # Draw lines on the image
    # line_on_image = fld.drawSegments(image, lines)
    # Plot
    return lines


def getLineAngle(seg_i, seg_j):
    """计算2条直线的夹角

    Args:
        seg_i ([Segment]): [线段i]
        seg_j ([Segment]): [线段j]
    返回的夹角在0-90之间
    """
    angleDiff = abs(seg_i.angle - seg_j.angle) / CV_PI * 180.0
    if angleDiff > 180:
        angleDiff = angleDiff - 180
    if angleDiff > 90:
        angleDiff = 180 - angleDiff
    return angleDiff


def lineVerticalDist(seg_i, seg_j):
    """计算2条直线的垂直距离

    Args:
        seg_i ([Segment]): [线段i]
        seg_j ([Segment]): [线段j]
    """
    # 将长线段投影到短的线段
    if seg_i.len < seg_j.len:
        p1 = seg_j.ps + [1.0]
        p1_array = np.array(p1).astype(float)
        p2 = seg_j.pe + [1.0]
        p2_array = np.array(p2).astype(float)
        l = seg_i.l
    else:
        p1 = seg_i.ps + [1.0]
        p1_array = np.array(p1).astype(float)
        p2 = seg_i.pe + [1.0]
        p2_array = np.array(p2).astype(float)
        l = seg_j.l
    
    dist1 = distPointLine(p1_array, l)
    dist2 = distPointLine(p2_array, l)
    return max(abs(dist1), abs(dist2))


def getSegmentsQuad(seg_i, seg_j):
    """计算2条直线组成的多边形

    Args:
        seg_i ([Segment]): [线段i]
        seg_j ([Segment]): [线段j]
    """
    corns = [seg_i.ps, seg_i.pe, seg_j.ps, seg_j.pe]
    corns = np.array(corns).reshape((-1, 2)).astype('int')
    hull = cv2.convexHull(corns, False)
    hull = hull.reshape(-1, 2)
    hull = hull.tolist()
    return hull


def isFilled(canny_img, quad):
    """ 判断多边形是否充满图像

    Args:
        canny_img ([numpy]): [mask]
        quad ([list]): [points]
    """
    quad_dl = np.array(quad)
    rect = cv2.boundingRect(quad_dl)
    x, y, w, h = rect
    roi = canny_img[y: y + h, x: x + w]

    quad_dl = quad[:] # 深拷贝
    for quad_p in quad_dl:
        quad_p[0] -= x
        quad_p[1] -= y
    
    quads = [np.array(quad_dl)]
    mask = np.zeros((h, w))
    mask = cv2.fillPoly(mask, quads, 255)

    fill = (roi * mask).astype(np.uint8)

    total_cnt = cv2.countNonZero(mask)
    fill_cnt = cv2.countNonZero(fill)

    if fill_cnt * 1.0 / total_cnt > FILLED_RATIO:
        return True
    else:
        return False


def isVerticalLine(seg):
    """判断线段垂直还是水平

    Args:
        seg : [线段]
    """
    delta_x = abs(seg.ps[0] - seg.pe[0])
    delta_y = abs(seg.ps[1] - seg.pe[1])
    return delta_y > delta_x


def getPointDirectOnline(pt, seg):
    """求点在线段的那个方向
    0:top 1:bottom 2:left  3:right 4:in

    Args:
        pt ([type]): [点]
        seg ([type]): [线段]
    """
    p0 = seg.ps
    p1 = seg.pe
    min_x = min(p0[0], p1[0])
    max_x = max(p0[0], p1[0])
    min_y = min(p0[1], p1[1])
    max_y = max(p0[1], p1[1])
    if isVerticalLine(seg):
        if pt[1] >= min_y and pt[1] <= max_y:
            return 4
        elif pt[1] < min_y:
            return 2
        else:
            return 3
    else:
        if pt[0] >= min_x and pt[0] <= max_x:
            return 4
        elif pt[0] < min_x:
            return 2
        else:
            return 3


def getPointDist(pt1, pt2):
    """求2点的距离

    Args:
        pt1: 点1
        pt2: 点2
    """
    delta_x = 1.0 * abs(pt2[0] - pt1[0])
    delta_y = 1.0 * abs(pt2[1] - pt1[1])
    return math.sqrt(delta_x * delta_x + delta_y * delta_y)


def getSegmentsOverlaps(seg_i, seg_j, isReProj=True):
    """计算2条直线的重合度

    Args:
        seg_i : 线段
        seg_j : 线段
    """
    projectL = copy.deepcopy(seg_i)  # 存储短的线段
    projectdL= copy.deepcopy(seg_j)  # 存储长的线段
    if isReProj:
        if seg_i.len > seg_j.len:
            projectL, projectdL = projectdL, projectL
    
    p1 = projectL.ps
    p2 = projectL.pe
    if isReProj:
        p1 = incidentPoint(projectL.l, p1)
        p2 = incidentPoint(projectL.l, p2)
    # # print("点p1的坐标为:{}, 点p2的坐标为:{}".format(p1, p2))
    direct1 = getPointDirectOnline(p1, projectdL)
    direct2 = getPointDirectOnline(p2, projectdL)

    if direct1 == direct2: # 同侧
        if direct1 != 4:
            d1 = getPointDist(p1, projectdL.ps)
            d2 = getPointDist(p1, projectdL.pe)
            d3 = getPointDist(p2, projectdL.ps)
            d4 = getPointDist(p2, projectdL.pe)
            d = - min([d1, d2, d3, d4])
            return d
        else:
            return getPointDist(p1, p2)
    else:
        if not isVerticalLine(projectdL):  # 横线
            pStart = projectdL.pe if projectdL.ps[0] > projectdL.pe[0] else projectdL.ps
            pInterStart = p2 if p1[0] > p2[0] else p1

            if pStart[0] > pInterStart[0]:
                pStart = pInterStart
            
            pEnd = projectdL.ps if projectdL.ps[0] > projectdL.pe[0] else projectdL.pe

            pInterEnd = p1 if p1[0] > p2[0] else p2

            if pEnd[0] < pInterEnd[0]:
                pEnd = pInterEnd

            return getPointDist(pInterStart, pInterEnd)
        else: # 竖直的情况
            pStart = projectdL.pe if projectdL.ps[1] > projectdL.pe[1] else projectdL.ps
            pInterStart = p2 if p1[1] > p2[1] else p1

            if pStart[1] > pInterStart[1]:
                pStart = pInterStart
            
            pEnd = projectdL.ps if projectdL.ps[1] > projectdL.pe[1] else projectdL.pe

            pInterEnd = p1 if p1[1] > p2[1] else p2

            if pEnd[1] < pInterEnd[1]:
                pEnd = pInterEnd

            return getPointDist(pInterStart, pInterEnd)


def mergeLines(seg_i, seg_j):
    """合并2条线段，这是直接从opencv中抠出来的代码

    Args:
        seg_i : 线段1
        seg_j : 线段2
    """
    delta1x = 0.0
    delta1y = 0.0
    delta2x = 0.0
    delta2y = 0.0

    delta1xg = 0.0
    delta2xg = 0.0
    ax = seg_i.ps[0]
    ay = seg_i.ps[1]
    bx = seg_i.pe[0]
    by = seg_i.pe[1]
    cx = seg_j.ps[0]
    cy = seg_j.ps[1]
    dx = seg_j.pe[0]
    dy = seg_j.pe[1]
    dlix = bx - ax
    dliy = by - ay
    dljx = dx - cx
    dljy = dy - cy
    li = seg_i.len
    lj = seg_j.len

    xg = (li * float(ax + bx) + lj * float(cx + dx)) / (2.0 * (li + lj))
    yg = (li * float(ay + by) + lj * float(cy + dy)) / (2.0 * (li + lj))

    if dlix == 0.0:
        thi = CV_PI / 2.0
    else:
        thi = math.atan(dliy / dlix)
    
    if dljx == 0.0:
        thj = CV_PI / 2.0
    else:
        thj = math.atan(dljy / dljx)
    
    if abs(thi - thj) <= CV_PI / 2.0:
        thr = (li * thi + lj * thj) / (li + lj)
    else:
        tmp = thj - CV_PI * (thj / math.fabs(thj))
        thr = li * thi + lj * tmp
        thr = thr / (li + lj)
    
    axg = (float(ay) - yg) * math.sin(thr) + (float(ax) -  xg) * math.cos(thr)
    bxg = (float(by) - yg) * math.sin(thr) + (float(bx) -  xg) * math.cos(thr)
    cxg = (float(cy) - yg) * math.sin(thr) + (float(cx) -  xg) * math.cos(thr)
    dxg = (float(dy) - yg) * math.sin(thr) + (float(dx) -  xg) * math.cos(thr)

    delta1xg = min([axg, bxg, cxg, dxg])
    delta2xg = max([axg, bxg, cxg, dxg])

    delta1x = delta1xg * math.cos(thr) + xg
    delta1y = delta1xg * math.sin(thr) + yg
    delta2x = delta2xg * math.cos(thr) + xg
    delta2y = delta2xg * math.sin(thr) + yg

    ps_merged = [delta1x, delta1y]
    pe_merged = [delta2x, delta2y]
    seg_merged = Segment(ps_merged, pe_merged)
    return seg_merged
    

def mergeCrudeSegs(canny_img, segments):
    """合并原始的线段

    Args:
        canny_img ([numpy]): [mask]
        segments ([list]): [存储线段的属性]
    """
    n_segments = len(segments)
    isReserved = [True] * n_segments # 标记线段是否保留
    # 根据线段的长度进行排序，长线段在前
    segments = sorted(segments, key=lambda x: x.len, reverse=True)

    merges = []
    for i in range(n_segments):
        if not isReserved[i]:
            continue
        
        seg_i = segments[i]

        for j in range(i + 1, n_segments):
            seg_j = segments[j]
            angle_diff_tmp = getLineAngle(seg_i, seg_j)
            # # print("线段{}和线段{}的夹角为:{}".format(i, j, angle_diff_tmp))
            if angle_diff_tmp > MAX_CRUDE_ANGLE: # 两条线段夹角大于15度，此时不考虑合并
                continue
            dist_tmp = lineVerticalDist(seg_i, seg_j)
            # # print("线段{}和线段{}的垂直距离为:{}".format(i, j, dist_tmp))
            if dist_tmp > MAX_CRUDE_LINE_DIST: # 两线段之间的垂直距离大于15，此时不考虑合并
                continue
            quad_tmp = getSegmentsQuad(seg_i, seg_j)
            isFilled_tmp = isFilled(canny_img, quad_tmp)
            # # print("当前距离为:{}, 是否填充:{}".format(dist_tmp, isFilled_tmp))
            if dist_tmp > MIN_CRUDE_LINE_DIST and not isFilled_tmp: # 距离较近而且所围成的图像面积较大，此时保留
                continue
            
            overlaps = getSegmentsOverlaps(seg_i, seg_j)
            # # print("线段{}和线段{}的重合距离为:{}".format(i, j, overlaps))
            if overlaps < min(seg_i.len, seg_j.len) * MIN_CRUDE_OVERLAP_RATIO: # 线段重合度较小
                continue

            # # print("合并线段{}和线段{}".format(i, j))
            merge = mergeLines(seg_i, seg_j)
            merge.init_segment()
            merge.seg_type = 1
            merges.append(merge)
            isReserved[i] = False
            isReserved[j] = False
            break
    
    for i in range(n_segments):
        if isReserved[i]:
            merges.append(segments[i])
    
    return merges


def uniqueSegs(segments):
    """uniqueSegs
    """
    uniques = []
    segments_dl = copy.deepcopy(segments)
    for seg in segments_dl:
        isUnique = True
        for u in uniques:
            if seg.new_eq(u): 
            # if seg == u:  发现python中的赋值是深拷贝
                isUnique = False
                break
        if isUnique:
            uniqueSub = []
            for sub in seg.subSegs:
                isSubUnique = True
                for us in uniqueSub:
                    if us == sub:
                        isSubUnique = False
                if isSubUnique:
                    uniqueSub.append(sub)
            tmp = seg
            tmp.subSegs = uniqueSub
            uniques.append(tmp)
    return uniques


def mergeSubSegments(seg):
    """mergeSubSegments
    """
    if not seg.subSegs:
        return seg
    isHorizon = True
    delta_x = seg.ps[0] - seg.pe[0]
    delta_y = seg.ps[1] = seg.pe[1]
    if math.fabs(delta_x) < math.fabs(delta_y):
        isHorizon = False
    
    if isHorizon:
        seg.subSegs = sorted(seg.subSegs, key= lambda x: x.center[0], reverse=True)
    else:
        seg.subSegs = sorted(seg.subSegs, key= lambda x: x.center[1], reverse=True)
    
    newSubs = []
    n_sub_size = len(seg.subSegs)
    for i in range(1, n_sub_size, 1):
        overlap = getSegmentsOverlaps(seg.subSegs[i - 1], seg.subSegs[i])
        if overlap > 0:
            merge = mergeLines(seg.subSegs[i - 1], seg.subSegs[i])
            merge.init_segment()
            seg.subSegs[i] = merge
        else:
            newSubs.append(seg.subSegs[i - 1])
    seg.subSegs = newSubs
    return seg


def mergeFineSegs(canny_img, segments):
    """精细化合并线段

    Args:
        canny_img : mask
        segments : 线段
    """
    segments = sorted(segments, key=lambda x: x.len, reverse=True)
    # init segment ref
    n_segments = len(segments)
    for i in range(n_segments):
        segments[i].ref = i
    
    segmentRaws = copy.deepcopy(segments)
    segmentDLs = copy.deepcopy(segments)

    for i in range(n_segments):
        seg_i = segmentDLs[i]
        for j in range(i + 1, n_segments):
            seg_j = segmentDLs[j]
            angle_diff = getLineAngle(seg_i, seg_j)
            # # print("线段{}和线段{}的夹角为:{}".format(i, j, angle_diff))
            if angle_diff > MAX_FINE_ANGLE:
                continue
            dist_tmp = lineVerticalDist(seg_i, seg_j)
            # # print("线段{}和线段{}的垂直距离为:{}".format(i, j, dist_tmp))
            if dist_tmp > MAX_FINE_LINE_DIST:
                continue
            
            overlaps = getSegmentsOverlaps(seg_i, seg_j)
            # # print("线段{}和线段{}的重合距离为:{}".format(i, j, overlaps))
            if overlaps < 0 and math.fabs(overlaps) > MIN_FINE_OVERLAP_RATIO * (seg_i.len + seg_j.len): # 这里合并平行的线段
                continue
            
            # # print("精细化合并线段{}和线段{}".format(i, j))
            merge = mergeLines(seg_i, seg_j)
            merge.init_segment()
            merge.seg_type = 2
            merge.ref = seg_i.ref
            segmentDLs[i] = copy.deepcopy(merge)
            segmentDLs[j] = copy.deepcopy(merge)
            break
    

    # update same ref
    fineSubMerges = [[] for _ in range(n_segments)]
    merges = []  # 存储没有合并的线段
    # 打印当前线段的属性
    # for i, debug_seg in enumerate(segmentDLs):
    #     # print("第{}条线段的属性为:{}".format(i, debug_seg.seg_type))
    #     # print("第{}条线段的ref为:{}".format(i, debug_seg.ref))

    for i in range(n_segments - 1, -1, -1):
        if segmentDLs[i].seg_type == 2:
            if not fineSubMerges[segmentDLs[i].ref]:
                segmentDLs[segmentDLs[i].ref] = segmentDLs[i]
            fineSubMerges[segmentDLs[i].ref].append(segmentRaws[i])
        else:
            merges.append(segmentRaws[i])

    
    for i in range(n_segments):
        if not fineSubMerges: # 如果没有合并成的线段
            segmentDLs[i].subSegs = fineSubMerges[i]
            merges.append(segmentDLs[i])
    
    uniques = uniqueSegs(segmentDLs)  # 得到合并后的线段并且标记是由那几条线段合并而成的
    for i, seg in enumerate(uniques):
        uniques[i] = mergeSubSegments(seg)  # 将子线段进行合并
    
    # debug_img = draw_segments(canny_img, uniques)
    # cv2.imwrite('debug_mergeFine.jpg', debug_img)
    
    return copy.deepcopy(uniques)


def filterSegs(segments):
    """过滤线段

    Args:
        segments: 线段
    """
    filter = []
    for seg in segments:
        if seg.len >= MIN_LINE_LEN:
            filter.append(seg)
    
    filter = sorted(filter, key= lambda x: x.len, reverse=True)
    if len(filter) > MAX_LINE_NUM:
        filter = filter[:MAX_LINE_NUM]
    return filter


def getSegmentIntersection(seg_i, seg_j):
    """计算2条直线的交点

    Args:
        seg_i: 线段i
        seg_j: 线段j

    Returns:
        返回交点坐标
    """
    inter = np.cross(seg_i.l, seg_j.l)
    ans = []
    if inter[2] == 0: # 平行
        return False, ans
    else:
        x_tmp = int(1.0 * inter[0] / inter[2])
        y_tmp = int(1.0 * inter[1] / inter[2])
        ans = [x_tmp, y_tmp]
    return True, ans


def isSegmentIntersection(seg_i, seg_j):
    """isSegmentIntersection
    """
    inter = np.cross(seg_i.l, seg_j.l)
    intersection = []
    if inter[2] == 0:
        return lineVerticalDist(seg_i, seg_j) <= MIN_LINE_LEN
    else:
        intersection.append(inter[0] / inter[2])
        intersection.append(inter[1] / inter[2])

        if isPointOnLine(intersection, seg_i) or isPointOnLine(intersection, seg_j):
            return True
        return False


def isPointOnLine(pt, seg):
    """isPointOnLine
    """
    p0 = seg.ps
    p1 = seg.pe
    min_x = min(p0[0], p1[0])
    max_x = max(p0[0], p1[0])
    min_y = min(p0[1], p1[1])
    max_y = max(p0[1], p1[1])
    return pt[0] >= min_x and pt[0] <= max_x and pt[1] >= min_y and pt[1] <= max_y


def testCornerInBoard(corner, canny_img, canOut=True):
    """testCornerInBoard
    """
    h, w = canny_img.shape
    if canOut:
        return corner.pt[0] >= -(w // 3) and \
            corner.pt[0] < w // 3 + w and \
            corner.pt[1] >= - (h // 3) and corner.pt[1] < h // 3 + h
    else:
        return corner.pt[0] >= 0 and \
            corner.pt[0] < w and \
            corner.pt[1] >= 0 and corner.pt[1] < h


def calcCorners(canny_img, segs, isLoose=False):
    """根据检测出的线段计算角点

    Args:
        canny_img : mask
        segs : 线段
        isLoose : 标志
    """
    
    corners = [] # 存储检测出的角点
    n_segments = len(segs)
    lineWithCornerIds = [[] for _ in range(n_segments)] # 存储每一条线段上对应的角点索引
    for i in range(n_segments):
        seg_i = segs[i]
        for j in range(i + 1, n_segments):
            seg_j = segs[j]
            angle = getLineAngle(seg_i, seg_j)
            if angle < MIN_CORNER_ANGLE:
                # # print("线段{} 和线段{}之间的角度大于{}".format(i, j, MIN_CORNER_ANGLE))
                continue
            flag, cornerPt = getSegmentIntersection(seg_i, seg_j)
            if not flag: # 如果平行
                # # print("线段{} 和线段{}平行".format(i, j))
                continue
            miss1 = 0
            miss2 = 0
            miss1Ratio = 0
            miss2Ratio = 0
            if not isPointOnLine(cornerPt, seg_i):
                dist1 = getPointDist(cornerPt, seg_i.ps)
                dist2 = getPointDist(cornerPt, seg_i.pe)
                miss1Ratio += min(dist1, dist2) / seg_i.len
                miss1 += min(dist1, dist2)
            
            if not isPointOnLine(cornerPt, seg_j):
                dist1 = getPointDist(cornerPt, seg_j.ps)
                dist2 = getPointDist(cornerPt, seg_j.pe)
                miss2Ratio += min(dist1, dist2) / seg_j.len
                miss2 += min(dist1, dist2)
            
            corner = Corner(cornerPt)
            corner.lineIds.append(i)
            corner.lineIds.append(j)
            
            isIn = testCornerInBoard(corner, canny_img, False)
            blank_ratio = MIN_CORNER_BLANK_RATIO if isIn else MIN_CORNER_BLANK_RATIO_OUTBOARD  # 1.5
            blank_ratio = MIN_CORNER_BLANK_RATIO_LOOSE if isLoose else blank_ratio

            if miss1Ratio > blank_ratio or miss2Ratio > blank_ratio:
                # # print("线段{} 和线段{}的角点不合理".format(i, j))
                continue

            minLen = min(seg_i.len, seg_j.len)
            maxLen = max(seg_i.len, seg_j.len)

            two_line_ratio = MIN_CORNER_TWO_LINE_RATIO_LOOSE if isLoose else MIN_CORNER_TWO_LINE_RATIO
            if minLen / maxLen <= two_line_ratio:
                continue
            if not testCornerInBoard(corner, canny_img):
                continue
            # # print("当前角点是由线段{} 和线段{}组成".format(i, j))

            corner.score += (miss1Ratio + miss2Ratio)
            corners.append(corner)
            lineWithCornerIds[i].append(len(corners) - 1)
            lineWithCornerIds[j].append(len(corners) - 1)
    
    # 根据角点的置信度进行排序
    corners = sorted(corners, key=lambda x: x.score)
    return corners if len(corners) < MAX_CORNER_NUM else corners[:MAX_CORNER_NUM]


def getBoardLine():
    """getBoardLine
    """
    pt_top = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
    pt_left = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING]
    pt_right = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
    pt_bottom = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING]

    seg_top = Segment(pt_top, pt_right)
    seg_bottom = Segment(pt_left, pt_right)
    seg_left = Segment(pt_top, pt_left)
    seg_right = Segment(pt_right, pt_bottom)

    segs = [seg_top, seg_bottom, seg_left, seg_right]
    for seg in segs:
        seg.init_segment()
    return segs


def calcEdgeQuad(canny_img, merges, corners):
    """calcEdgeQuad
    """
    quadPts = []
    quad = []
    if len(merges) < 2: # 只有一条线段肯定不可以组成一个多边形
        return False, quadPts
    
    right_angle = 90.0
    n_corners = len(corners)
    n_segs = len(merges)
    h, w = canny_img.shape

    for i in range(n_corners):
        seg_i = merges[corners[i].lineIds[0]]
        seg_j = merges[corners[i].lineIds[1]]
        if seg_i.len < h / 3 or seg_j.len < h / 3:  # 线段长度太短
            continue
        angle_diff = getLineAngle(seg_i, seg_j)
        if angle_diff - right_angle > EDGE_QUAD_TWO_STRAIGHT_SEG_DELTA_ANGEL:  # 两边的夹角太小
            continue
        seg1_d1 = getPointDist(corners[i].pt, seg_i.ps)
        seg1_d2 = getPointDist(corners[i].pt, seg_i.pe)
        seg2_d1 = getPointDist(corners[i].pt, seg_j.ps)
        seg2_d2 = getPointDist(corners[i].pt, seg_j.pe)
        # 角点离线段太远
        if math.fabs(max(seg1_d1, seg1_d2)) -  seg_i.len > EDGE_QUAD_SEG_NO_OVERLAP_DIST or \
            math.fabs(max(seg2_d1, seg2_d2)) -  seg_j.len > EDGE_QUAD_SEG_NO_OVERLAP_DIST:
            continue
        seg1_far_pt = seg_i.ps if seg1_d1 > seg1_d2 else seg_i.pe
        seg2_far_pt = seg_j.ps if seg2_d1 > seg2_d2 else seg_j.pe

        # 满足要求的条件为:
        # 离角点比较远的2个点离边缘比较近，而且远处点出没有检测出来直线
        # 添加四条边
        boards = getBoardLine()
        p1 = seg1_far_pt + [1.0]
        p1_array = np.array(p1).astype(float)
        p2 = seg2_far_pt + [1.0]
        p2_array = np.array(p2).astype(float)

        min_dis_p1 = LARGE_NUM
        min_dis_p2 = LARGE_NUM

        min_dis_p1_id = 0
        min_dis_p2_id = 0

        # 找到距离最近的边界线
        for j in range(4):
            dis_p1 = math.fabs(distPointLine(p1_array, boards[j].l))
            if min_dis_p1 > dis_p1:
                min_dis_p1 = dis_p1
                min_dis_p1_id = j
            
            dis_p2 = math.fabs(distPointLine(p2_array, boards[j].l))
            if min_dis_p2 > dis_p2:
                min_dis_p2 = dis_p2
                min_dis_p2_id = j
        
        if min_dis_p1 > EDGE_QUAD_SEG_TO_EDGE_DIST or min_dis_p2 > EDGE_QUAD_SEG_TO_EDGE_DIST:
            continue

        noNearLine = True  # 判断附近是否有比较靠近的直线
        for j in range(n_segs):
            if j == corners[i].lineIds[0] or j == corners[i].lineIds[1]:
                continue
            else:
                p1 = merges[j].ps + [1.0]
                p1_array = np.array(p1).astype(float)
                p2 = merges[j].pe + [1.0]
                p2_array = np.array(p2).astype(float)
                dis_p1_seg1 = math.fabs(distPointLine(p1_array, seg_i.l))
                dis_p2_seg1 = math.fabs(distPointLine(p2_array, seg_i.l))
                dis_p1_seg2 = math.fabs(distPointLine(p1_array, seg_j.l))
                dis_p2_seg2 = math.fabs(distPointLine(p2_array, seg_j.l))
                if min([dis_p1_seg1, dis_p2_seg1, dis_p1_seg2, dis_p2_seg2]) < EDGE_QUAD_PT_TO_SEG_DIST:
                    noNearLine = False
                    break
        
        # 如果附近有比较靠近的直线，直接跳过
        if not noNearLine:
            continue

        edge1 = boards[min_dis_p1_id]
        edge2 = boards[min_dis_p2_id]

        angle_diff = getLineAngle(edge1, edge2)

        if getLineAngle(edge1, edge2) - right_angle > EDGE_QUAD_TWO_EDGE_DELTA_ANGEL: # 平行
            continue

        flag, edge_pt = getSegmentIntersection(edge1, edge2) # 交点
        if not flag:
            continue
        quad_pts = [corners[i].pt, seg1_far_pt, seg2_far_pt, edge_pt]
        quad_pts_array = np.array(quad_pts).reshape((-1, 2))
        hull = cv2.convexHull(quad_pts_array, False, False)
        hull = hull.reshape((-1, 2))
        hull = hull.tolist()
        if len(hull) != len(quad_pts):
            continue
        
        for i in range(len(hull)):
            quad.append(quad_pts[hull[i]])
        
        for pt in quad:
            pt = pt - HANDLE_IMAGE_PADDING
            # 这里没有resize到原图
        if quad:
            return True, quad
        else:
            return False, quad
    return False, []


def checkEnoughPoints(corner_pt, segCornerInfo):
    """判断线段上是否至少有2个角点

    Args:
        corner_pt: 角点
        segCornerInfo: 线段角点信息

    Returns:
        True/False
    """
    for l_id in corner_pt.lineIds:
        if len(segCornerInfo[l_id]) < 2:
            return False
    return True


def findCornersLine(c_i, c_j):
    """找到2个角点组成的线段id

    Args:
        c_i : 角点1
        c_j : 角点2

    Returns:
        返回角点组成的线段id, -1 表示没有共同的线段
    """
    for l1 in c_i.lineIds:
        for l2 in c_j.lineIds:
            if l1 == l2:
                return l1
    return -1


def isConvexQuad(corners):
    """isConvexQuad
    """
    if len(corners) != QUAD_CORNER_NUM:
        return False, []
    
    quads = []
    for corner in corners:
        quads.append(corner.pt)
    
    quads_array = np.array(quads).reshape((-1, 2))
    hull = cv2.convexHull(quads_array, clockwise=False, returnPoints=False)
    # # print(hull)

    if len(hull) != QUAD_CORNER_NUM:
        return False, []
    
    newCorners = []
    for i in range(len(hull)):
        index_tmp = hull[i][0]
        newCorners.append(corners[index_tmp])
    
    return True, newCorners


def draw_test(img, corners, graph_tmp):
    """
    draw_test
    """
    edges = graph_tmp.graph_
    h, w = img.shape
    img_draw = np.zeros_like((h, w, 3))
    for edge in edges:
        ps = corners[edge.v1].pt
        pe = corners[edge.v2].pt
        ps = tuple(map(int, ps))
        pe = tuple(map(int, pe))
        cv2.line(img_draw, ps, pe, (255, 255, 255), 1)
    return img_draw


def calcQuad(canny_img, segments, corners, isLoose=False):
    """计算角点和边围成的四边形

    Args:
        canny_img : mask
        segs : 线段
        corners : 角点
        isLoose : Defaults to False.
    """
    if len(corners) < QUAD_CORNER_NUM:
        return []
    
    n_corners = len(corners)
    # # print("一共有{}条线段".format(len(segments)))
    n_segs = len(segments)
    h, w = canny_img.shape
    segCornerIds = [[] for _ in range(n_segs)] # 存储每一条线段对应的角点
    quads = []

    for i in range(n_corners):
        segCornerIds[corners[i].lineIds[0]].append(i)
        segCornerIds[corners[i].lineIds[1]].append(i)
    
    # # print("当前线段的角点为:{}".format(segCornerIds))

    graph = Graph()

    for i in range(n_corners):
        c_i = corners[i]
        isCiIn = testCornerInBoard(c_i, canny_img, False)
        if not checkEnoughPoints(c_i, segCornerIds):
            continue
        for j in range(i + 1, n_corners):
            c_j = corners[j]
            lineId = findCornersLine(c_i, c_j)

            if lineId < 0: # 说明没有共有的线段
                # # print("当前的角点对为:{}, {}".format(i, j))
                continue
        
            dist = getPointDist(c_i.pt, c_j.pt)
            if dist < MIN_CORNER_DIST: # 角点太近
                continue

            seg_tmp = Segment(c_i.pt, c_j.pt)

            isCjIn = testCornerInBoard(c_j, canny_img, False)

            overlapsRatio = DOTTED_SOLID_LINE_RATIO_OUTBOARD if not isCiIn or not isCjIn else DOTTED_SOLID_LINE_RATIO
            overlapsRatio = DOTTED_SOLID_LINE_RATIO_LOOSE if isLoose else overlapsRatio

            overlaps = getSegmentsOverlaps(seg_tmp, segments[lineId], False)
            # # print("角点对是:{}, {}".format(i, j))

            if overlaps / dist < overlapsRatio:
                continue
            
            graph.addEdgeFast(i, j)
    
    # # print("edges:{}".format(graph.edgeNum()))
    # debug_img = draw_test(canny_img, corners, graph)
    # cv2.imwrite('test_edges.jpg', debug_img)

    cycles = graph.findAllCyclesFast(QUAD_CORNER_NUM)


    # 选择最好的闭环
    for cycle in cycles:
        quadCorners = []
        lines = set()
        for v in cycle:
            quadCorners.append(corners[v])
            lines.add(corners[v].lineIds[0])
            lines.add(corners[v].lineIds[1])
        
        if len(lines) != QUAD_CORNER_NUM: # 4个点中有三个以上的点在一条直线上
            continue
        
        tmp = isConvexQuad(quadCorners)
        flag_tmp, quadCorners = tmp
        if not flag_tmp:
            continue

        overlaps = 0
        perimeter = 0
        isValidQuad = True
        for i in range(len(quadCorners)):
            last_c = quadCorners[(i + QUAD_CORNER_NUM - 1) % QUAD_CORNER_NUM]
            now_c = quadCorners[i]
            next_c = quadCorners[(i + 1) % QUAD_CORNER_NUM]
            lineId = findCornersLine(now_c, next_c)
            if lineId < 0:
                isValidQuad = False
                break

            seg1 = Segment(last_c.pt, now_c.pt)
            seg2 = Segment(now_c.pt, next_c.pt)

            seg1.init_segment()
            seg2.init_segment()

            angle_diff = getLineAngle(seg1, seg2)
            if angle_diff <= MIN_CORNER_ANGLE:
                isValidQuad = False
                break

            seg_tmp = Segment(now_c.pt, next_c.pt)
            if segments[lineId].subSegs:
                for sub in segments[lineId].subSegs:
                    o = getSegmentsOverlaps(seg_tmp, sub, False)
                    if o > 0:
                        overlaps += o
                        overlaps -= QUAD_EXCEED_LINE_PUNISH * (sub.len - o)
            
            else:
                if segments[lineId].seg_type != 3:
                    o = getSegmentsOverlaps(seg_tmp, segments[lineId], False)
                    if o > 0:
                        overlaps += o
                        overlaps -= QUAD_EXCEED_LINE_PUNISH * (segments[lineId].len - o)
            
            if segments[lineId].seg_type != 3:
                perimeter += getPointDist(now_c.pt, next_c.pt)
        
        if not isValidQuad:
            continue

        quad = Quad(quadCorners)
        quad.score = overlaps - QUAD_BLANK_SCORE_PUNISH * (perimeter - overlaps)
        quads.append(quad)

        # # print("find quads:{}".format(len(quads)))

        return quads
    return []


def addBoardLine(segs):
    """addBoardLine
    """
    boards = getBoardLine()
    boardLines = []
    for b in boards:
        inters = []
        for seg in segs:
            flag, inter = getSegmentIntersection(seg, b)
            if not flag:
                continue
            if not isPointOnLine(inter, b):
                continue

            d1 = getPointDist(inter, seg.ps)
            d2 = getPointDist(inter, seg.pe)

            if min(d1, d2) <= MIN_BOARD_LINE_DIST:
                inters.append(inter)
        
        if len(inters) >= 2:
            minX = [LARGE_NUM, LARGE_NUM]
            minY = [LARGE_NUM, LARGE_NUM]
            maxX = [-1, -1]
            maxY = [-1, -1]
            for in_tmp in inters:
                if minX[0] >= in_tmp[0]:
                    minX = in_tmp
                
                if minY[1] >= in_tmp[1]:
                    minY = in_tmp
                
                if maxX[0] <= in_tmp[0]:
                    maxX = in_tmp

                if maxY[1] <= in_tmp[1]:
                    maxY = in_tmp
            
            d1 = maxX[0] - minX[0]
            d2 = maxY[1] - minY[1]

            boardLine = Segment(minX, maxX) if d1 > d2 else Segment(minY, maxY)
            boardLine.init_segment()

            boardLine.seg_type = 3
            isExist =False
            for seg in segs:
                if lineVerticalDist(seg, boardLine) < MIN_BOARD_LINE_EXIST_DIST  and \
                    getLineAngle(seg, boardLine) < MIN_BOARD_LINE_EXIST_ANGLE and \
                    min(seg.len, boardLine.len) / max(seg.len, boardLine.len) > MIN_BOARD_LINE_EXIST_RATIO:
                    isExist = True
                    break
            
            if not isExist:
                boardLines.append(boardLine)
    seg_res = copy.deepcopy(segs)
    seg_res.extend(boardLines[:])
    return seg_res


def tryQuadWithBoardLine(canny_img, inSegs, inCorners):
    """尝试使用边界线形成多边形

    Args:
        inSegs: 线段
        inCorners: 角点
    """
    # 
    outSegs = copy.deepcopy(inSegs)
    outSegs = addBoardLine(outSegs)
    # debug_img = draw_segments(canny_img, outSegs)
    # cv2.imwrite('debug_corner_case_add_board.jpg', debug_img)
    outCorners = copy.deepcopy(inCorners)
    quads = []
    
    debug_img_segment_add_board = draw_segments(canny_img, outSegs)
    cv2.imwrite('test_segment_0719.jpg', debug_img_segment_add_board)
    flag = False
    ans = dict()
    if len(outSegs) != len(inSegs):
        outCorners = calcCorners(canny_img, outSegs)
        add_corner_number = len(outCorners) - len(inCorners)
        # # print("add boardline calcCorners: {}".format(add_corner_number))
    
        quads = calcQuad(canny_img, outSegs, outCorners)
        flag = True
    
    if not quads:
        flag = False
    
    ans['segments'] = outSegs
    ans['corners'] = outCorners
    ans['quads'] = quads
    ans['flag'] = flag
    return ans


def addMoreSegs(inSegs, outSegs):
    """addMoreSegs
    """
    res_segs = copy.deepcopy(outSegs)
    n_in_segs = len(inSegs)
    for i in range(n_in_segs):
        seg_i = inSegs[i]
        for j in range(i + 1, n_in_segs):
            seg_j = inSegs[j]

            if isSegmentIntersection(seg_i, seg_j):
                continue

            d1 = min(seg_i.len, seg_j.len)
            d2 = max(seg_i.len, seg_j.len)

            if d1 / d2 < QUAD_SEG_LEN_RATIO:
                continue

            seg1 = Segment(seg_i.ps, seg_j.ps)
            seg2 = Segment(seg_i.pe, seg_j.pe)
            seg1.init_segment()
            seg2.init_segment()
            seg1.seg_type = 3
            seg2.seg_type = 3

            angle_diff1 = getLineAngle(seg1, seg_i)
            angle_diff2 = getLineAngle(seg2, seg_i)
            angle_diff3 = getLineAngle(seg1, seg_j)
            angle_diff4 = getLineAngle(seg2, seg_j)

            min_angle = min([angle_diff1, angle_diff2, angle_diff3, angle_diff4])

            if min_angle < MIN_CORNER_ANGLE:
                continue

            isExist1 = False
            isExist2 = False
            for o in outSegs:
                if getLineAngle(o, seg1) <= MIN_BOARD_LINE_EXIST_ANGLE and \
                    lineVerticalDist(o, seg1) <= MIN_BOARD_LINE_EXIST_DIST and \
                    min(o.len, seg1.len) / max(o.len, seg1.len) >= MIN_BOARD_LINE_EXIST_RATIO:
                    isExist1 = True

                if getLineAngle(o, seg2) <= MIN_BOARD_LINE_EXIST_ANGLE and \
                    lineVerticalDist(o, seg2) <= MIN_BOARD_LINE_EXIST_DIST and \
                    min(o.len, seg2.len) / max(o.len, seg2.len) >= MIN_BOARD_LINE_EXIST_RATIO:
                    isExist2 = True
            
            if not isExist1 and seg1.len > CORNER_CASE_LINE_LEN:
                res_segs.append(seg1)
            
            if not isExist2 and seg2.len > CORNER_CASE_LINE_LEN:
                res_segs.append(seg2)
    return res_segs
            

def addVertexSegs(canny_img, inSegs):
    """addVertexSegs
    """
    horizontals = [] # 存储水平线段
    verticals = [] # 存储竖值线段
    outCorners = [] # 存储返回的角点
    for seg in inSegs:
        if seg.len < CORNER_CASE_LINE_LEN:
            continue

        seg_tmp = copy.deepcopy(seg)
        seg_tmp.sort()
        delta_x = seg.ps[0] - seg.ps[1]
        delta_y = seg.ps[1] - seg.pe[1]
        if math.fabs(delta_x) > math.fabs(delta_y):
            horizontals.append(seg_tmp)
        else:
            verticals.append(seg_tmp)
    
    horizontals = sorted(horizontals, key=lambda x: x.len, reverse=True)
    verticals = sorted(verticals, key=lambda x: x.len, reverse=True)
    
    debug_segments = []
    debug_segments.extend(horizontals[:])
    debug_segments.extend(verticals[:])
    debug_img = draw_segments(canny_img, debug_segments)
    cv2.imwrite('debug_addVertexSegs.jpg', debug_img)

    horizontalTmp = copy.deepcopy(horizontals)
    verticalsTmp = copy.deepcopy(verticals)

    horizontalTmp = horizontalTmp[:CORNER_CASE_MAX_AUTO_NEW_LINE] \
            if len(horizontalTmp) > CORNER_CASE_MAX_AUTO_NEW_LINE else horizontalTmp
    
    verticalsTmp = verticalsTmp[:CORNER_CASE_MAX_AUTO_NEW_LINE] \
            if len(verticalsTmp) > CORNER_CASE_MAX_AUTO_NEW_LINE else verticalsTmp
    
    horizontals = addMoreSegs(verticalsTmp, horizontals)  # 根据垂直线补水平的线

    if len(horizontals) < 2: # 补完之后水平线段数目小于2
        top_pt_s = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
        top_pt_e = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
        bottom_pt_s = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING]
        bottom_pt_e = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING]
        top = Segment(top_pt_s, top_pt_e)
        bottom = Segment(bottom_pt_s, bottom_pt_e)
        top.init_segment()
        bottom.init_segment()
        top.seg_type = 3
        bottom.seg_type = 3
        
        if not horizontals: # 如果原来是空的，那么补上边界线
            horizontals.append(top)
        horizontals.append(bottom)

    verticals = addMoreSegs(horizontalTmp, verticals)

    if len(verticals) < 2:
        left_pt_s = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
        left_pt_e = [HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING]
        right_pt_s = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_PADDING]
        right_pt_e = [HANDLE_IMAGE_W - HANDLE_IMAGE_PADDING, HANDLE_IMAGE_H - HANDLE_IMAGE_PADDING]

        left = Segment(left_pt_s, left_pt_e)
        right = Segment(right_pt_s, right_pt_e)
        left.init_segment()
        right.init_segment()
        left.seg_type = 3
        right.seg_type = 3
        if not verticals:
            verticals.append(left)
        verticals.append(right)
        
    horizontals = sorted(horizontals, key=lambda x: x.len, reverse=True)
    verticals = sorted(verticals, key=lambda x: x.len, reverse=True)

    outSegs = horizontals[:]
    outSegs.extend(verticals[:])
    # debug_img = draw_segments(canny_img, outSegs)
    # cv2.imwrite('debug_addVertexSegs_v3.jpg', debug_img)

    startVIdx = len(horizontals) # 竖直线起始id
    for i in range(len(horizontals)):
        seg_h = horizontals[i]
        for j in range(len(verticals)):
            seg_v = verticals[j]

            angle = getLineAngle(seg_h, seg_v)

            if angle < MIN_CORNER_ANGLE:
                continue
            
            flag, cornerPt = getSegmentIntersection(seg_h, seg_v)
            if not flag:
                continue

            miss1 = 0
            miss2 = 0
            miss1Ratio = 0
            miss2Ratio = 0
            if not isPointOnLine(cornerPt, seg_h):
                dist1 = getPointDist(cornerPt, seg_h.ps)
                dist2 = getPointDist(cornerPt, seg_h.pe)
                miss1Ratio += min(dist1, dist2) / seg_h.len
                miss1 += min(dist1, dist2)
        
            if not isPointOnLine(cornerPt, seg_v):
                dist1 = getPointDist(cornerPt, seg_v.ps)
                dist2 = getPointDist(cornerPt, seg_v.pe)
                miss2Ratio += min(dist1, dist2) / seg_v.len
                miss2 += min(dist1, dist2)
        
            corner = Corner(cornerPt)
            corner.lineIds.append(i)
            corner.lineIds.append(startVIdx + j)
        
            isIn = testCornerInBoard(corner, canny_img, False)
            # 这里是补的线，因此这里设置为1.5
            blank_ratio = MIN_CORNER_BLANK_RATIO if isIn else MIN_CORNER_BLANK_RATIO_OUTBOARD  # 1.5

            if miss1Ratio > blank_ratio or miss2Ratio > blank_ratio:
                continue

            minLen = min(seg_h.len, seg_v.len)
            maxLen = max(seg_h.len, seg_v.len)

            two_line_ratio = MIN_CORNER_TWO_LINE_RATIO
            if minLen / maxLen <= two_line_ratio:
                continue
            if not testCornerInBoard(corner, canny_img):
                continue

            corner.score += (miss1Ratio + miss2Ratio)
            outCorners.append(corner)
    
    outCorners = sorted(outCorners, key=lambda x: x.score)
    outCorners = outCorners[:MAX_CORNER_NUM] if len(outCorners) > MAX_CORNER_NUM else outCorners
    res_info = {}
    res_info['outCorners'] = outCorners
    res_info['outSegs'] = outSegs
    return res_info


def generateImageEdgeQuad(canny_img):
    """generateImageEdgeQuad
    """
    h, w = canny_img.shape
    c1 = Corner((0, 0))
    c2 = Corner((w - 1, 0))
    c3 = Corner((h - 1, w - 1))
    c4 = Corner((0, h - 1))
    quadOut = Quad([c1, c2, c3, c4])
    return quadOut


def isTrapezoid(quad, segs, isLoose):
    """isTrapezoid
    """
    quadCorners = quad.corners
    quadSegs = []
    n_corners = len(quadCorners)
    for i in range(n_corners):
        now_c = quadCorners[i]
        next_c = quadCorners[(i + 1) % QUAD_CORNER_NUM]
        seg = Segment(now_c.pt, next_c.pt)
        seg.init_segment()
        seg.seg_type = 3
        quadSegs.append(seg)
    
    angDiff1 = getLineAngle(quadSegs[0], quadSegs[1])
    angDiff2 = getLineAngle(quadSegs[1], quadSegs[3])

    angleOffset = QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET_LOOSE if isLoose else QUAD_TWO_PARALLEL_LINE_ANGLE_OFFSET

    if math.fabs(angDiff1 - angDiff2) > angleOffset:
        return True
    
    elif min(angDiff1, angDiff2) > QUAD_TWO_PARALLEL_LINE_MIN_ANGLE:
        return True
    
    return False


def addExtendNearEdgeSegs(inSegs, corners, outSegs):
    """addExtendNearEdgeSegs
    """
    boards = getBoardLine() # 上，下，左，右
    dirSegsWithId = [[] for i in range(4)] # 存储上下左右边界附近的线段 0:top 1:bottom 2 left 3:right
    n_segs = len(inSegs)
    for i in range(n_segs):
        seg_i = inSegs[i]
        boardAngles = [] # 存储与边缘的角度
        for j in range(len(boards)):
            seg_j = boards[j]
            angle = getLineAngle(seg_i, seg_j)
            boardAngles.append(angle)
        
        min_x = min(seg_i.ps[0], seg_j.pe[0])
        max_x = max(seg_i.ps[0], seg_j.pe[0])
        min_y = min(seg_i.ps[1], seg_j.pe[1])
        max_y = max(seg_i.ps[1], seg_j.pe[1])

        if min_y < NEAR_BOARD_PADDING and boardAngles[0] < MAX_NEAR_BOARDLINE_ANGLE \
                    and seg_i.len > MIN_NEAR_BOARDLINE_LENGHT:
            dirSegsWithId[0].append((0, seg_i))
        
        elif max_y > HANDLE_IMAGE_W - NEAR_BOARD_PADDING and boardAngles[1] <  \
                MAX_NEAR_BOARDLINE_ANGLE and seg_i.len > MIN_NEAR_BOARDLINE_LENGHT: \
            dirSegsWithId[1].append((1, seg_i))
        
        elif min_x < NEAR_BOARD_PADDING and boardAngles[2] < MAX_NEAR_BOARDLINE_ANGLE  \
                        and seg_i.len > MIN_NEAR_BOARDLINE_LENGHT:
            dirSegsWithId[2].append((2, seg_i))
        
        elif max_x > HANDLE_IMAGE_W - NEAR_BOARD_PADDING and boardAngles[3] <  \
                    MAX_NEAR_BOARDLINE_ANGLE and seg_i.len > MIN_NEAR_BOARDLINE_LENGHT:
            dirSegsWithId[3].append((3, seg_i))
        
        else:
            outSegs.append(seg_i)
    
    needExpandLinesWithId = [] # 需要补线的线段
    for i in range(4):
        if dirSegsWithId[i]: # 当前这个方向
            dir_Segs_dl = copy.deepcopy(dirSegsWithId[i])
            print("dir_Segs_dl=", dir_Segs_dl)
            dir_Segs_dl = sorted(dir_Segs_dl, key=lambda x: x[1].len, reverse=True)
            needExpandLinesWithId.append(dir_Segs_dl[0])
    
    if not needExpandLinesWithId: # 没有需要补的线段
        return
    

    for i in range(len(needExpandLinesWithId)):
        direct, seg = needExpandLinesWithId[i]
        seg.sort()
        segP1ExsitCornerCnt = 0
        segP2ExsitCornerCnt = 0 

        for c in range(len(corners)):
            pt_tmp = corners[c].pt
            dist1 = getPointDist(seg.ps, pt_tmp)
            dist2 = getPointDist(seg.pe, pt_tmp)

            if dist1 < MIN_LINE_PT_TO_CORNERS_DIS:
                segP1ExsitCornerCnt += 1
            
            if dist2 < MIN_LINE_PT_TO_CORNERS_DIS:
                segP2ExsitCornerCnt += 1
            
        if segP1ExsitCornerCnt >= 1 and segP2ExsitCornerCnt >= 1:
            continue

        if segP1ExsitCornerCnt >= 1:
            if isVerticalLine(seg):
                slope = (seg.pe[0] - seg.ps[0]) / (seg.pe[1] - seg.ps[1])
                seg.pe[1] = HANDLE_IMAGE_H - 1
                seg.pe[0] = (seg.pe[1] - seg.ps[1]) * slope + seg.ps[0]
            else:
                slope = (seg.pe[1] - seg.ps[1]) / (seg.pe[0] - seg.ps[0])
                seg.pe[0] = HANDLE_IMAGE_W - 1
                seg.pe[1] = (seg.pe[0] - seg.ps[0]) * slope + seg.ps[1]
        
        elif segP2ExsitCornerCnt >= 1:
            if isVerticalLine(seg):
                slope = (seg.pe[0] - seg.ps[0]) / (seg.pe[1] - seg.ps[1])
                seg.ps[1] = 0
                seg.ps[0] = seg.pe[0] - (seg.pe[1] - seg.ps[1]) * slope 
            else:
                slope = (seg.pe[1] - seg.ps[1]) / (seg.pe[0] - seg.ps[0])
                seg.ps[0] = 0
                seg.ps[1] = seg.pe[1] - (seg.pe[0] - seg.ps[0]) * slope
        
        else: # 两端都要补线
            if isVerticalLine(seg):
                slope = (seg.pe[0] - seg.ps[0]) / (seg.pe[1] - seg.ps[1])
                seg.ps[1] = 0
                seg.ps[0] = seg.pe[0] - (seg.pe[1] - seg.ps[1]) * slope
                seg.pe[1] = HANDLE_IMAGE_H - 1
                seg.pe[0] = (seg.pe[1] - seg.ps[1]) * slope + seg.ps[0]
            else:
                slope = (seg.pe[1] - seg.ps[1]) / (seg.pe[0] - seg.ps[0])
                seg.ps[0] = 0
                seg.ps[1] = seg.pe[1] - (seg.pe[0] - seg.ps[0]) * slope
                seg.pe[0] = HANDLE_IMAGE_W - 1
                seg.pe[1] = (seg.pe[0] - seg.ps[0]) * slope + seg.ps[1]
        
        seg.init_segment()
        seg.expandDirect = direct

        if seg.subSegs():
            seg.subSegs = []
        
        if seg.len < MIN_EXPANDED_EDGE_LINE_LENGHT:
            continue

        outSegs.append(seg)


def mayGenerateQuad(segs):
    """mayGenerateQuad
    """
    expandSegs = []
    for seg in segs:
        if seg.expandDirect != -1:
            expandSegs.append(seg)
    
    if not expandSegs:
        return False
    
    expandSegs = sorted(expandSegs, key=lambda x: x.len)

    if len(expandSegs) >= 3:
        return True
    else:
        verticalDirectSum = 0 + 1
        horizontalDirectSum = 2 + 3
        directCnt = [0, 0, 0, 0]
        for seg in segs:
            if seg.len < QUAD_EXPAND_MIN_SEG_LENGHT:
                continue

            if max(seg.ps[1], seg.pe[1]) < HANDLE_IMAGE_H / 4:
                directCnt[0] += 1
            elif min(seg.ps[1], seg.pe[1]) > HANDLE_IMAGE_H - HANDLE_IMAGE_H / 4:
                directCnt[1] += 1
            elif max(seg.ps[0], seg.pe[0]) < HANDLE_IMAGE_W / 4:
                directCnt[2] += 1
            elif min(seg.ps[0], seg.pe[0]) > HANDLE_IMAGE_W - HANDLE_IMAGE_W / 4:
                directCnt[3] += 1
            
            if len(expandSegs) == 1:
                if expandSegs[0].expandDirect <= verticalDirectSum \
                    and directCnt[verticalDirectSum - expandSegs[0].expandDirect] > 0:
                    return True
                elif expandSegs[0].expandDirect <= horizontalDirectSum \
                    and directCnt[horizontalDirectSum - expandSegs[0].expandDirect] > 0:
                    return True
            
            if len(expandSegs) == 2:
                directPairSum = expandSegs[0].expandDirect + expandSegs[1].expandDirect
                if directPairSum == verticalDirectSum or directPairSum == horizontalDirectSum:
                    return True
                elif directCnt[verticalDirectSum - expandSegs[0].expandDirect] > 0 or \
                    directCnt[horizontalDirectSum - expandSegs[1].expandDirect] > 0:
                    return True
    return False


def cornerCase(canny_img, segs, corners):
    """根据角点情况找多边形
    Args:
        segs: 线段
        corners: 角点
    """
    res_tmp = tryQuadWithBoardLine(canny_img, segs, corners)
    newQuadsWithBoard = res_tmp['quads']
    flag = res_tmp['flag']
    newSegsWithBoard = res_tmp['segments']
    newCornersWithBoard = res_tmp['corners']
    if flag:
        newQuadsWithBoard = sorted(newQuadsWithBoard, key=lambda x: x.score, reverse=True)
        quadOut = newQuadsWithBoard[0]
        return quadOut
    
    # 增加边界线还找不到框，那么增加一些可能的线
    # # print(len(newSegsWithBoard))
    # # print(len(newCornersWithBoard))
    # debug_img_widthBoard = draw_segments(canny_img, newSegsWithBoard)
    # debug_img_newCorners = draw_corners(canny_img, newCornersWithBoard)
    # cv2.imwrite('test_segment_withBoard.jpg', debug_img_widthBoard)
    # cv2.imwrite('test_corner_newCorners.jpg', debug_img_newCorners)

    res_info_tmp = addVertexSegs(canny_img, newSegsWithBoard)
    allSegs = res_info_tmp['outSegs']
    newCornersWithAllSegs = res_info_tmp['outCorners']

    # debug_img = draw_segments(handle, allSegs)
    # debug_img_corner = draw_corners(handle, corners)
    # cv2.imwrite('test_segment_corner_case_step1.jpg', debug_img)
    newQuadsWithAllSegs = calcQuad(canny_img, allSegs, newCornersWithAllSegs, False)
    
    
    if newQuadsWithAllSegs:
        newQuadsWithAllSegs = sorted(newQuadsWithAllSegs, key=lambda x: x.score, reverse=True)
        quadOut = newQuadsWithAllSegs[0]
        if isTrapezoid(quadOut, allSegs, False):
            newExpandAndOrgSegs = []
            addExtendNearEdgeSegs(segs, corners, newExpandAndOrgSegs)

            newExpandQuads = []
            newExpandAllSegs = []
            newExpandCorners = []
            res_info_Tra = addVertexSegs(canny_img, newExpandAndOrgSegs)
            newExpandAllSegs = res_info_tmp['outSegs']
            newExpandCorners = res_info_tmp['outCorners']

            if not mayGenerateQuad(newExpandAllSegs):
                quadOut = generateImageEdgeQuad(canny_img)
            
            quads = calcQuad(canny_img, newExpandAllSegs, newExpandCorners, False)
            if quads:
                quads = sorted(quads, key=lambda x: x.score, reverse=True)
                quadOut = quads[0]

        return quadOut
    else: # 直接返回原始的图像
        return generateImageEdgeQuad(canny_img)


def detect(heatmap, img_bgr, thre):
    """[summary]

    Args:
        heatmap ([Mat]): 边缘检测网络输出的heatmap图, [0, 255]
        img_bgr ([Mat]): 原始的图像 [0, 255]
        thre ([float]): 阈值  [0, 1]
    """
    # 检测直线，借用的是opencv contrib中的fastlineDetector 
    # 如果后续上线的opencv版本中包含contrib模块，可做适合的替换
    h_heatmap = HANDLE_IMAGE_H
    w_heatmap = HANDLE_IMAGE_W
    
    h_real_handle = h_heatmap - 2 * handle_image_padding # opencv 中的设定
    w_real_handle = w_heatmap - 2 * handle_image_padding
    heatmap_handle = np.zeros((h_heatmap, w_heatmap))
    handleRect = cv2.resize(heatmap, (w_real_handle, h_real_handle))
    heatmap_handle[handle_image_padding:  \
            handle_image_padding + h_real_handle, \
            handle_image_padding: handle_image_padding + w_real_handle] = handleRect.copy()

    # 模糊 blur
    handle_mask = (heatmap_handle < (thre * 255))
    heatmap_handle[handle_mask] = 0
    handle = heatmap_handle.copy().astype(np.uint8)
    handle = cv2.GaussianBlur(handle, (3, 3), 0)
    
    # handle_name = img_name + '_handle.png'
    # handle_name_path = osp.join(debug_output_dir, handle_name)
    # cv2.imwrite(handle_name_path, handle)

    fld = cv2.ximgproc.createFastLineDetector(length_thre, distance_thre,  \
            canny_th1, canny_th2, canny_aperture_size, do_merge=True)
    lines = fld.detect(handle)

    merges = []
    # for i in range(len(lines)):
    #     # print("线段{}的端点为:{}".format(i, lines[i]))

    # 给线段增加一些新的属性
    for line_seg in lines:
        ps_tmp = line_seg[0][0:2]
        pe_tmp = line_seg[0][2:]
        seg_tmp = Segment(ps_tmp, pe_tmp)
        seg_tmp.seg_type = 0
        # # print(seg_tmp.ps)
        # # print(seg_tmp.pe)
        seg_tmp.init_segment()
        merges.append(seg_tmp)
    
    # 合并线段
    """
    1.合并FSL检测出的线段
     合并规则：
        (1)两条线段夹角不能超过给定的角度阈值 MAX_CRUDE_ANGLE
        (2)两条线段垂直距离不能超过给定的距离阈值 MAX_CRUDE_LINE_DIST
        (3)两条线段的垂直距离大于给定的距离阈值并且形成的多边形需要在图像内 MIN_CRUDE_LINE_DIST 
        (4)两条线段重合的部分大于一定的长度 MIN_CRUDE_OVERLAP_RATIO    
    2.合并第一步中得到的线段
       合并规则：
       （1）两直线的夹角不超过给定的阈值
       （2）两条线段垂直距离不能超过给定的距离阈值
       （3）重叠部分在设定的阈值内
    """

    # for i in range(len(merges)):
    #     # print("线段{}的端点为:{}, {}".format(i, merges[i].ps, merges[i].pe))

    merges = mergeCrudeSegs(handle, merges)
    # for i in range(len(merges)):
    #     # print("初步合并后线段{}的端点为:{}, {}".format(i, merges[i].ps, merges[i].pe))
    # crude_img = draw_segments_v2(img_bgr_draw, merges)
    # crude_name = img_name + '_crude.png'
    # crude_img_path = osp.join(debug_output_dir, crude_name)
    # cv2.imwrite(crude_img_path, crude_img)

    merges = mergeFineSegs(handle, merges)
    # fine_img = draw_segments_v2(img_bgr_draw, merges)
    # fine_name = img_name + '_fine.png'
    # fine_img_path = osp.join(debug_output_dir, fine_name)
    # cv2.imwrite(fine_img_path, fine_img)
    merges = filterSegs(merges)

    # debug_img_segment = draw_segments(handle, merges)
    # cv2.imwrite('test_segment_filter.jpg', debug_img_segment)

    # 计算角点
    corners = calcCorners(handle, merges)
    # corner_img = draw_corners(debug_img_segment, corners)
    # corner_name = img_name + '_corner.png'
    # corner_img_path = osp.join(debug_output_dir, corner_name)
    # cv2.imwrite(corner_img_path, corner_img)

    flag_calc_Edge_quad, quad = calcEdgeQuad(handle, merges, corners)

    # debug_img_segment = draw_segments(handle, merges)
    # debug_img_corner = draw_corners(debug_img_segment, corners)
    # cv2.imwrite('test_segment.jpg', debug_img_segment)
    # cv2.imwrite('test_corner.jpg', debug_img_corner)
    if not flag_calc_Edge_quad:
        # 考虑角点的情况
        # debug_img_segment = draw_segments(handle, merges)
        # debug_img_corner = draw_corners(debug_img_segment, corners)
        # cv2.imwrite('test_segment_debug.jpg', debug_img_segment)
        # cv2.imwrite('test_corner_debug.jpg', debug_img_corner)
        quads = calcQuad(handle, copy.deepcopy(merges), corners)
        # debug_img_segment = draw_segments(handle, merges)
        # debug_img_corner = draw_corners(handle, corners)
        # cv2.imwrite('test_segment_corner_case_input.jpg', debug_img_segment)
        # cv2.imwrite('test_corner_corner_case_input.jpg', debug_img_corner)

        realQuads = []
        if quads:
            quad_sort = sorted(quads, key=lambda x: x.score, reverse=True)
            quad_pts = normalizeQuad(heatmap, quad_sort[0])
            quad = quad_sort[0]
            # debug
            # corners_tmp = quad_sort[0].corners
            # debug_img = img_bgr_draw.copy()
                # 目前存在右边的节点的坐标向左边平移了一部分

            # debug_img_v2 = img_bgr_draw[handle_image_padding: handle_image_padding + HANDLE_REAL_H, handle_image_padding: handle_image_padding + HANDLE_REAL_W]
            # debug_img_v2 = cv2.resize(debug_img_v2, (512, 512))
            
            # for i, pt_tmp in enumerate(corners_tmp):
            #     pt_ps = corners_tmp[(i) % 4].pt
            #     pt_pe = corners_tmp[(i + 1) % 4].pt 
            #     cv2.line(debug_img, tuple(map(int, pt_ps)), tuple(map(int, pt_pe)), (0, 0, 255), 1)
            #     # ratio = 1.0 * 512 / HANDLE_IMAGE_H
            #     # pt_ps_draw = [int((pt_ps[0] - 5) * ratio), int((pt_ps[1] -  5) * ratio)]
            #     # pt_pe_draw = [int((pt_pe[0] - 5) * ratio), int((pt_pe[1] -  5) * ratio)]
            #     pt_ps_draw = [pt_ps[0] - 5, pt_ps[1] -  5]
            #     pt_pe_draw = [pt_pe[0] - 5, pt_pe[1] -  5]
            #     cv2.line(debug_img_v2, tuple(map(int, pt_ps_draw)), tuple(map(int, pt_pe_draw)), (0, 0, 255), 1)

            # cv2.imwrite('debug_0719.jpg', debug_img)
            # cv2.imwrite('debug_0719_v2.jpg', debug_img_v2)
            # h_tmp, w_tmp = heatmap.shape
            # # print("h_tmp:{}, w_tmp:{}".format(h_tmp, w_tmp))
            
            
        else:
            # cornerCase
            # print("角点case情况")
            quad_tmp = cornerCase(handle, merges, corners)
            quad_pts = normalizeQuad_2(heatmap, quad_tmp)
            quad = quad_tmp
    else:
        quad_pts = []
        for corner_tmp in quad.corners:
            h, w, c = img_bgr.shape
            ratio_w = 1.0 * w / HANDLE_REAL_W
            ratio_h = 1.0 * h / HANDLE_REAL_H
            quad_pts.append([int(corner_tmp.pt[0] * ratio_w), int(corner_tmp.pt[1] * ratio_h)])
    res_pt = copy.deepcopy(quad_pts)
    # img_res = img_bgr.copy()
    # for i, pt_tmp in enumerate(res_pt):
    #     pt_pe = res_pt[ (i + 1) % 4] 
    #     cv2.line(img_res, tuple(pt_tmp), tuple(pt_pe), (0, 255, 0), 1)
    # cv2.imwrite('renchang_result.jpg', img_res)

    if len(res_pt) > 0:
        score = detect_confidence.confidence(heatmap, img_bgr, thre, res_pt, quad)
    else:
        score = 0
    return res_pt, score
 

def draw_segments(img, segments):
    """draw_segments
    """
    if img.ndim == 3:
        res_img = np.zeros_like(img)
    else:
        h, w = img.shape
        res_img = np.zeros((h, w, 3))
    for i, segment in enumerate(segments):
        if segment.seg_type == 0:
            color_draw = (255, 255, 255)
        elif segment.seg_type == 1:
            color_draw = (255, 0, 255)
        elif segment.seg_type == 2:
            color_draw = (255, 255, 0)
        else:
            color_draw = (255, 0, 0)
        
        p1 = tuple(map(int, segment.ps)) 
        p2 = tuple(map(int, segment.pe))
        mid_p = ((p1[0] + p2[0]) // 2, (p1[1] + p2[1]) // 2)
        cv2.line(res_img, p1, p2, color_draw, thickness=1)
        cv2.putText(res_img, str(i), mid_p, cv2.FONT_HERSHEY_PLAIN, 1, color_draw, 1)
    cv2.imwrite('test.jpg', res_img)
    return res_img


def draw_corners(img, corners):
    """绘制角点
    """
    # if img.ndim == 3:
    #     img_draw = np.zeros_like(img)
    # else:
    #     h , w = img.shape
    #     img_draw = np.zeros((h, w, 3))
    img_draw = img.copy()
    for i, corner in enumerate(corners):
        pt = corner.pt
        pt_draw = (pt[0], pt[1])
        pt_text = (max(pt[1] - 5, 0), max(pt[0] - 5, 0))
        text = str(i) + '_' + "%.2f" % corner.score
        # print("第{}个点的坐标为:{}, 得分为:{}".format(i, pt, "%.2f" % corner.score))
        cv2.circle(img_draw, pt_draw, 1, (255, 255, 255), 0)
        # cv2.putText(img_draw, text, pt_text, cv2.FONT_HERSHEY_PLAIN, 0.5, (0, 0, 255), 1)
    return img_draw


def draw_segments_v2(img, segments):
    """draw_segments
    """
    if img.ndim == 3:
        res_img = img.copy()
    else:
        h, w = img.shape
        res_img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)
    
    for i, segment in enumerate(segments):
        if segment.seg_type == 0:
            color_draw = (0, 0, 255)
        elif segment.seg_type == 1:
            color_draw = (255, 0, 255)
        elif segment.seg_type == 2:
            color_draw = (255, 255, 0)
        else:
            color_draw = (255, 0, 0)
        
        p1 = tuple(map(int, segment.ps)) 
        p2 = tuple(map(int, segment.pe))
        mid_p = ((p1[0] + p2[0]) // 2, (p1[1] + p2[1]) // 2)
        cv2.line(res_img, p1, p2, color_draw, thickness=1)
        cv2.putText(res_img, str(i), mid_p, cv2.FONT_HERSHEY_PLAIN, 1, color_draw, 1)
    cv2.imwrite('test.jpg', res_img)
    return res_img


def restoreCorners(src_img, corners):
    """restoreCorners
    """
    if src_img.ndim == 3:
        h, w, c = src_img.shape
    else:
        h, w = src_img.shape
    corners_dl = copy.deepcopy(corners)
    for corner in corners_dl:
        # print(corner.pt)
        corner.pt[0] -= HANDLE_IMAGE_PADDING
        corner.pt[1] -= HANDLE_IMAGE_PADDING
        x_ratio = w * 1.0 / HANDLE_REAL_W
        y_ratio = h * 1.0 / HANDLE_REAL_H
        corner.pt[0] *= x_ratio
        corner.pt[1] *= y_ratio
    return corners_dl


def restoreQuad(src_img, quad):
    """
    restoreQuad
    """
    res_corners = restoreCorners(src_img, quad.corners)
    quad_res = copy.deepcopy(quad)
    quad_res.corners = res_corners
    return quad_res


def normalizeQuad(src_img, quad):
    """normalizeQuad
    """
    quadPts = []
    quadDL = copy.deepcopy(quad)
    if src_img.ndim == 3:
        h, w, c = src_img.shape
    else:
        h, w = src_img.shape
    
    quadDL = restoreQuad(src_img, quadDL)
    # debug_pts = []
    for corner in quadDL.corners:
        corner.pt = list(map(int, corner.pt))
        # debug_pts.append(corner.pt)

    # # print("映射后的点的坐标为:{}".format(debug_pts))
    
    pt_top = [0, 0]
    pt_left = [0, h - 1]
    pt_right = [w - 1, 0]
    pt_bottom = [w - 1, h - 1]

    seg_top = Segment(pt_top, pt_right)
    seg_bottom = Segment(pt_left, pt_right)
    seg_left = Segment(pt_top, pt_left)
    seg_right = Segment(pt_right, pt_bottom)

    boardLines = [seg_top, seg_right, seg_bottom, seg_left]
    for seg in boardLines:
        seg.init_segment()
    
    n_corner = len(quadDL.corners)
    boardsDirects = (0, 3, 2, 1)
    
    for i in range(n_corner):
        last_c = quadDL.corners[(i + QUAD_CORNER_NUM - 1) % QUAD_CORNER_NUM]
        now_c = quadDL.corners[i]
        next_c = quadDL.corners[(i + 1) % QUAD_CORNER_NUM]

        if not testCornerInBoard(now_c, src_img, False):
            direct = []
            if now_c.pt[0] < 0:
                direct.append(2)
            elif now_c.pt[0] >= w:
                direct.append(3)
            
            if now_c.pt[1] < 0:
                direct.append([0])
            elif now_c.pt[1] >= h:
                direct.append(1)
            
            mayInterBoards = []
            
            for dir_tmp in direct:
                for i, d in enumerate(boardsDirects):
                    if d == dir_tmp:
                        mayInterBoards.append(boardLines[i])
            
            l1 = Segment(last_c.pt, now_c.pt)
            l1.init_segment()
            l2 = Segment(now_c.pt, next_c.pt)
            l2.init_segment()

            intersections = []
            for b in mayInterBoards:
                flag1, inter_l1 = getSegmentIntersection(b, l1)
                if not flag1:
                    continue
                if isPointOnLine(inter_l1, b) and isPointOnLine(inter_l1, l1):
                    intersections.append(inter_l1)
                
                flag2, inter_l2 = getSegmentIntersection(b, l2)
                if not flag2:
                    continue
                if isPointOnLine(inter_l2, b) and isPointOnLine(inter_l2, l2):
                    intersections.append(inter_l2)
                
                if len(intersections) >= 2:
                    break
            
            if len(intersections) >= 2:
                d1 = getPointDist(now_c.pt, intersections[0])
                d2 = getPointDist(now_c.pt, intersections[1])
                if d1 < d2:
                    quadPts.append(intersections[0])
                else:
                    quadPts.append(intersections[1])
            elif len(intersections) == 1:
                quadPts.append(intersections[0])
            else:
                return []
        else:
            quadPts.append(now_c.pt)
    return quadPts


def normalizeQuad_2(src_img, quad):
    """normalizeQuad_2
    """
    quadPts = []
    quadDL = copy.deepcopy(quad)
    if src_img.ndim == 3:
        h, w, c = src_img.shape
    else:
        h, w = src_img.shape
    
    quadDL = restoreQuad(src_img, quadDL)
    for corner_tmp in quadDL.corners:
        corner_tmp.pt[0] = int(min(max(corner_tmp.pt[0], 0), w - 1))
        corner_tmp.pt[1] = int(min(max(corner_tmp.pt[1], 0), h - 1))
        quadPts.append(corner_tmp.pt)
    return quadPts


def draw_result(src_img, quadPts):
    """draw_result
    """
    img_res = src_img.copy()
    for i, pt_tmp in enumerate(quadPts):
        pt_pe = quadPts[(i + 1) % 4] 
        cv2.line(img_res, tuple(pt_tmp), tuple(pt_pe), (0, 255, 0), 1)
    return img_res


if __name__ == "__main__":
    debug_dir = '/home/work/codes/document/document/algorithm/edge_detection/postprocess/result_image'
    debug_img_pattern = osp.join(debug_dir, '*')
    debug_img_fullpaths = glob(debug_img_pattern)
    debug_output_dir = './output'
    os.makedirs(debug_output_dir, exist_ok=True)
    thre = 0.22

    for img_path in tqdm(debug_img_fullpaths, total=len(debug_img_fullpaths)):
        img_name = osp.split(img_path)[-1].split('.')[0]
        img_heatmap_bgr = cv2.imread(img_path)
        h, w, _ = img_heatmap_bgr.shape
        img_bgr = img_heatmap_bgr[:, 0: w // 2, :]
        heatmap = img_heatmap_bgr[:, w // 2:, :]
        heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2GRAY)
        res_pt = detect(heatmap, img_bgr, thre)
        res_img_tmp = draw_result(img_bgr, res_pt)
        img_save_name = img_name + '_result.jpg'
        img_save_path = osp.join(debug_output_dir, img_save_name)
        cv2.imwrite(img_save_path, res_img_tmp)



    




