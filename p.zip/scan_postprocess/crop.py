#!/usr/bin/env python
# -*- encoding: utf-8 -*-
################################################################################
#
# Copyright (c) 2021 Baidu.com, Inc. All Rights Reserved
#
################################################################################
"""
@File        :crop.py
@Time        :2021/07/27 14:29:52
@Author      :renchang
@Version     :1.0
@Contact     :renchang@baidu.com
"""

# 根据角点坐标矫正文档
import os
import numpy as np
import cv2 
from detect import getLineAngle, Segment, getPointDist, draw_result
import copy
import math


CROP_EXCEED_RATIO = 1.2
EPS = 1e-10

def check_scan_result(pts, angle_thre):
    """check并修正角点

    Args:
        pts : 角点
        angle_thre : 角度阈值

    Returns:
        角点
    """
    assert len(pts) == 4 and len(pts[0]) == 2
    n_points = len(pts)
    pts_array = np.array(pts).reshape((-1, 2))
    hull = cv2.convexHull(pts_array, False, False)

    flag = True
    if len(hull) != len(pts):
        flag = False

    pt_res = []
    for i in range(len(hull)):
        index_tmp = hull[i][0]
        pt_res.append(pts[i])
    
    
    for i in range(len(pt_res)):
        ps_tmp = pt_res[i]
        pe_tmp = pt_res[(i + 1) % n_points]
        pre_tmp = pt_res[(i - 1) % n_points]
        seg_tmp = Segment(ps_tmp, pe_tmp)
        seg_tmp.init_segment()
        
        seg_pre = Segment(ps_tmp, pre_tmp)
        seg_pre.init_segment()
        angle_diff = getLineAngle(seg_pre, seg_tmp)
        if angle_diff < angle_thre:
            flag = False
            break
    
    return pt_res if flag else []


def calcEdgesAngle(segs):
    """calcEdgesAngle
    """
    seg_horizontal = Segment([0, 0], [1, 0])
    seg_horizontal.init_segment()

    angle_total = 0
    for seg in segs:
        angle_diff_tmp = getLineAngle(seg, seg_horizontal)
        angle_total += angle_diff_tmp
    return angle_total
    

def reorderImgPts(imgPts):
    """    # 先找到水平和竖直的边
           # 返回的角点的顺序是[0, 1
           #                 2, 3]
    """

    edge1 = []
    edge2 = []
    n_points = len(imgPts)
    for i in range(n_points):
        ps_tmp = imgPts[i]
        pe_tmp = imgPts[(i + 1) % n_points]
        seg_tmp = Segment(ps_tmp, pe_tmp)
        seg_tmp.init_segment()
        if i % 2 == 0:
            edge1.append(seg_tmp)
        else:
            edge2.append(seg_tmp)
    
    angle1 = calcEdgesAngle(edge1)
    angle2 = calcEdgesAngle(edge2)
    print("angel1:{}".format(angle1))
    print("angel2:{}".format(angle2))
    flag = angle1 < angle2
    
    if flag: # 说明edge1 存储的是水平边
        seg_horizontals = edge1
        seg_verticals = edge2
    else:
        seg_horizontals = edge2
        seg_verticals = edge1
    
    # print("原始的点的坐标为:{}".format(imgPts))
    # print("当前的方向为:{}".format(flag))
    res_imgPts = []
    if flag: 
        if imgPts[0][1] > imgPts[3][1]: # 右下角
            res_imgPts = [imgPts[2], imgPts[3], imgPts[1], imgPts[0]]
        else:
            res_imgPts = [imgPts[0], imgPts[1], imgPts[3], imgPts[2]]
    else:
        if imgPts[0][1] > imgPts[1][1]: # 右上角
            res_imgPts = [imgPts[1], imgPts[2], imgPts[0], imgPts[3]]
        else:
            res_imgPts = [imgPts[3], imgPts[0], imgPts[2], imgPts[1]]
    # print("排序后点的坐标为:{}".format(res_imgPts))
    mean_y = (res_imgPts[0][1] + res_imgPts[1][1]) / 2
    mean_y1 = (res_imgPts[2][1] + res_imgPts[3][1]) / 2
    if mean_y > mean_y1:
        return [res_imgPts[2], res_imgPts[3], res_imgPts[0], res_imgPts[1]]
    else:
        return res_imgPts


def calcAspectRatio(imgPts, real_img):
    """calcAspectRatio
    """
    h, w, _ = real_img.shape
    assert len(imgPts) == 4

    imgPts_add = []
    for i in range(4):
        cur_pt = imgPts[i]
        cur_pt.append(1)
        imgPts_add.append(cur_pt)
    

    imgPts_add_array = np.array(imgPts_add).astype(float).reshape((-1, 3))
    
    m1 = imgPts_add_array[0, :]
    m2 = imgPts_add_array[1, :]
    m3 = imgPts_add_array[2, :]
    m4 = imgPts_add_array[3, :]

    k2Numerator = np.cross(m1, m4).dot(m3)
    k2Denominator = np.cross(m2, m4).dot(m3)
    k2 = k2Numerator / k2Denominator
    n2 = k2 * imgPts_add_array[1] - imgPts_add_array[0]

    k3Numerator = np.cross(m1, m4).dot(m2)
    k3Denominator = np.cross(m2, m4).dot(m2)
    k3 = k3Numerator / (k3Denominator + EPS)
    n3 = k3 * imgPts_add_array[2] - imgPts_add_array[1]

    usualFocal = min(h, w)
    focalThreshold = usualFocal / 10
    u0 =  w / 2
    v0 = h / 2
    s = 1
    focal = 0.0
    aspectRatio = 0.0

    if abs(n2[2]) < 0.001 or abs(n3[2]) < 0.001:
        focal = usualFocal
    else:
        fSquare = -((n2[0] * n3[0] - (n2[0] * n3[2] + n2[2] * n3[0]) * u0 + n2[2] * n3[2] * u0 * u0) * s * s +  \
                     (n2[1] * n3[1] - (n2[1] * n3[2] + n2[2] * n3[1]) * v0  \
                     + n2[2] * n3[2] * v0 * v0)) / (n2[2] * n3[2] * s * s + EPS)
        if fSquare < 0:
            focal = usualFocal
        else:
            focal = math.sqrt(fSquare)
        
        if abs(focal - usualFocal) <= focalThreshold:
            focal = usualFocal
    
    # 通过焦距估计长宽比
    A = [[focal, 0, u0], [0, focal, v0], [0, 0, 1]]
    A_array = np.array(A).astype(float).reshape((3, 3))
    A_array_inv = np.linalg.inv(A_array)
    A_array_t = A_array.T
    A_array_t_inv = np.linalg.inv(A_array_t)

    fraction =  np.dot(np.dot(n2.T, A_array_t_inv * A_array_inv), n2)
    denominator_tmp = np.dot(np.dot(n3.T, A_array_t_inv * A_array_inv), n3)
    aspectRatioSquare = fraction / denominator_tmp
    # aspectRatioSquare = np.dot(np.dot(n2.T, A_array_t_inv * A_array_inv), n2) / np.dot(np.dot(n3.T, A_array_t_inv * A_array_inv), n3)

    if aspectRatioSquare < 0:
        aspectRatio = -1
    else:
        aspectRatio = math.sqrt(aspectRatio)
    
    return aspectRatio


def calPerspectiveImgHW(imgPts, aspectRatio, src_img):
    """calPerspectiveImgHW
    """
    assert len(imgPts) ==  4
    h, w, _ = src_img.shape
    a = getPointDist(imgPts[0], imgPts[1])
    b = getPointDist(imgPts[0], imgPts[2])
    a1 = getPointDist(imgPts[2], imgPts[3])
    b1 = getPointDist(imgPts[3], imgPts[1])

    maxW = max(a, a1)
    maxH = max(b, b1)

    mean_a = (a + a1) / 2
    mean_b = (b + b1) / 2

    ratio = min(a, a1) / min(b, b1)

    if mean_a > mean_b:
        resultW = int(maxW)
        resultH = min(int(resultW / (ratio + EPS)), int(h * CROP_EXCEED_RATIO))
    else:
        resultH = int(maxH)
        resultW = min(int(resultH * ratio), int(w * CROP_EXCEED_RATIO))
    
    if aspectRatio == -1:
        initialRatio = maxW / maxH
        if initialRatio >= aspectRatio:
            resultH = min(int(resultW / (aspectRatio + EPS)), int(h * CROP_EXCEED_RATIO))
        else:
            resultW = min(int(resultH * aspectRatio), int(w * CROP_EXCEED_RATIO))
    return (resultW, resultH)
        

def crop(src_img, pts):
    """crop
    """
    h_src, w_src, _ = src_img.shape
    assert len(pts) == 4 and len(pts[0]) == 2

    # 判断检测出的点是否合理
    angle_thre = 30
    pts_check = check_scan_result(pts, angle_thre)
    
    if not pts_check:
        return None 
    
    pts_reorder = reorderImgPts(pts_check)
    print("映射后的点的位置为:{}".format(pts_reorder))
    pts_reorder_float = np.float32(pts_reorder)
    print('pts_reorder_float:{}'.format(pts_reorder_float))

    aspectRatio = calcAspectRatio(pts_reorder, src_img)

    resultW, resultH = calPerspectiveImgHW(pts_reorder, aspectRatio, src_img)

    dst_pts = [[0, 0], [resultW - 1, 0], [0, resultH - 1], [resultW - 1, resultH - 1]]

    dst_pts_float = np.float32(dst_pts)
    print("dst_pts_float:{}".format(dst_pts_float))

    M = cv2.getPerspectiveTransform(pts_reorder_float, dst_pts_float)

    crop_img = cv2.warpPerspective(src_img, M, (resultW, resultH))
    return crop_img







    

