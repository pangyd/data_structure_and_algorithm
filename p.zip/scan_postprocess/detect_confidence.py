from skimage.draw import line
import numpy as np
import cv2

from utils import draw_result, show_img


weights_dict = {"边缘": 0.5, "角点":0.15, "矩形度":0.2, "长宽比":0 , "面积":0.15}

def get_line_points(p1, p2):
    return line(p1[1], p1[0], p2[1], p2[0])

def calculate_properties(points, area):
    points = np.array(points)

    # 1. 计算四边形的面积
    polygon_area = cv2.contourArea(points)
    
    # 2. 计算最小外接矩形的长、宽、面积及其长宽比
    rect = cv2.minAreaRect(points)
    box = cv2.boxPoints(rect)
    box = np.int0(box)
    
    rect_width = np.linalg.norm(box[0] - box[1])
    rect_height = np.linalg.norm(box[1] - box[2])
    bounding_rect_area = rect_width * rect_height
    aspect_ratio = rect_width / rect_height if rect_width >= rect_height else rect_height / rect_width

    # 3. 计算矩形度
    rectangularity = polygon_area / bounding_rect_area

    rect_score = rectangularity * rectangularity
    scale_score = min(2 / aspect_ratio, 1)
    area_score = min(2 * polygon_area / area, 1)
    return {
        "矩形度": rect_score,
        "长宽比": scale_score,
        "面积": area_score,
    }
    
def confidence(heatmap, img_bgr, thre, points, quads):
    lines_points = []
    for i in range(len(points)):
        lines_points.append(get_line_points(points[i], points[(i + 1)%len(points)]))

    h, w, _ = img_bgr.shape
    ratio = w / h
    # 设定调整后的图像A的尺寸
    new_size = (384, int(384 / ratio)) if ratio > 1 else (int(384 * ratio), 384)

    scale_x = new_size[0] / heatmap.shape[1]
    scale_y = new_size[1] / heatmap.shape[0]
    heatmap = cv2.resize(heatmap, new_size)
    
    # 膨胀，模糊 blur
    heatmap[heatmap < (thre * 255)] = 0
    kernel = np.ones((5, 5), np.uint8) # 5
    heatmap = cv2.dilate(heatmap, kernel, iterations=1)
    heatmap = cv2.GaussianBlur(heatmap, (21, 21), 0) # 21
    
    # 获取所有直线上的点并计算平均值
    values = []
    for line_points in lines_points:
        rr, cc = line_points
        rr = np.round(rr * scale_y).astype(int)
        cc = np.round(cc * scale_x).astype(int)
        rr = np.minimum(rr, heatmap.shape[0] - 1)
        cc = np.minimum(cc, heatmap.shape[1] - 1)
        values.extend(heatmap[rr, cc])

    line_score = np.mean(values)
    point_score = 1
    print(line_score / 255.0)
    for i in range(4):
        point_score -= quads.corners[i].score * 0.5
        point_score -= quads.corners[i].score * 0.5
    print(point_score)
                    
    area = heatmap.shape[0] * heatmap.shape[1]
    pro = calculate_properties(points, area)
    pro["角点"] = max(point_score, 0)
    pro["边缘"] = line_score / 255.0
    pro["总分"] = 0
    for key, value in weights_dict.items():
        pro["总分"] += pro[key] * value
    print(pro)
    score = str(int(pro["总分"] * 100))
    
    points = np.array(points)
    points[:, 1] = np.round(points[:, 1] * scale_x).astype(int)
    points[:, 0] = np.round(points[:, 0] * scale_y).astype(int)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_GRAY2BGR)
    heatmap = draw_result(heatmap, points, thickness=1)
    show_img(heatmap, "heatmap")
    return score
