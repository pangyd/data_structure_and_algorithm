# include "Python.h"
#include<opencv2/imgcodecs.hpp>
#include<opencv2/highgui.hpp>
#include<opencv/cv.hpp>
#include "doc_scan/doc_postprocess.h"
#include "doc_crop/doc_correction.h"

// void detect(const cv::Mat& heatmap, std::vector<cv::Point2f>& quadPts, const cv::Mat& src, float thresh,
//                 int& processStatus, bool isDebug = false);
extern "C" PyObject* post_process(int thresh, int w, int h, uchar * data, int src_w, int src_h, uchar * srcData){
    float lowTh = 40;
    float best_thresh = thresh * 0.01;
    DocPostprocess detector = DocPostprocess(8, 4, lowTh, lowTh * 3, 3, true);

    cv::Mat heatmap(cv::Size(w, h), CV_8UC1, data);
    cv::Mat src(cv::Size(src_w, src_h), CV_8UC3, srcData);

    int processStatus = PROCESS::EDGECASE;
    std::vector<cv::Point2f> quadPts;
    detector.detect(heatmap, quadPts, src, best_thresh, processStatus, false);

    PyGILState_STATE gstate = PyGILState_Ensure();
    PyObject* Plist = PyList_New(0);

    for(auto pt: quadPts){
        PyList_Append(Plist, Py_BuildValue("f", pt.x));
        PyList_Append(Plist, Py_BuildValue("f", pt.y));
    }
    PyGILState_Release(gstate);
    return Plist;

}

extern "C" PyObject* crop(int w, int h, uchar * data, float* coordinate_p, int coordinate_size){
    cv::Mat src(cv::Size(w, h), CV_8UC3, data);
    std::vector<float> coordinate(coordinate_p,coordinate_p+coordinate_size);
    std::cout << __LINE__ << std::endl;

    bool flag = false;
    cv::Mat recitify = crop(src, coordinate, flag);
    int h_ = recitify.rows;
    int w_ = recitify.cols;
    int channels = recitify.channels();
    std::cout << "Channels: " << channels << std::endl;
    PyGILState_STATE gstate = PyGILState_Ensure();
    PyObject* Plist = PyList_New(0);
    auto* p = recitify.data;
    for (int c=0;c<channels;c++) {
        for (int i = 0; i < recitify.rows; i++) {
            for (int j = 0; j < recitify.cols; j++) {
                int tmp = static_cast<int>(*p);
                PyList_Append(Plist, Py_BuildValue("I", tmp));
                p++;
            }
        }
    }
    // for (int i = 0; i < recitify.rows; i++) {
    //     for (int j = 0; j < recitify.cols; j++) {
    //         int tmp = static_cast<int>(*p);
    //         PyList_Append(Plist, Py_BuildValue("I", tmp));
    //         p++;
    //     }
    // }
    PyList_Append(Plist, Py_BuildValue("I", h_));
    PyList_Append(Plist, Py_BuildValue("I", w_));
    PyGILState_Release(gstate);
    
    return Plist;
}
// extern "C" void post_crop(int w, int h, uchar* data, float* points, char* save_path){
//     cv::Mat src_img(cv::Size(w, h), CV_8UC3, data);
//     std::vector<float> cv_points;
//     for(int i = 0; i < 8; i++){
//         cv_points.push_back(points[i]);
//     }
//     std::string str(save_path);
//     crop_save(src_img, cv_points, str);
// }